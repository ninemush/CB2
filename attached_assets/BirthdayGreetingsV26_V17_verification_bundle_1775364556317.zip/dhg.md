# Developer Handoff Guide

**Project:** BirthdayGreetingsV26
**Generated:** 2026-04-04
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Not Ready (39%)

**14 workflows: 5 fully generated, 0 with handoff blocks, 8 workflow-level stubs, 1 Studio-blocked**
**Total Estimated Effort: ~205 minutes (3.4 hours)**
**Remediations:** 18 total (0 property, 6 activity, 0 sequence, 0 structural-leaf, 8 workflow)
**Auto-Repairs:** 9
**Quality Warnings:** 70

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `Main.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 2 | `GetBirthdays.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 3 | `ProcessBirthday.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 4 | `GenerateDraft.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 5 | `HandleHumanReview.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 6 | `Finalize.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 7 | `Process.xaml` | Blocked | 2 | 2 | 0 | 0 | 0 |
| 8 | `InitAllSettings.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 9 | `GetTransactionData.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 10 | `SetTransactionStatus.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 11 | `CloseAllApplications.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 12 | `KillAllProcesses.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 13 | `Init.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 14 | `AgentInvocation_Stub.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 5 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `GetTransactionData.xaml` | Fully Generated | Studio-openable |
| 2 | `SetTransactionStatus.xaml` | Fully Generated | Studio-openable |
| 3 | `CloseAllApplications.xaml` | Fully Generated | Studio-openable |
| 4 | `Init.xaml` | Fully Generated | Studio-openable |
| 5 | `AgentInvocation_Stub.xaml` | Generated with Placeholders | Openable with warnings |

### AI-Resolved with Smart Defaults (9)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_PLACEHOLDER_CLEANUP` | `Process.xaml` | Stripped 32 placeholder token(s) from Process.xaml | 5 |
| 2 | `REPAIR_PLACEHOLDER_CLEANUP` | `AgentInvocation_Stub.xaml` | Stripped 1 placeholder token(s) from AgentInvocation_Stub.xaml | 5 |
| 3 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (fallback): Moved ucs:BuildDataTable.DataTable from attribute to child-element in GetBirt... | undefined |
| 4 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (fallback): Moved ucs:BuildDataTable.Columns from attribute to child-element in GetBirthd... | undefined |
| 5 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (fallback): Moved ugs:GoogleCalendarGetEvents.Events from attribute to child-element in G... | undefined |
| 6 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (fallback): Moved Throw.Exception from attribute to child-element in GetBirthdays.xaml | undefined |
| 7 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (fallback): Moved ForEach.Values from attribute to child-element in GetBirthdays.xaml | undefined |
| 8 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (fallback): Moved ucs:AddDataRow.DataTable from attribute to child-element in GetBirthday... | undefined |
| 9 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (fallback): Moved ucs:AddDataRow.ArrayRow from attribute to child-element in GetBirthdays... | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `Main.xaml` | Studio-openable | — | — |
| 2 | `GetBirthdays.xaml` | Studio-openable | — | — |
| 3 | `ProcessBirthday.xaml` | Studio-openable | — | — |
| 4 | `GenerateDraft.xaml` | Studio-openable | — | — |
| 5 | `HandleHumanReview.xaml` | Studio-openable | — | — |
| 6 | `Finalize.xaml` | Studio-openable | — | — |
| 7 | `Process.xaml` | Structurally invalid — not Studio-loadable | Unclassified | [pseudo-xaml] Line 318: pseudo-XAML attribute Body="[str_EmailBody]"; [pseudo-xaml] Line 456: pseudo-XAML attribute Body="[str_EmailBody]"; [pseudo-xaml] Line 502: pseudo-XAML attribute Body="[str_EmailBody]" |
| 8 | `InitAllSettings.xaml` | Studio-openable | — | — |
| 9 | `GetTransactionData.xaml` | Studio-openable | — | — |
| 10 | `SetTransactionStatus.xaml` | Studio-openable | — | — |
| 11 | `CloseAllApplications.xaml` | Studio-openable | — | — |
| 12 | `KillAllProcesses.xaml` | Studio-openable | — | — |
| 13 | `Init.xaml` | Studio-openable | — | — |
| 14 | `AgentInvocation_Stub.xaml` | Openable with warnings | Unclassified | — |

**Summary:** 12 Studio-loadable, 1 with warnings, 1 not Studio-loadable

> **⚠ 1 workflow(s) are not Studio-loadable** — they will fail to open in UiPath Studio. Address the blockers listed above before importing.

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**6 handoff block(s) requiring manual implementation**

#### 1. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 2. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 3. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 4. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 5. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 6. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**88 items remaining — ~905 minutes (15.1 hours) total estimated effort**

### Finalize.xaml (6 items, ~70 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `Finalize.xaml` replaced with Studio-openable stub | Fix XML structure in Finalize.xaml — [malformed-quote] Line 97: attribute Fil... | 15 |
| 2 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Finalize.xaml — estimated 15 min | 15 |
| 3 | Low | Quality Warning | unguarded-array-index: Line 149: array indexing ".Rows(N)" without a precedin... | Review and address | 10 |
| 4 | Low | Quality Warning | hardcoded-retry-interval: Line 159: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 5 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 91: Complex expression (lambdas, LINQ, n... | Review and address | 10 |
| 6 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 149: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### GenerateDraft.xaml (4 items, ~45 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 7 | High | Workflow Stub | Entire workflow `GenerateDraft.xaml` replaced with Studio-openable stub | Fix XML structure in GenerateDraft.xaml — [malformed-quote] Line 69: attribut... | 15 |
| 8 | Low | Quality Warning | invalid-activity-property: Line 258: property "Condition" is not a known prop... | Review and address | 10 |
| 9 | Low | Quality Warning | hardcoded-retry-interval: Line 79: retry interval hardcoded as "{&quot;type&q... | Review and address | 10 |
| 10 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 325: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### GetBirthdays.xaml (6 items, ~65 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 11 | High | Workflow Stub | Entire workflow `GetBirthdays.xaml` replaced with Studio-openable stub | Fix XML structure in GetBirthdays.xaml — [malformed-quote] Line 322: attribut... | 15 |
| 12 | Low | Quality Warning | invalid-activity-property: Line 295: property "Condition" is not a known prop... | Review and address | 10 |
| 13 | Low | Quality Warning | hardcoded-retry-count: Line 250: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 14 | Low | Quality Warning | hardcoded-retry-interval: Line 203: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 15 | Low | Quality Warning | hardcoded-retry-interval: Line 250: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 16 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 378: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### HandleHumanReview.xaml (11 items, ~110 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 17 | High | Workflow Stub | Entire workflow `HandleHumanReview.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml | 10 |
| 18 | Low | Quality Warning | hardcoded-retry-count: Line 146: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 19 | Low | Quality Warning | hardcoded-retry-count: Line 198: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 20 | Low | Quality Warning | hardcoded-retry-interval: Line 146: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 21 | Low | Quality Warning | hardcoded-retry-interval: Line 198: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 22 | Low | Quality Warning | hardcoded-asset-name: Line 70: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 23 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 133: Unbalanced parentheses: 0 open vs 1 close — remo... | Review and address | 10 |
| 24 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 141: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 25 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 367: Unbalanced parentheses: 0 open vs 1 close — remo... | Review and address | 10 |
| 26 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 27 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### InitAllSettings.xaml (21 items, ~215 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 28 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Fix XML structure in InitAllSettings.xaml — [xml-wellformedness] XML parse er... | 15 |
| 29 | Low | Quality Warning | hardcoded-asset-name: Line 100: asset name "BGV26_GSuite_ServiceAccount_Crede... | Review and address | 10 |
| 30 | Low | Quality Warning | hardcoded-asset-name: Line 105: asset name "BGV26_BirthdaysCalendarName" is h... | Review and address | 10 |
| 31 | Low | Quality Warning | hardcoded-asset-name: Line 114: asset name "BGV26_TimeZone" is hardcoded — co... | Review and address | 10 |
| 32 | Low | Quality Warning | hardcoded-asset-name: Line 123: asset name "BGV26_EmailStyleSpec" is hardcode... | Review and address | 10 |
| 33 | Low | Quality Warning | hardcoded-asset-name: Line 132: asset name "BGV26_EmailWordCountMin" is hardc... | Review and address | 10 |
| 34 | Low | Quality Warning | hardcoded-asset-name: Line 141: asset name "BGV26_EmailWordCountMax" is hardc... | Review and address | 10 |
| 35 | Low | Quality Warning | hardcoded-asset-name: Line 150: asset name "BGV26_AllowActionCenterFallback" ... | Review and address | 10 |
| 36 | Low | Quality Warning | hardcoded-asset-name: Line 159: asset name "BGV26_GmailFromConnectionName" is... | Review and address | 10 |
| 37 | Low | Quality Warning | hardcoded-asset-name: Line 168: asset name "BGV26_DedupeScope" is hardcoded —... | Review and address | 10 |
| 38 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 39 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 40 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_GSuite_ServiceAccount_Creden... | Review and address | 10 |
| 41 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_BirthdaysCalendarName" for u... | Review and address | 10 |
| 42 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_TimeZone" for ui:GetAsset.As... | Review and address | 10 |
| 43 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailStyleSpec" for ui:GetAs... | Review and address | 10 |
| 44 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailWordCountMin" for ui:Ge... | Review and address | 10 |
| 45 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailWordCountMax" for ui:Ge... | Review and address | 10 |
| 46 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_AllowActionCenterFallback" f... | Review and address | 10 |
| 47 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_GmailFromConnectionName" for... | Review and address | 10 |
| 48 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_DedupeScope" for ui:GetAsset... | Review and address | 10 |

### KillAllProcesses.xaml (4 items, ~45 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 49 | High | Workflow Stub | Entire workflow `KillAllProcesses.xaml` replaced with Studio-openable stub | Fix XML structure in KillAllProcesses.xaml — [xml-wellformedness] XML parse e... | 15 |
| 50 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "chrome" for ui:KillProcess.Process... | Review and address | 10 |
| 51 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "iexplore" for ui:KillProcess.Proce... | Review and address | 10 |
| 52 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "EXCEL" for ui:KillProcess.ProcessN... | Review and address | 10 |

### Main.xaml (1 item, ~15 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 53 | High | Workflow Stub | Entire workflow `Main.xaml` replaced with Studio-openable stub | TODO: Implement Main — review SDD for workflow requirements | 15 |

### ProcessBirthday.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 54 | High | Workflow Stub | Entire workflow `ProcessBirthday.xaml` replaced with Studio-openable stub | TODO: Implement ProcessBirthday — review SDD for workflow requirements | 15 |
| 55 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### Unknown.xaml (6 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 56 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 57 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 58 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 59 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 60 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 61 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |

### AgentInvocation_Stub.xaml (1 item, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 62 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |

### Process.xaml (25 items, ~265 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 63 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 64 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 65 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 66 | Low | Implementation Required | Contains 30 placeholder value(s) matching "\bTODO\b" [Developer Implementatio... | Implement in Studio | 10 |
| 67 | Low | Quality Warning | hardcoded-credential: Potential hardcoded credential detected (pattern: passw... | Review and address | 10 |
| 68 | Low | Quality Warning | invalid-type-argument: Line 70: x:TypeArguments="UiPath.Persistence.Activitie... | Review and address | 10 |
| 69 | Low | Quality Warning | hardcoded-retry-count: Line 124: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 70 | Low | Quality Warning | hardcoded-retry-count: Line 170: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 71 | Low | Quality Warning | hardcoded-retry-count: Line 446: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 72 | Low | Quality Warning | hardcoded-retry-count: Line 492: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 73 | Low | Quality Warning | hardcoded-retry-count: Line 538: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 74 | Low | Quality Warning | hardcoded-retry-interval: Line 124: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 75 | Low | Quality Warning | hardcoded-retry-interval: Line 170: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 76 | Low | Quality Warning | hardcoded-retry-interval: Line 446: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 77 | Low | Quality Warning | hardcoded-retry-interval: Line 492: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 78 | Low | Quality Warning | hardcoded-retry-interval: Line 538: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 79 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 90: Standalone "No" corrected to "False" in expressio... | Review and address | 10 |
| 80 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 109: Standalone "No" corrected to "False" in expressi... | Review and address | 10 |
| 81 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 214: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |
| 82 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 582: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |
| 83 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 84 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 85 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 86 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 87 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### orchestrator.xaml (1 item, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 88 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_AllowActionCenterFallback}... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Automate birthday greetings to friends and family

### PDD Summary

## 1. Executive Summary
The “birthday greetingsV26” project automates a daily personal workflow: at 8:00am, birthdays are checked in Google Calendar and a warm, funny, lightly sarcastic birthday email is sent from the user’s Gmail account. The current manual approach is simple but prone to missed sends when the user forgets. The to-be solution will run fully autonomously on unattended robots via UiPath Orchestrator Triggers, retrieve today’s birthday events from the built-in Google “Birthdays” calendar feed, resolve the recipient’s email address via Google Contacts (preferring “Personal” when multiple emails exist), generate a personalized message using UiPath native GenAI capabilities (no OpenAI/Azure OpenAI usage), send via the Gmail Integration Service connector for **ninemush@gmail.com**, and record a sent-log to prevent duplicates within the same day.

## 2. Process Scope
This automation is in scope to execute once per day at 8:00am and complete all birthday greetings for that same calendar date. It reads birthday events from the built-in Google “Birthdays” calendar feed (displayed as “Birthdays”), where each event title contains only the person’s full name. It then performs an exact-name lookup in Google Contacts to find a recipient email labeled “Personal” or “Home,” prioritizing “Personal.” If no valid email is found, the automation skips that person without further action.

The email is sent exclusively from the Gmail account connected in UiPath Integration Service as **Gmail – ninemush@gmail.com**. The content is AI-generated using UiPath native capabilities (UiPath GenAI Activities / Agents) and follows an approved default style specification (warm, funny, lightly sarcastic; no emojis; one short subject line; 40–90 words). Photo usage (e.g., Google Photos) and any relationship-based personalization are explicitly out of scope for this iteration.

## 3. As-Is Process Description

![As-Is Process Map](/api/ideas/fcbe5f6d-60a1-45f7-8c96-5df24f1173b0/process-...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Automation type: Hybrid (Workflow + Native GenAI), unattended-first, exception-only human-in-the-loop.**

- **Deterministic steps** (schedule, calendar read, exact contact lookup, email selection, dedupe, send, logging) are best implemented as **unattended workflow automation** for reliability and operability.
- **Generative step** (subject/body drafting in the approved default voice spec) is best implemented using **UiPath native GenAI capabilities** invoked from the workflow. This is not a “pure Agent” process because the core is deterministic and must be strongly governed (exact-match, dedupe, same-day rules).
- **Action Center** is included only for **edge cases** (draft validation failure, ambiguous contacts if exact name returns multiples) to keep the standard path fully autonomous while still preventing unsafe or incomplete sends.

### 1.2 High-level architecture (services used)
- **Orchestrator**
  - **Time-based Trigger**: daily at **08:00**.
  - **Unattended job execution** on available unattended slots (11).
  - **Assets** for configuration (calendar name/id, voice spec, validation thresholds).
  - **Monitoring & alerting hooks**: job state, custom logs, and failure notifications.
- **Integration Service**
  - **Gmail connector** to send email from **connection “ninemush@gmail.com” (ID: 0a0d5ee1-a1e8-477a-a943-58161e6f3272)**.
  - Rationale: connector-based sending is more stable and auditable than UI automation, and avoids custom HTTP per platform rule.
- **Google access**
  - Calendar + Contacts access in the PDD is via **UiPath GSuite Activities** (Google APIs).
  - Rationale: quick, stable, no UI; also avoids building/maintaining bespoke HTTP integrations.
- **Data Service**
  - Stores persistent **sent-log** and run trace data to enforce deduplication (**once per person per year**, and at minimum also same-day).
  - Rationale vs Orchestrator Queue:
    - **Queue** ...

**Automation Type:** hybrid
**Rationale:** The calendar/contact lookup + sending are deterministic and best as RPA, while drafting “warm/funny/sarcastic” unique messages is generative and best handled by a UiPath GenAI-powered agent step with guardrails and fallback.
**Feasibility Complexity:** medium
**Effort Estimate:** 1-2 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | 8am Daily Birthday Run Trigger | System | Orchestrator Triggers | start | — |
| 2 | Get Today’s Birthday Events (Built-in Birthdays Calendar) | System | Google Calendar (UiPath GSuite Activities) | task | — |
| 3 | Any birthdays today? | System | Google Calendar (UiPath GSuite Activities) | decision | — |
| 4 | No Birthdays Today End | System | Orchestrator | end | — |
| 5 | For Each Birthday Event: Normalize Full Name | System | Workflow | task | — |
| 6 | Exact Match Contact by Full Name | System | Google Contacts (UiPath GSuite Activities) | task | — |
| 7 | Personal/Home email available? | System | Google Contacts (UiPath GSuite Activities) | decision | — |
| 8 | Skip Person (No Email) | System | Workflow | task | — |
| 9 | Select Recipient Email (Prefer Personal) | System | Google Contacts (UiPath GSuite Activities) | task | — |
| 10 | Already Sent Today for This Person? | System | Data Service / Data Fabric | decision | — |
| 11 | Skip Duplicate Send | System | Workflow | task | — |
| 12 | Generate Birthday Email Draft (Your Voice) | System | UiPath Agents + UiPath GenAI Activities | agent-task | — |
| 13 | Draft Safe/Complete? (no sensitive content, has subject+body) | System | UiPath Agents | agent-decision | — |
| 14 | Create Human Review Task (Edge Case) | System | Action Center | task | — |
| 15 | Apply Approved/Edited Text from Action Center | System | Action Center | task | — |
| 16 | Send Birthday Email | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 17 | Send Birthday Email (Post-Review) | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 18 | Record Sent Log (name, email, date, messageId) | System | Data Service / Data Fabric | task | — |
| 19 | More birthday events remaining? | System | Workflow | decision | — |
| 20 | Process Next Event | System | Workflow | task | — |
| 21 | Birthday Batch Completed End | System | Orchestrator | end | — |
| 22 | Loop Back to Next Contact Lookup | System | Workflow | task | — |
| 23 | Merge Skips Back to Loop | System | Workflow | task | — |
| 24 | Merge Duplicate Skips Back to Loop | System | Workflow | task | — |
| 25 | Continue Loop | System | Workflow | task | — |
| 26 | Return to “More events remaining?” decision | System | Workflow | task | — |
| 27 | Loop to Contact Lookup | System | Workflow | task | — |
| 28 | Loop Connection | System | Workflow | task | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath GSuite Activities)
- Orchestrator
- Workflow
- Google Contacts (UiPath GSuite Activities)
- Data Service / Data Fabric
- UiPath Agents + UiPath GenAI Activities
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

### User Roles Involved

- System

### Decision Points (Process Map Topology)

**Any birthdays today?**
  - [No] → No Birthdays Today End
  - [Yes] → For Each Birthday Event: Normalize Full Name

**Personal/Home email available?**
  - [No] → Skip Person (No Email)
  - [Yes] → Select Recipient Email (Prefer Personal)

**Already Sent Today for This Person?**
  - [Yes] → Skip Duplicate Send
  - [No] → Generate Birthday Email Draft (Your Voice)

**More birthday events remaining?**
  - [Yes] → Process Next Event
  - [No] → Birthday Batch Completed End

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows or Portable |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Standard |
| Action Center | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.UIAutomation.Activities` |
| 3 | `UiPath.Persistence.Activities` |
| 4 | `UiPath.DataService.Activities` |
| 5 | `UiPath.Mail.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath GSuite Activities)
- Orchestrator
- Workflow
- Google Contacts (UiPath GSuite Activities)
- Data Service / Data Fabric
- UiPath Agents + UiPath GenAI Activities
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

## 7. Credential & Asset Inventory

**Total:** 1 activities (0 hardcoded, 1 variable-driven)

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[` | Unknown | — | `HandleHumanReview.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `HandleHumanReview.xaml` | 70 | GetAsset | `[` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 0 aligned, 10 SDD-only, 2 XAML-only

> **Warning:** 10 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 2 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `BGV26_GSuite_ServiceAccount_Credential` | credential | **SDD Only** | type: Credential, description: Credential for Google Workspace/GSuite Activities authentication (service identity) to read Google Calendar 'Birthdays' feed and Google Contacts. | — | — |
| 2 | `BGV26_BirthdaysCalendarName` | asset | **SDD Only** | type: Text, value: Birthdays, description: Display name of the built-in Google Calendar feed used as source for birthdays. | — | — |
| 3 | `BGV26_TimeZone` | asset | **SDD Only** | type: Text, value: America/New_York, description: Time zone used to compute 'today' for birthday event retrieval and deduplication. | — | — |
| 4 | `BGV26_EmailStyleSpec` | asset | **SDD Only** | type: Text, value: Write a warm, funny, lightly sarcastic birthday email. No emojis. Provide one short subject line and an email body of 40–90 words. Keep it appropriate for workplace/friends; no sensitive or offensive content., description: Default prompt/style specification passed to UiPath native GenAI generation. | — | — |
| 5 | `BGV26_EmailWordCountMin` | asset | **SDD Only** | type: Integer, value: 40, description: Minimum allowed word count for generated email body. | — | — |
| 6 | `BGV26_EmailWordCountMax` | asset | **SDD Only** | type: Integer, value: 90, description: Maximum allowed word count for generated email body. | — | — |
| 7 | `BGV26_AllowActionCenterFallback` | asset | **SDD Only** | type: Bool, value: true, description: If true, create an Action Center task when GenAI output fails validation or contact match is ambiguous. | — | — |
| 8 | `BGV26_GmailFromConnectionName` | asset | **SDD Only** | type: Text, value: ninemush@gmail.com, description: Integration Service Gmail connection name to be used for sending. | — | — |
| 9 | `BGV26_DedupeScope` | asset | **SDD Only** | type: Text, value: FullName+SendDate, description: Deduplication key scope for sent-log checks. | — | — |
| 10 | `[` | asset | **XAML Only** | — | `HandleHumanReview.xaml` | 70 |
| 11 | `birthdayGreetingsV26_Exceptions` | queue | **SDD Only** | maxRetries: 2, uniqueReference: true, description: Queue for non-blocking exceptions and reprocessing items (e.g., ambiguous contact match, transient integration failures) for birthday greetings run. | — | — |
| 12 | `[in_QueueName]` | queue | **XAML Only** | — | `GetTransactionData.xaml` | 62 |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### Queues to Provision

| # | Queue Name | Activities | Unique Reference | Auto Retry | SLA | Action |
|---|-----------|------------|-----------------|------------|-----|--------|
| 1 | `[in_QueueName]` | GetTransactionItem | Recommended | Yes (3x) | — | Verify exists |

### SDD-Defined Queues (Not Yet in XAML)

| # | Queue Name | Unique Reference | Max Retries | SLA | Note |
|---|-----------|-----------------|-------------|-----|------|
| 1 | `birthdayGreetingsV26_Exceptions` | Yes | 2x | — | Defined in SDD but no matching XAML activity — verify implementation |

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | No |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

> **Note:** This is a Performer process — a separate Dispatcher process is needed to populate the queue.

## 10. Exception Handling Coverage

**Coverage:** 4/8 high-risk activities inside TryCatch (50%)

### Files Without TryCatch

- `GetBirthdays.xaml`
- `ProcessBirthday.xaml`
- `GenerateDraft.xaml`
- `Finalize.xaml`
- `InitAllSettings.xaml`
- `GetTransactionData.xaml`
- `KillAllProcesses.xaml`
- `AgentInvocation_Stub.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `GetTransactionData.xaml:62` | Get Queue Item |
| 2 | `GetTransactionData.xaml:63` | ui:GetTransactionItem |
| 3 | `SetTransactionStatus.xaml:67` | Set Success |
| 4 | `SetTransactionStatus.xaml:89` | Set Failed |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_BirthdayGreetingsV26_Daily_0800 | SDD-specified: TRG_BirthdayGreetingsV26_Daily_0800 | Cron: 0 0 8 ? * * * | Runs the birthdayGreetingsV26 job daily at 08:00. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| hardcoded-credential | warning | 1 | Potential hardcoded credential detected (pattern: password\s*[:=]\s*["'](?!\[)[^...) |
| placeholder-value | warning | 3 | Contains 30 placeholder value(s) matching "\bTODO\b" [Developer Implementation Required] |
| undeclared-asset | warning | 1 | Asset "{type:literal,value:BGV26_AllowActionCenterFallback}" is referenced in XAML but not declared in orchestrator arti... |
| invalid-activity-property | warning | 2 | Line 295: property "Condition" is not a known property of ui:ShouldRetry |
| invalid-type-argument | warning | 1 | Line 70: x:TypeArguments="UiPath.Persistence.Activities.FormTask" may not be a valid .NET type |
| unguarded-array-index | warning | 1 | Line 149: array indexing ".Rows(N)" without a preceding row count check — may throw IndexOutOfRangeException at runtime |
| hardcoded-retry-count | warning | 8 | Line 250: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| hardcoded-retry-interval | warning | 11 | Line 203: retry interval hardcoded as "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:10&quot;}" — ... |
| hardcoded-asset-name | warning | 10 | Line 70: asset name "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_AllowActionCenterFallback&quot;... |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 5 | Line 378: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption i... |
| EXPRESSION_SYNTAX | warning | 6 | Line 133: Unbalanced parentheses: 0 open vs 1 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imb... |
| BARE_TOKEN_QUOTED | warning | 14 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |
| RETRY_INTERVAL_DEFAULTED | warning | 7 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Assets | Provision asset: `[` | Yes |
| 5 | Queues | Create queue: `[in_QueueName]` | Yes |
| 6 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 7 | Testing | Run smoke test in target environment | Yes |
| 8 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 9 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 10 | Governance | Peer code review completed | Yes |
| 11 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 12 | Governance | Business process owner validation obtained | Yes |
| 13 | Governance | CoE approval obtained | Yes |
| 14 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Not Ready — 34/50 (39%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 4/10 | 50% coverage — consider wrapping remaining activities; 8 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | Queue configuration looks good |
| Build Quality | 0/10 | 70 quality warnings — significant remediation needed; 18 remediations — stub replacements need developer attention; 13/14 workflow(s) are Studio-loadable (1 blocked — 7% not loadable) |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Action Required:** Address the items above before deploying to production. Focus on sections with the lowest scores first.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 88 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 652 | 652 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 6200 | 2840 | 0 | 0 | 0 | 3360 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 14999 | 11082 | 0 | 3520 | 0 | 397 |
| executable-path-validator | Yes | 364 | 324 | 0 | 0 | 0 | 40 |
| post-emission-dependency-analyzer | Yes | 10 | 10 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "GetTransactionData.xaml",
    "SetTransactionStatus.xaml",
    "CloseAllApplications.xaml",
    "AgentInvocation_Stub.xaml"
  ],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "Process.xaml",
      "description": "Stripped 32 placeholder token(s) from Process.xaml",
      "developerAction": "Review Process.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "AgentInvocation_Stub.xaml",
      "description": "Stripped 1 placeholder token(s) from AgentInvocation_Stub.xaml",
      "developerAction": "Review AgentInvocation_Stub.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (fallback): Moved ucs:BuildDataTable.DataTable from attribute to child-element in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (fallback): Moved ucs:BuildDataTable.Columns from attribute to child-element in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (fallback): Moved ugs:GoogleCalendarGetEvents.Events from attribute to child-element in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (fallback): Moved Throw.Exception from attribute to child-element in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (fallback): Moved ForEach.Values from attribute to child-element in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (fallback): Moved ucs:AddDataRow.DataTable from attribute to child-element in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (fallback): Moved ucs:AddDataRow.ArrayRow from attribute to child-element in GetBirthdays.xaml"
    }
  ],
  "remediations": [
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 588, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 586, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement Main — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ProcessBirthday.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 252, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 250, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement ProcessBirthday — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Finalize.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 253: ugs:GmailSendMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Finalize.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 315: umail:SendSmtpMailMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 451: umail:SendSmtpMailMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 497: umail:SendSmtpMailMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 76, col 186 (code: InvalidAttr): Attribute 'Settings\"]\"' has no space in starting.",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in InitAllSettings.xaml — [xml-wellformedness] XML parse error at line 76, col 186 (code: InvalidAttr): Attribute 'Settings\"]\"' has no space in starting.",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "KillAllProcesses.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 58, col 160 (code: InvalidAttr): Attribute 'chrome\"]\"' has no space in starting.",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in KillAllProcesses.xaml — [xml-wellformedness] XML parse error at line 58, col 160 (code: InvalidAttr): Attribute 'chrome\"]\"' has no space in starting.",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "GetBirthdays.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 322: attribute Message contains raw quote character mid-value; [malformed-quote] Line 551: attribute Message contains raw quote character mid-value",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in GetBirthdays.xaml — [malformed-quote] Line 322: attribute Message contains raw quote character mid-value; [malformed-quote] Line 551: attribute Message contains raw quote character mid-value",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "GenerateDraft.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 69: attribute Message contains raw quote character mid-value; [malformed-quote] Line 75: attribute Message contains raw quote character mid-value; [malformed-quote] Line 124: attribute Message contains raw quote character mid-value; [malformed-quote] Line 177: attribute Message contains raw quote character mid-value; [malformed-quote] Line 178: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 230: attribute Message contains raw quote character mid-value; [malformed-quote] Line 231: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 244: attribute Message contains raw quote character mid-value; [malformed-quote] Line 245: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 259: attribute Message contains raw quote character mid-value; [malformed-quote] Line 272: attribute Message contains raw quote character mid-value; [malformed-quote] Line 274: attribute Message contains raw quote character mid-value",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in GenerateDraft.xaml — [malformed-quote] Line 69: attribute Message contains raw quote character mid-value; [malformed-quote] Line 75: attribute Message contains raw quote character mid-value; [malformed-quote] Line 124: attribute Message contains raw quote character mid-value; [malformed-quote] Line 177: attribute Message contains raw quote character mid-value; [malformed-quote] Line 178: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 230: attribute Message contains raw quote character mid-value; [malformed-quote] Line 231: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 244: attribute Message contains raw quote character mid-value; [malformed-quote] Line 245: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 259: attribute Message contains raw quote character mid-value; [malformed-quote] Line 272: attribute Message contains raw quote character mid-value; [malformed-quote] Line 274: attribute Message contains raw quote character mid-value",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "Finalize.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 97: attribute Filter contains raw quote character mid-value",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in Finalize.xaml — [malformed-quote] Line 97: attribute Filter contains raw quote character mid-value",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "HandleHumanReview.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "hardcoded-credential",
      "file": "Process.xaml",
      "detail": "Potential hardcoded credential detected (pattern: password\\s*[:=]\\s*[\"'](?!\\[)[^...)",
      "severity": "warning"
    },
    {
      "check": "placeholder-value",
      "file": "Process.xaml",
      "detail": "Contains 30 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "AgentInvocation_Stub.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ProcessBirthday.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_AllowActionCenterFallback}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "GetBirthdays.xaml",
      "detail": "Line 295: property \"Condition\" is not a known property of ui:ShouldRetry",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "GenerateDraft.xaml",
      "detail": "Line 258: property \"Condition\" is not a known property of ui:ShouldRetry",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "Process.xaml",
      "detail": "Line 70: x:TypeArguments=\"UiPath.Persistence.Activities.FormTask\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "unguarded-array-index",
      "file": "Finalize.xaml",
      "detail": "Line 149: array indexing \".Rows(N)\" without a preceding row count check — may throw IndexOutOfRangeException at runtime",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "GetBirthdays.xaml",
      "detail": "Line 250: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GetBirthdays.xaml",
      "detail": "Line 203: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:10&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GetBirthdays.xaml",
      "detail": "Line 250: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GenerateDraft.xaml",
      "detail": "Line 79: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:10&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 146: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 198: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 146: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 198: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 70: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_AllowActionCenterFallback&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Finalize.xaml",
      "detail": "Line 159: retry interval hardcoded as \"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;TimeSpan.FromSeconds(5)&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 124: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 170: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 446: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 492: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 538: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 124: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 170: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 446: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 492: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 538: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 100: asset name \"BGV26_GSuite_ServiceAccount_Credential\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 105: asset name \"BGV26_BirthdaysCalendarName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 114: asset name \"BGV26_TimeZone\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 123: asset name \"BGV26_EmailStyleSpec\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 132: asset name \"BGV26_EmailWordCountMin\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 141: asset name \"BGV26_EmailWordCountMax\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 150: asset name \"BGV26_AllowActionCenterFallback\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 159: asset name \"BGV26_GmailFromConnectionName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 168: asset name \"BGV26_DedupeScope\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GetBirthdays.xaml",
      "detail": "Line 378: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(calendarE...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GenerateDraft.xaml",
      "detail": "Line 325: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationMe...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 133: Unbalanced parentheses: 0 open vs 1 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imbalance near position 204, fragment: \"&amp; InFullName) &amp; \\\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(isContent...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 141: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;{\\&qu...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 367: Unbalanced parentheses: 0 open vs 1 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imbalance near position 204, fragment: \", InProposedSubject)&quot;}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.Is...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "Finalize.xaml",
      "detail": "Line 91: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;BGV26...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "Finalize.xaml",
      "detail": "Line 149: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(queriedRu...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 90: Standalone \"No\" corrected to \"False\" in expression: No",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 109: Standalone \"No\" corrected to \"False\" in expression: No",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 214: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 582: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_GSuite_ServiceAccount_Credential\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_BirthdaysCalendarName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_TimeZone\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailStyleSpec\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailWordCountMin\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailWordCountMax\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_AllowActionCenterFallback\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_GmailFromConnectionName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_DedupeScope\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"chrome\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"iexplore\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"EXCEL\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "HandleHumanReview.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "HandleHumanReview.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 205,
  "studioCompatibility": [
    {
      "file": "GetBirthdays.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "GenerateDraft.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "HandleHumanReview.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Finalize.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "Process.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "GetTransactionData.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "SetTransactionStatus.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CloseAllApplications.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "KillAllProcesses.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "Init.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "AgentInvocation_Stub.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "ProcessBirthday.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetBirthdays",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ProcessBirthday",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GenerateDraft",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "HandleHumanReview",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Finalize",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process.xaml",
      "targetWorkflow": "AgentInvocation_Stub",
      "targetDeclaredArguments": [
        "in_AgentName",
        "in_InputData",
        "out_AgentResult",
        "out_DecisionResult"
      ],
      "providedBindings": {
        "Nothing": "[str_AgentOutput]"
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_AgentName",
        "in_InputData",
        "in_AgentName",
        "in_InputData"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process.xaml",
      "targetWorkflow": "AgentInvocation_Stub",
      "targetDeclaredArguments": [
        "in_AgentName",
        "in_InputData",
        "out_AgentResult",
        "out_DecisionResult"
      ],
      "providedBindings": {
        "Nothing": "[bool_AgentDecisionResult]"
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_AgentName",
        "in_InputData",
        "in_AgentName",
        "in_InputData"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications.xaml",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "d6793669e31410227db9fa2d9de4421faaaf57555e82b08ccb4c67b1dd556959",
      "postRepair": "d6793669e31410227db9fa2d9de4421faaaf57555e82b08ccb4c67b1dd556959",
      "postNormalization": "b6a0f4c1ed11eec69a852d1cd38acc0ed2a2f77d0fff8ecd11a9c1b8c3aeddc2",
      "preCanonicalization": "b6a0f4c1ed11eec69a852d1cd38acc0ed2a2f77d0fff8ecd11a9c1b8c3aeddc2",
      "archivedFile": "82b473f624ac441b0d478991e2c0070363cefe867cb1c7679a27d029bfdcadea",
      "postFinalValidationInput": "82b473f624ac441b0d478991e2c0070363cefe867cb1c7679a27d029bfdcadea",
      "preArchive": "82b473f624ac441b0d478991e2c0070363cefe867cb1c7679a27d029bfdcadea"
    },
    {
      "workflowFile": "GetBirthdays.xaml",
      "postGeneration": "8c16421738399f152137816bc4e4c86072d4c913eae66e79f1b3cc192af4acc4",
      "postRepair": "8c16421738399f152137816bc4e4c86072d4c913eae66e79f1b3cc192af4acc4",
      "postNormalization": "8c16421738399f152137816bc4e4c86072d4c913eae66e79f1b3cc192af4acc4",
      "preCanonicalization": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
      "archivedFile": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
      "postFinalValidationInput": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
      "preArchive": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8"
    },
    {
      "workflowFile": "ProcessBirthday.xaml",
      "postGeneration": "be68945acec6b390be0ba5d0f1fc791247179a09677f02f12a053950206f711a",
      "postRepair": "be68945acec6b390be0ba5d0f1fc791247179a09677f02f12a053950206f711a",
      "postNormalization": "8b31ecf5e55e17182735399e04e5f6e1ac831ef7c9b5df99944ad9f289bcf61b",
      "preCanonicalization": "8b31ecf5e55e17182735399e04e5f6e1ac831ef7c9b5df99944ad9f289bcf61b",
      "archivedFile": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "postFinalValidationInput": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "preArchive": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0"
    },
    {
      "workflowFile": "GenerateDraft.xaml",
      "postGeneration": "bbb7ee24d6660927ed63dce947019608716ed4ab8ba19a49d04cb55f0bbc2111",
      "postRepair": "bbb7ee24d6660927ed63dce947019608716ed4ab8ba19a49d04cb55f0bbc2111",
      "postNormalization": "bbb7ee24d6660927ed63dce947019608716ed4ab8ba19a49d04cb55f0bbc2111",
      "preCanonicalization": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
      "archivedFile": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
      "postFinalValidationInput": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
      "preArchive": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619"
    },
    {
      "workflowFile": "HandleHumanReview.xaml",
      "postGeneration": "112ad77db43817121fe814f8fa86201c4e55a40e762209ce6b71c9e85f4c4e75",
      "postRepair": "112ad77db43817121fe814f8fa86201c4e55a40e762209ce6b71c9e85f4c4e75",
      "postNormalization": "112ad77db43817121fe814f8fa86201c4e55a40e762209ce6b71c9e85f4c4e75",
      "preCanonicalization": "5d82ec7581fedbf851e7919444e4769e60ee9eba627bcc1f1a89db814ad60e2b",
      "archivedFile": "db61960446f5ec9da80c178b9ab00b2465f942d09a9e0796ff57f317a4a677e4",
      "postFinalValidationInput": "db61960446f5ec9da80c178b9ab00b2465f942d09a9e0796ff57f317a4a677e4",
      "preArchive": "db61960446f5ec9da80c178b9ab00b2465f942d09a9e0796ff57f317a4a677e4"
    },
    {
      "workflowFile": "Finalize.xaml",
      "postGeneration": "0562675a44800ad1fc471792cc7926309521afd84e10d40c4633ff94ab338816",
      "postRepair": "0562675a44800ad1fc471792cc7926309521afd84e10d40c4633ff94ab338816",
      "postNormalization": "0562675a44800ad1fc471792cc7926309521afd84e10d40c4633ff94ab338816",
      "preCanonicalization": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "archivedFile": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "postFinalValidationInput": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "preArchive": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c"
    },
    {
      "workflowFile": "Process.xaml",
      "postGeneration": "74d21f9c6ed3f3074e0e461e972343f58f9b31cc9858e7d585261b9b8f3f508c",
      "postRepair": "74d21f9c6ed3f3074e0e461e972343f58f9b31cc9858e7d585261b9b8f3f508c",
      "postNormalization": "74d21f9c6ed3f3074e0e461e972343f58f9b31cc9858e7d585261b9b8f3f508c",
      "preCanonicalization": "b0aad71262da7126d423dd1fb72b252755ae903b09d7d1c1df1e15878f697c36",
      "archivedFile": "de0c2e87627784b9f4cc8e28102759f7af8cc2dfc899fed656ef7225be8a34f6",
      "postFinalValidationInput": "de0c2e87627784b9f4cc8e28102759f7af8cc2dfc899fed656ef7225be8a34f6",
      "preArchive": "de0c2e87627784b9f4cc8e28102759f7af8cc2dfc899fed656ef7225be8a34f6"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "postRepair": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "postNormalization": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "preCanonicalization": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
      "archivedFile": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
      "postFinalValidationInput": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
      "preArchive": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6"
    },
    {
      "workflowFile": "KillAllProcesses.xaml",
      "postGeneration": "35ed46a8fe50eed39e7bedb3d903663018c4aa5e1d503ad537c42ce2ced5f4b5",
      "postRepair": "35ed46a8fe50eed39e7bedb3d903663018c4aa5e1d503ad537c42ce2ced5f4b5",
      "postNormalization": "35ed46a8fe50eed39e7bedb3d903663018c4aa5e1d503ad537c42ce2ced5f4b5",
      "preCanonicalization": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
      "archivedFile": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
      "postFinalValidationInput": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
      "preArchive": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878"
    },
    {
      "workflowFile": "Init.xaml",
      "postGeneration": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "postRepair": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "postNormalization": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "preCanonicalization": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "archivedFile": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "postFinalValidationInput": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "preArchive": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741"
    },
    {
      "workflowFile": "AgentInvocation_Stub.xaml",
      "postGeneration": "1ab25d7751f64ffc740db6d7b8f0efeba0144d7b5753315417db00cee0cd2630",
      "postRepair": "1ab25d7751f64ffc740db6d7b8f0efeba0144d7b5753315417db00cee0cd2630",
      "postNormalization": "1ab25d7751f64ffc740db6d7b8f0efeba0144d7b5753315417db00cee0cd2630",
      "preCanonicalization": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "archivedFile": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "postFinalValidationInput": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "preArchive": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  },
  "invokeSerializationFixes": [
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] ENTER | ReviewType=\\&quot; &amp; InReviewType &amp; \\&quot; | RunId=\\&quot; &amp; InRunId &amp; \\&quot; |\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] ENTER | ReviewType=\" & InReviewType & \" | RunId=\" & InRunId & \" | FullName=\" & InFullName & \" | SentLogId=\" & InSentLogId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] WARN | Action Center fallback disabled by asset BGV26_AllowActionCenterFallback. Setting decision=Rejecte\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] WARN | Action Center fallback disabled by asset BGV26_AllowActionCenterFallback. Setting decision=Rejected for FullName=\" & InFullName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] INFO | Creating Action Center task | Catalog=\\&quot; &amp; taskCatalog &amp; \\&quot; | Title=\\&quot; &amp\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] INFO | Creating Action Center task | Catalog=\" & taskCatalog & \" | Title=\" & taskTitle & \" | SentLogId=\" & InSentLogId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] INFO | Action Center task created | TaskId=\\&quot; &amp; taskId &amp; \\&quot; | FullName=\\&quot; &amp; In\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] INFO | Action Center task created | TaskId=\" & taskId & \" | FullName=\" & InFullName & \" | RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] INFO | Suspending workflow to wait for Action Center task completion | TaskId=\\&quot; &amp; taskId &amp; \"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] INFO | Suspending workflow to wait for Action Center task completion | TaskId=\" & taskId & \" | SLA=6h | FullName=\" & InFullName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] INFO | Resumed from Action Center | TaskId=\\&quot; &amp; taskId &amp; \\&quot; | FullName=\\&quot; &amp; In\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] INFO | Resumed from Action Center | TaskId=\" & taskId & \" | FullName=\" & InFullName & \" | RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] INFO | Reviewer decision received | Decision=\\&quot; &amp; approvalDecision &amp; \\&quot; | TaskId=\\&quot\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] INFO | Reviewer decision received | Decision=\" & approvalDecision & \" | TaskId=\" & taskId & \" | FullName=\" & InFullName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] WARN | Reviewer rejected or skipped task | Decision=\\&quot; &amp; approvalDecision &amp; \\&quot; | Commen\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] WARN | Reviewer rejected or skipped task | Decision=\" & approvalDecision & \" | Comments=\" & reviewerComments & \" | FullName=\" & InFullName & \" | RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] INFO | ContentReview approved | Subject=\\&quot; &amp; approvedSubject &amp; \\&quot; | BodyWordCount=\\&quo\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] INFO | ContentReview approved | Subject=\" & approvedSubject & \" | BodyWordCount=\" & approvedBody.Split(\" \"c).Length.ToString() & \" | FullName=\" & InFullName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] INFO | ContactDisambiguation resolved | SelectedEmail=\\&quot; &amp; selectedEmail &amp; \\&quot; | FullNam\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] INFO | ContactDisambiguation resolved | SelectedEmail=\" & selectedEmail & \" | FullName=\" & InFullName & \" | RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;allowActionCenterStr&quot;}\"",
      "canonicalizedForm": "Value=\"[allowActionCenterStr]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskData&quot;}\"",
      "canonicalizedForm": "Result=\"[taskData]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "upers:WaitForFormTaskAndResume",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    }
  ],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_Config",
      "offendingExpression": "io_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_Config\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_QueueName",
      "offendingExpression": "in_QueueName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_QueueName\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionItem",
      "offendingExpression": "out_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_TransactionNumber",
      "offendingExpression": "io_TransactionNumber",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_TransactionNumber\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "allowActionCenterStr",
      "offendingExpression": "[allowActionCenterStr]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"allowActionCenterStr\" referenced in Value but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskCatalog",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | Creating Action Center task | Catalog=&quot; &amp; taskCatalog &amp; &quot; | Title=&quot; &amp; taskTitle &amp; &quot; | SentLogId=&quot; &amp; InSentLogId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskCatalog\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskTitle",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | Creating Action Center task | Catalog=&quot; &amp; taskCatalog &amp; &quot; | Title=&quot; &amp; taskTitle &amp; &quot; | SentLogId=&quot; &amp; InSentLogId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskTitle\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskId",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | Action Center task created | TaskId=&quot; &amp; taskId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | RunId=&quot; &amp; InRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskId",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | Suspending workflow to wait for Action Center task completion | TaskId=&quot; &amp; taskId &amp; &quot; | SLA=6h | FullName=&quot; &amp; InFullName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "upers:WaitForFormTaskAndResume",
      "propertyName": "Result",
      "referencedSymbol": "taskData",
      "offendingExpression": "[taskData]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"taskData\" referenced in Result but not declared in workflow \"HandleHumanReview\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskId",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | Resumed from Action Center | TaskId=&quot; &amp; taskId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | RunId=&quot; &amp; InRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "approvalDecision",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | Reviewer decision received | Decision=&quot; &amp; approvalDecision &amp; &quot; | TaskId=&quot; &amp; taskId &amp; &quot; | FullName=&quot; &amp; InFullName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"approvalDecision\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskId",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | Reviewer decision received | Decision=&quot; &amp; approvalDecision &amp; &quot; | TaskId=&quot; &amp; taskId &amp; &quot; | FullName=&quot; &amp; InFullName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "approvalDecision",
      "offendingExpression": "[&quot;[HandleHumanReview] WARN | Reviewer rejected or skipped task | Decision=&quot; &amp; approvalDecision &amp; &quot; | Comments=&quot; &amp; reviewerComments &amp; &quot; | FullName=&quot; &amp; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"approvalDecision\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "reviewerComments",
      "offendingExpression": "[&quot;[HandleHumanReview] WARN | Reviewer rejected or skipped task | Decision=&quot; &amp; approvalDecision &amp; &quot; | Comments=&quot; &amp; reviewerComments &amp; &quot; | FullName=&quot; &amp; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"reviewerComments\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "approvedSubject",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | ContentReview approved | Subject=&quot; &amp; approvedSubject &amp; &quot; | BodyWordCount=&quot; &amp; approvedBody.Split(&quot; &quot;c).Length.ToString() &amp; &qu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"approvedSubject\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "approvedBody",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | ContentReview approved | Subject=&quot; &amp; approvedSubject &amp; &quot; | BodyWordCount=&quot; &amp; approvedBody.Split(&quot; &quot;c).Length.ToString() &amp; &qu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"approvedBody\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "selectedEmail",
      "offendingExpression": "[&quot;[HandleHumanReview] INFO | ContactDisambiguation resolved | SelectedEmail=&quot; &amp; selectedEmail &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | RunId=&quot; &amp; InRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"selectedEmail\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "Rejected",
      "offendingExpression": "[Rejected]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Rejected\" referenced in child element <Assign.Value> but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "Rejected",
      "offendingExpression": "[Rejected]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Rejected\" referenced in child element <Assign.Value> but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "No",
      "offendingExpression": "[No]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"No\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "No",
      "offendingExpression": "[No]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"No\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_AgentName",
      "offendingExpression": "in_AgentName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_AgentName\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_InputData",
      "offendingExpression": "in_InputData",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_InputData\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_AgentResult",
      "offendingExpression": "out_AgentResult",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_AgentResult\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_AgentName",
      "offendingExpression": "in_AgentName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_AgentName\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_InputData",
      "offendingExpression": "in_InputData",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_InputData\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_DecisionResult",
      "offendingExpression": "out_DecisionResult",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_DecisionResult\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Init.xaml",
      "workflow": "Init",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_Config",
      "offendingExpression": "out_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_Config\" referenced in Key but not declared in workflow \"Init\" — expression replaced with \"Nothing\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 36 symbol scope defect(s), 4 sentinel replacement(s), 29 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ProcessBirthday — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;allowActionCenter&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;approvalDecision&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;Rejected\\&quot;&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;selectedEmail&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;\\&quot;&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    }
  ],
  "sentinelReplacements": [
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ProcessBirthday — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: ProcessBirthday — this workflow was auto-generated as a placeholder\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "umail:SendSmtpMailMessage",
      "propertyName": "To",
      "originalValue": "TODO: Set recipient email",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "todo_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"TODO: Set recipient email\" in executable property To replaced with platform-safe value \"Nothing\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "umail:SendSmtpMailMessage",
      "propertyName": "To",
      "originalValue": "TODO: Set recipient email",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "todo_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"TODO: Set recipient email\" in executable property To replaced with platform-safe value \"Nothing\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "umail:SendSmtpMailMessage",
      "propertyName": "To",
      "originalValue": "TODO: Set recipient email",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "todo_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"TODO: Set recipient email\" in executable property To replaced with platform-safe value \"Nothing\" — not executable, degradation substitute"
    }
  ],
  "unresolvableJsonDefects": [
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;allowActionCenter&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvalDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isContentReview&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskCatalog&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskDataJson&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskLinkJson&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvalDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewerComments&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedSubject&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedBody&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;selectedEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedSubject&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedBody&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;selectedEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvalDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;Boolean.Parse(If(String.IsNullOrWhiteSpace(allowActionCenterStr), \\&quot;True\\&quot;, allowActionCenterStr))&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Equals(InReviewType, \\&quot;ContentReview\\&quot;, StringComparison.OrdinalIgnoreCase)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(isContentReview, \\&quot;BGV26 Content Review: \\&quot; &amp; InFullName, \\&quot;BGV26 Contact Disambiguation: \\&quot; &amp; InFul",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(isContentReview, \\&quot;AC_BirthdayGreetingsV26_HumanReview\\&quot;, \\&quot;AC_BirthdayGreetingsV26_HumanReview\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;{\\&quot; &amp; \\&quot;\\\\\\&quot;RunId\\\\\\&quot;:\\\\\\&quot;\\&quot; &amp; InRunId &amp; \\&quot;\\\\\\&quot;,\\&quot; &amp; \\&quot;\\\\\\",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskObject IsNot Nothing, taskObject.ToString(), \\&quot;UNKNOWN\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;{\\\\\\&quot;ActionCenterTaskId\\\\\\&quot;:\\\\\\&quot;\\&quot; &amp; taskId &amp; \\&quot;\\\\\\&quot;,\\\\\\&quot;ReviewType\\\\\\&quot;:\\\\\\&",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskData IsNot Nothing, taskData.ToString(), \\&quot;Rejected\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskData IsNot Nothing, \\&quot;ReviewerComments from task\\&quot;, \\&quot;No comments - task may have expired\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrWhiteSpace(InProposedSubject), \\&quot;Happy Birthday \\&quot; &amp; InFullName &amp; \\&quot;!\\&quot;, InProposedSu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrWhiteSpace(InProposedBody), \\&quot;Wishing you a wonderful birthday!\\&quot;, InProposedBody)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrWhiteSpace(InRecipientEmail), \\&quot;\\&quot;, InRecipientEmail)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    }
  ],
  "requiredPropertyBindings": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initializing BirthdayGreetingsV26 ===&quot;]",
      "resolvedValue": "[&quot;=== Initializing BirthdayGreetingsV26 ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initializing BirthdayGreetingsV26 ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Init.xaml",
      "resolvedValue": "Init.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Init.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_SystemReady]",
      "resolvedValue": "[bool_SystemReady]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_SystemReady",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization complete&quot;]",
      "resolvedValue": "[&quot;Initialization complete&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization complete&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetTransactionData.xaml",
      "resolvedValue": "GetTransactionData.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetTransactionData.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Process.xaml",
      "resolvedValue": "Process.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Process.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryNumber]",
      "resolvedValue": "[int_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryNumber",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "0",
      "resolvedValue": "0",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "0",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetBirthdays.xaml",
      "resolvedValue": "GetBirthdays.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetBirthdays.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ProcessBirthday.xaml",
      "resolvedValue": "ProcessBirthday.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ProcessBirthday.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GenerateDraft.xaml",
      "resolvedValue": "GenerateDraft.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GenerateDraft.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "HandleHumanReview.xaml",
      "resolvedValue": "HandleHumanReview.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "HandleHumanReview.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Finalize.xaml",
      "resolvedValue": "Finalize.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Finalize.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "resolvedValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; Da",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "resolvedValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== BirthdayGreetingsV26 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "resolvedValue": "[&quot;=== BirthdayGreetingsV26 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== BirthdayGreetingsV26 Complete. Transactions processed: &quot; &amp; i",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: GetBirthdays — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: GetBirthdays — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: GetBirthdays — Final validation remediation — original XAML had wel",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetBirthdays ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetBirthdays ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetBirthdays ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateDraft.xaml",
      "workflow": "GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: GenerateDraft — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: GenerateDraft — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: GenerateDraft — Final validation remediation — original XAML had we",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateDraft.xaml",
      "workflow": "GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GenerateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GenerateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GenerateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[HandleHumanReview] ENTER | ReviewType=&quot; &amp; InReviewType &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | SentLogId=&quot; &amp; InSentLogId]",
      "resolvedValue": "[&quot;[HandleHumanReview] ENTER | ReviewType=&quot; &amp; InReviewType &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | SentLogId=&quot; &amp; InSentLogId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[HandleHumanReview] ENTER | ReviewType=&quot; &amp; InReviewType &amp; &q",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read BGV26_AllowActionCenterFallback asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read BGV26_AllowActionCenterFallback asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read BGV26_AllowActionCenterFallback asset failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;allowActionCenter&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;allowActionCenter&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;allowActionCent",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Guard: if Action Center fallback is disabled, log and set Rejected decision&quot;]",
      "resolvedValue": "[&quot;Then path: Guard: if Action Center fallback is disabled, log and set Rejected decision&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Guard: if Action Center fallback is disabled, log and set Reje",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Guard: if Action Center fallback is disabled, log and set Rejected decision&quot;]",
      "resolvedValue": "[&quot;Else path: Guard: if Action Center fallback is disabled, log and set Rejected decision&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Guard: if Action Center fallback is disabled, log and set Reje",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[HandleHumanReview] WARN | Action Center fallback disabled by asset BGV26_AllowActionCenterFallback. Setting decision=Rejected for FullName=&quot; &amp; InFullName]",
      "resolvedValue": "[&quot;[HandleHumanReview] WARN | Action Center fallback disabled by asset BGV26_AllowActionCenterFallback. Setting decision=Rejected for FullName=&quot; &amp; InFullName]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[HandleHumanReview] WARN | Action Center fallback disabled by asset BGV26",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "AC_BirthdayGreetingsV26_HumanReview",
      "resolvedValue": "AC_BirthdayGreetingsV26_HumanReview",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "AC_BirthdayGreetingsV26_HumanReview",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Create Action Center Form Task (ContentReview or ContactDisambiguation), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Create Action Center Form Task (ContentReview or ContactDisambiguation), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Create Action Center Form Task (ContentReview or Cont",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Create Action Center Form Task (ContentReview or ContactDisambiguation) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Create Action Center Form Task (ContentReview or ContactDisambiguation) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Create Action Center Form Task (ContentReview or Contac",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "BGV26_SentLog",
      "resolvedValue": "BGV26_SentLog",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGV26_SentLog",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObject&quot;}",
      "resolvedValue": "[sentLogUpdateObject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObjec",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Update BGV26_SentLog record with ActionCenter task linkage and PendingReview status, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Update BGV26_SentLog record with ActionCenter task linkage and PendingReview status, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Update BGV26_SentLog record with ActionCenter task li",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Update BGV26_SentLog record with ActionCenter task linkage and PendingReview status failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Update BGV26_SentLog record with ActionCenter task linkage and PendingReview status failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Update BGV26_SentLog record with ActionCenter task link",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Suspend and wait for reviewer to complete the Action Center task failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Suspend and wait for reviewer to complete the Action Center task failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Suspend and wait for reviewer to complete the Action Center task ",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;approvalDecision&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;Rejected\\&quot;&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;approvalDecision&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;Rejected\\&quot;&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;approvalDecisio",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on reviewer decision: Approve / EditAndApprove / SelectEmailAndContinue vs Reject / Skip / Expired&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on reviewer decision: Approve / EditAndApprove / SelectEmailAndContinue vs Reject / Skip / Expired&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on reviewer decision: Approve / EditAndApprove / Select",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on reviewer decision: Approve / EditAndApprove / SelectEmailAndContinue vs Reject / Skip / Expired&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on reviewer decision: Approve / EditAndApprove / SelectEmailAndContinue vs Reject / Skip / Expired&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on reviewer decision: Approve / EditAndApprove / Select",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[]",
      "resolvedValue": "[]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[]",
      "resolvedValue": "[]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[]",
      "resolvedValue": "[]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "BGV26_SentLog",
      "resolvedValue": "BGV26_SentLog",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGV26_SentLog",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObject&quot;}",
      "resolvedValue": "[sentLogUpdateObject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObjec",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update BGV26_SentLog status to Rejected in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update BGV26_SentLog status to Rejected in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update BGV26_SentLog status to Rejected in Data Service failed (&",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on review type for approved path: ContentReview extracts subject+body; ContactDisambiguation extracts email&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on review type for approved path: ContentReview extracts subject+body; ContactDisambiguation extracts email&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on review type for approved path: ContentReview extract",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on review type for approved path: ContentReview extracts subject+body; ContactDisambiguation extracts email&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on review type for approved path: ContentReview extracts subject+body; ContactDisambiguation extracts email&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on review type for approved path: ContentReview extract",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;selectedEmail&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;\\&quot;&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;selectedEmail&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;\\&quot;&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;selectedEmail&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate selected email is not empty on disambiguation approval&quot;]",
      "resolvedValue": "[&quot;Then path: Validate selected email is not empty on disambiguation approval&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate selected email is not empty on disambiguation approva",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate selected email is not empty on disambiguation approval&quot;]",
      "resolvedValue": "[&quot;Else path: Validate selected email is not empty on disambiguation approval&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate selected email is not empty on disambiguation approva",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: Finalize — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: Finalize — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: Finalize — Final validation remediation — original XAML had well-fo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Finalize ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Finalize ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Finalize ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization: 8am Daily Birthday Run Trigger&quot;]",
      "resolvedValue": "[&quot;Initialization: 8am Daily Birthday Run Trigger&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization: 8am Daily Birthday Run Trigger&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Get Today’s Birthday Events (Built-in Birthdays Calendar)",
      "resolvedValue": "Executing: Get Today’s Birthday Events (Built-in Birthdays Calendar)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Get Today’s Birthday Events (Built-in Birthdays Calendar)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "resolvedValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: For Each Birthday Event: Normalize Full Name",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: No Birthdays Today End",
      "resolvedValue": "Executing: No Birthdays Today End",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: No Birthdays Today End",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "resolvedValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: For Each Birthday Event: Normalize Full Name",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Exact Match Contact by Full Name",
      "resolvedValue": "Executing: Exact Match Contact by Full Name",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Exact Match Contact by Full Name",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Skip Person (No Email), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Skip Person (No Email), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Skip Person (No Email), screenshot captured&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Skip Person (No Email) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Skip Person (No Email) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Skip Person (No Email) failed after retries — &quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Select Recipient Email (Prefer Personal), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Select Recipient Email (Prefer Personal), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Select Recipient Email (Prefer Personal), screenshot ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Select Recipient Email (Prefer Personal) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Select Recipient Email (Prefer Personal) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Select Recipient Email (Prefer Personal) failed after r",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Skip Duplicate Send",
      "resolvedValue": "Executing: Skip Duplicate Send",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Skip Duplicate Send",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Skip Duplicate Send",
      "resolvedValue": "Executing: Skip Duplicate Send",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Skip Duplicate Send",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Invoking agent for: Generate Birthday Email Draft (Your Voice)&quot;]",
      "resolvedValue": "[&quot;Invoking agent for: Generate Birthday Email Draft (Your Voice)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Invoking agent for: Generate Birthday Email Draft (Your Voice)&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "AgentInvocation_Stub.xaml",
      "resolvedValue": "AgentInvocation_Stub.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "AgentInvocation_Stub.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_AgentOutput]",
      "resolvedValue": "[str_AgentOutput]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AgentOutput",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AgentOutput]",
      "resolvedValue": "[str_AgentOutput]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AgentOutput",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Agent completed: Generate Birthday Email Draft (Your Voice)&quot;]",
      "resolvedValue": "[&quot;Agent completed: Generate Birthday Email Draft (Your Voice)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Agent completed: Generate Birthday Email Draft (Your Voice)&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Generate Birthday Email Draft (Your Voice) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Generate Birthday Email Draft (Your Voice) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Generate Birthday Email Draft (Your Voice) failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Invoking agent decision for: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "resolvedValue": "[&quot;Invoking agent decision for: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Invoking agent decision for: Draft Safe/Complete? (no sensitive content, ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "AgentInvocation_Stub.xaml",
      "resolvedValue": "AgentInvocation_Stub.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "AgentInvocation_Stub.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_AgentDecisionResult]",
      "resolvedValue": "[bool_AgentDecisionResult]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_AgentDecisionResult",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set email subject",
      "resolvedValue": "TODO: Set email subject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set email subject",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Body",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_EmailBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_EmailBody",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set SMTP server",
      "resolvedValue": "TODO: Set SMTP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set SMTP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Agent decision completed: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "resolvedValue": "[&quot;Agent decision completed: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Agent decision completed: Draft Safe/Complete? (no sensitive content, has",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Draft Safe/Complete? (no sensitive content, has subject+body) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Draft Safe/Complete? (no sensitive content, has subject+body) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Draft Safe/Complete? (no sensitive content, has subject+body) fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create Human Review Task (Edge Case) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create Human Review Task (Edge Case) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create Human Review Task (Edge Case) failed (&quot; &amp; excepti",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Apply Approved/Edited Text from Action Center failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Apply Approved/Edited Text from Action Center failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Apply Approved/Edited Text from Action Center failed (&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set email subject",
      "resolvedValue": "TODO: Set email subject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set email subject",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Body",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_EmailBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_EmailBody",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set SMTP server",
      "resolvedValue": "TODO: Set SMTP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set SMTP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Send Birthday Email, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Send Birthday Email, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Send Birthday Email, screenshot captured&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Send Birthday Email failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Send Birthday Email failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Send Birthday Email failed after retries — &quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set email subject",
      "resolvedValue": "TODO: Set email subject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set email subject",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Body",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_EmailBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_EmailBody",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set SMTP server",
      "resolvedValue": "TODO: Set SMTP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set SMTP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Send Birthday Email (Post-Review), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Send Birthday Email (Post-Review), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Send Birthday Email (Post-Review), screenshot capture",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Send Birthday Email (Post-Review) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Send Birthday Email (Post-Review) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Send Birthday Email (Post-Review) failed after retries ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Record Sent Log (name, email, date, messageId), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Record Sent Log (name, email, date, messageId), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Record Sent Log (name, email, date, messageId), scree",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Record Sent Log (name, email, date, messageId) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Record Sent Log (name, email, date, messageId) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Record Sent Log (name, email, date, messageId) failed a",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Process Next Event",
      "resolvedValue": "Executing: Process Next Event",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Process Next Event",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Birthday Batch Completed End",
      "resolvedValue": "Executing: Birthday Batch Completed End",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Birthday Batch Completed End",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Process Next Event",
      "resolvedValue": "Executing: Process Next Event",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Process Next Event",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Loop Back to Next Contact Lookup",
      "resolvedValue": "Executing: Loop Back to Next Contact Lookup",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Loop Back to Next Contact Lookup",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Merge Skips Back to Loop",
      "resolvedValue": "Executing: Merge Skips Back to Loop",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 44,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Merge Skips Back to Loop",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Merge Duplicate Skips Back to Loop",
      "resolvedValue": "Executing: Merge Duplicate Skips Back to Loop",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 45,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Merge Duplicate Skips Back to Loop",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Continue Loop",
      "resolvedValue": "Executing: Continue Loop",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 46,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Continue Loop",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Return to “More events remaining?” decision",
      "resolvedValue": "Executing: Return to “More events remaining?” decision",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 47,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Return to “More events remaining?” decision",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Loop to Contact Lookup",
      "resolvedValue": "Executing: Loop to Contact Lookup",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 48,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Loop to Contact Lookup",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Loop Connection",
      "resolvedValue": "Executing: Loop Connection",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 49,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Loop Connection",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: No Birthdays Today End&quot;]",
      "resolvedValue": "[&quot;Completed: No Birthdays Today End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 50,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: No Birthdays Today End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Birthday Batch Completed End&quot;]",
      "resolvedValue": "[&quot;Completed: Birthday Batch Completed End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 51,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Birthday Batch Completed End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 52,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: InitAllSettings — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: InitAllSettings — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: InitAllSettings — Final validation remediation — original XAML had ",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[out_TransactionItem IsNot Nothing]",
      "resolvedValue": "[out_TransactionItem IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[out_TransactionItem IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_TransactionNumber",
        "sourceWorkflow": "GetTransactionData",
        "precedenceTier": 1
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber + 1]",
      "resolvedValue": "[io_TransactionNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "resolvedValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;No more transactions in queue&quot;]",
      "resolvedValue": "[&quot;No more transactions in queue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;No more transactions in queue&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetTransactionData ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_Status = &quot;Successful&quot;]",
      "resolvedValue": "[in_Status = &quot;Successful&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_Status = &quot;Successful&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "resolvedValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "resolvedValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Closing all applications...&quot;]",
      "resolvedValue": "[&quot;Closing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Closing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications closed&quot;]",
      "resolvedValue": "[&quot;All applications closed&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications closed&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "resolvedValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "KillAllProcesses.xaml",
      "resolvedValue": "KillAllProcesses.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "KillAllProcesses.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "resolvedValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: KillAllProcesses — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: KillAllProcesses — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: KillAllProcesses — Final validation remediation — original XAML had",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Started ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Started ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Started ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_Config]",
      "resolvedValue": "[io_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 1
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Complete ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Complete ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Complete ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "AgentInvocation_Stub.xaml",
      "workflow": "AgentInvocation_Stub",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: AgentInvocation_Stub ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: AgentInvocation_Stub ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: AgentInvocation_Stub ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObject&quot;}",
      "resolvedValue": "[sentLogUpdateObject]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObject&quot;}",
      "resolvedValue": "[sentLogUpdateObject]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 1
    }
  ],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "214 required property binding(s) resolved; 30 unresolved required property defect(s); 3 structured expression(s) lowered; 30 invalid generic substitution(s) blocked",
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "b6a0f4c1ed11eec69a852d1cd38acc0ed2a2f77d0fff8ecd11a9c1b8c3aeddc2",
      "canonicalizedHash": "82b473f624ac441b0d478991e2c0070363cefe867cb1c7679a27d029bfdcadea",
      "archivedHash": "82b473f624ac441b0d478991e2c0070363cefe867cb1c7679a27d029bfdcadea",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GetBirthdays.xaml",
      "preCanonicalizationHash": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
      "canonicalizedHash": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
      "archivedHash": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
      "identical": true,
      "mutated": false
    },
    {
      "file": "ProcessBirthday.xaml",
      "preCanonicalizationHash": "8b31ecf5e55e17182735399e04e5f6e1ac831ef7c9b5df99944ad9f289bcf61b",
      "canonicalizedHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "archivedHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GenerateDraft.xaml",
      "preCanonicalizationHash": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
      "canonicalizedHash": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
      "archivedHash": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
      "identical": true,
      "mutated": false
    },
    {
      "file": "HandleHumanReview.xaml",
      "preCanonicalizationHash": "5d82ec7581fedbf851e7919444e4769e60ee9eba627bcc1f1a89db814ad60e2b",
      "canonicalizedHash": "db61960446f5ec9da80c178b9ab00b2465f942d09a9e0796ff57f317a4a677e4",
      "archivedHash": "db61960446f5ec9da80c178b9ab00b2465f942d09a9e0796ff57f317a4a677e4",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Finalize.xaml",
      "preCanonicalizationHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "canonicalizedHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "archivedHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Process.xaml",
      "preCanonicalizationHash": "b0aad71262da7126d423dd1fb72b252755ae903b09d7d1c1df1e15878f697c36",
      "canonicalizedHash": "de0c2e87627784b9f4cc8e28102759f7af8cc2dfc899fed656ef7225be8a34f6",
      "archivedHash": "de0c2e87627784b9f4cc8e28102759f7af8cc2dfc899fed656ef7225be8a34f6",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
      "canonicalizedHash": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
      "archivedHash": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
      "identical": true,
      "mutated": false
    },
    {
      "file": "GetTransactionData.xaml",
      "preCanonicalizationHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
      "canonicalizedHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
      "archivedHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
      "identical": true,
      "mutated": false
    },
    {
      "file": "SetTransactionStatus.xaml",
      "preCanonicalizationHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "canonicalizedHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "archivedHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "identical": true,
      "mutated": false
    },
    {
      "file": "CloseAllApplications.xaml",
      "preCanonicalizationHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "canonicalizedHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "archivedHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "identical": true,
      "mutated": false
    },
    {
      "file": "KillAllProcesses.xaml",
      "preCanonicalizationHash": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
      "canonicalizedHash": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
      "archivedHash": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Init.xaml",
      "preCanonicalizationHash": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "canonicalizedHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "archivedHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "identical": true,
      "mutated": true
    },
    {
      "file": "AgentInvocation_Stub.xaml",
      "preCanonicalizationHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "canonicalizedHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "archivedHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "identical": true,
      "mutated": false
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "HandleHumanReview.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "AgentInvocation_Stub.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
        "allowed": true,
        "reason": "Workflow \"AgentInvocation_Stub.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Finalize.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
        "allowed": true,
        "reason": "Workflow \"Finalize.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GenerateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
        "allowed": true,
        "reason": "Workflow \"GenerateDraft.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
        "allowed": true,
        "reason": "Workflow \"GetBirthdays.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "HandleHumanReview.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "db61960446f5ec9da80c178b9ab00b2465f942d09a9e0796ff57f317a4a677e4",
        "allowed": true,
        "reason": "Workflow \"HandleHumanReview.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "82b473f624ac441b0d478991e2c0070363cefe867cb1c7679a27d029bfdcadea",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "de0c2e87627784b9f4cc8e28102759f7af8cc2dfc899fed656ef7225be8a34f6",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessBirthday.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
        "allowed": true,
        "reason": "Workflow \"ProcessBirthday.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "AgentInvocation_Stub.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "Finalize.xaml": 1,
      "GenerateDraft.xaml": 1,
      "GetBirthdays.xaml": 1,
      "GetTransactionData.xaml": 1,
      "HandleHumanReview.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "ProcessBirthday.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 14,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 14,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "AgentInvocation_Stub.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
        "allowed": true,
        "reason": "Workflow \"AgentInvocation_Stub.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Finalize.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
        "allowed": true,
        "reason": "Workflow \"Finalize.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GenerateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "633b3861605c681032ac0640966e74f1f5c081c652f5210b3e53fce713b99619",
        "allowed": true,
        "reason": "Workflow \"GenerateDraft.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c8c132973de10f27476d5e0db9943db17e346acc759f893dd3b39a0dc55f72e8",
        "allowed": true,
        "reason": "Workflow \"GetBirthdays.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "HandleHumanReview.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "db61960446f5ec9da80c178b9ab00b2465f942d09a9e0796ff57f317a4a677e4",
        "allowed": true,
        "reason": "Workflow \"HandleHumanReview.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fce9ff53c88a22323e588f164e7c59d8dc1c9d88f7a6d52c18e9affc107806d6",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f85bc88e0889adc6584e67341b0431d998456ffb9a3efe7eca145d5f63582878",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "82b473f624ac441b0d478991e2c0070363cefe867cb1c7679a27d029bfdcadea",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "de0c2e87627784b9f4cc8e28102759f7af8cc2dfc899fed656ef7225be8a34f6",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessBirthday.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
        "allowed": true,
        "reason": "Workflow \"ProcessBirthday.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "AgentInvocation_Stub.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "Finalize.xaml": 1,
      "GenerateDraft.xaml": 1,
      "GetBirthdays.xaml": 1,
      "GetTransactionData.xaml": 1,
      "HandleHumanReview.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "ProcessBirthday.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 14,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 14,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 652,
        "approved": 652,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 6200,
        "approved": 2840,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 3360
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 14999,
        "approved": 11082,
        "deprecated": 0,
        "nonEmissionApproved": 3520,
        "targetIncompatible": 0,
        "unknown": 397
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 364,
        "approved": 324,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 40
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 10,
        "approved": 10,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
