# Diagnostic Summary

## Run Metadata
- **Run ID:** 74f1b525-d77e-4131-862a-445e6571ab71
- **Idea ID:** fcbe5f6d-60a1-45f7-8c96-5df24f1173b0
- **Status:** completed_with_warnings
- **Generation Mode:** baseline_openable
- **Triggered By:** chat
- **Created At:** Sat Apr 04 2026 16:12:06 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Sat Apr 04 2026 16:17:06 GMT+0000 (Coordinated Universal Time)
- **Duration:** 300.0s

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 21 |
| pipeline_sdd_validation | succeeded | 20 |
| spec_generation | succeeded | 237480 |
| spec_context_loading | succeeded | 5 |
| spec_prompt_assembly | succeeded | 3 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 36339 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 0 |
| spec_handoff | succeeded | 0 |
| build_pipeline | succeeded | 62450 |
| pipeline_build_pipeline | succeeded | 62450 |
| pipeline_decomposition | succeeded | 4 |
| pipeline_pre_complexity_estimation | succeeded | 0 |
| pipeline_workflow_budget_check | succeeded | 0 |
| pipeline_complexity_classification | succeeded | 0 |
| pipeline_xaml_emission | succeeded | 3134 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 16 |
| pipeline_validation | succeeded | 52912 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 274 |
| pipeline_packaging_dhg_guide | succeeded | 48 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_complete | succeeded | 0 |

## LLM Call Summary

| Stage | Model | Duration (ms) | Input Tokens | Output Tokens | Status |
|-------|-------|--------------|-------------|--------------|--------|
| iterative_correction:GetBirthdays:round_1 | gpt-5.2 | 26391 | 6877 | 0 | success |
| iterative_correction:GenerateDraft:round_1 | gpt-5.2 | 26300 | 8006 | 0 | success |

**Totals:** 2 calls, 14883 input tokens, 0 output tokens, 52.7s total LLM time

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 21 |
| workflow_analyzer_autofix | 14 |
| activity_policy_filter | 6 |
| expression_lint | 2 |
| required_property_enforcement | 6 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 6
- **Total Warnings:** 21
- **Completeness:** structural

## Meta-Validation Summary

- **Engaged:** true
- **Mode:** Always
- **Corrections Applied:** 0
- **Corrections Skipped:** 2
- **Corrections Failed:** 0
- **Confidence Score:** 0.4411764705882353
- **Duration:** 49ms

## Remediations

- {"level":"workflow","file":"Main.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 588, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 586, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement Main — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"ProcessBirthday.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 252, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 250, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement ProcessBirthday — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Finalize.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 253: ugs:GmailSendMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Finalize.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 315: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 451: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 497: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 76, col 186 (code: InvalidAttr): Attribute 'Settings\"]\"' has no space in starting.","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in InitAllSettings.xaml — [xml-wellformedness] XML parse error at line 76, col 186 (code: InvalidAttr): Attribute 'Settings\"]\"' has no space in starting.","estimatedEffortMinutes":15}
- {"level":"workflow","file":"KillAllProcesses.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 58, col 160 (code: InvalidAttr): Attribute 'chrome\"]\"' has no space in starting.","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in KillAllProcesses.xaml — [xml-wellformedness] XML parse error at line 58, col 160 (code: InvalidAttr): Attribute 'chrome\"]\"' has no space in starting.","estimatedEffortMinutes":15}
- {"level":"workflow","file":"GetBirthdays.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 322: attribute Message contains raw quote character mid-value; [malformed-quote] Line 551: attribute Message contains raw quote character mid-value","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in GetBirthdays.xaml — [malformed-quote] Line 322: attribute Message contains raw quote character mid-value; [malformed-quote] Line 551: attribute Message contains raw quote character mid-value","estimatedEffortMinutes":15}
- {"level":"workflow","file":"GenerateDraft.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 69: attribute Message contains raw quote character mid-value; [malformed-quote] Line 75: attribute Message contains raw quote character mid-value; [malformed-quote] Line 124: attribute Message contains raw quote character mid-value; [malformed-quote] Line 177: attribute Message contains raw quote character mid-value; [malformed-quote] Line 178: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 230: attribute Message contains raw quote character mid-value; [malformed-quote] Line 231: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 244: attribute Message contains raw quote character mid-value; [malformed-quote] Line 245: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 259: attribute Message contains raw quote character mid-value; [malformed-quote] Line 272: attribute Message contains raw quote character mid-value; [malformed-quote] Line 274: attribute Message contains raw quote character mid-value","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in GenerateDraft.xaml — [malformed-quote] Line 69: attribute Message contains raw quote character mid-value; [malformed-quote] Line 75: attribute Message contains raw quote character mid-value; [malformed-quote] Line 124: attribute Message contains raw quote character mid-value; [malformed-quote] Line 177: attribute Message contains raw quote character mid-value; [malformed-quote] Line 178: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 230: attribute Message contains raw quote character mid-value; [malformed-quote] Line 231: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 244: attribute Message contains raw quote character mid-value; [malformed-quote] Line 245: attribute Exception contains raw quote character mid-value; [malformed-quote] Line 259: attribute Message contains raw quote character mid-value; [malformed-quote] Line 272: attribute Message contains raw quote character mid-value; [malformed-quote] Line 274: attribute Message contains raw quote character mid-value","estimatedEffortMinutes":15}
- {"level":"workflow","file":"Finalize.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 97: attribute Filter contains raw quote character mid-value","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in Finalize.xaml — [malformed-quote] Line 97: attribute Filter contains raw quote character mid-value","estimatedEffortMinutes":15}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"workflow","file":"HandleHumanReview.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"Process.xaml","description":"Stripped 32 placeholder token(s) from Process.xaml","developerAction":"Review Process.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"AgentInvocation_Stub.xaml","description":"Stripped 1 placeholder token(s) from AgentInvocation_Stub.xaml","developerAction":"Review AgentInvocation_Stub.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (fallback): Moved ucs:BuildDataTable.DataTable from attribute to child-element in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (fallback): Moved ucs:BuildDataTable.Columns from attribute to child-element in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (fallback): Moved ugs:GoogleCalendarGetEvents.Events from attribute to child-element in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (fallback): Moved Throw.Exception from attribute to child-element in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (fallback): Moved ForEach.Values from attribute to child-element in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (fallback): Moved ucs:AddDataRow.DataTable from attribute to child-element in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (fallback): Moved ucs:AddDataRow.ArrayRow from attribute to child-element in GetBirthdays.xaml"}
