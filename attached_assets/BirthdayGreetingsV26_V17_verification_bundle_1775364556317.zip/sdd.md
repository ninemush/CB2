## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Automation type: Hybrid (Workflow + Native GenAI), unattended-first, exception-only human-in-the-loop.**

- **Deterministic steps** (schedule, calendar read, exact contact lookup, email selection, dedupe, send, logging) are best implemented as **unattended workflow automation** for reliability and operability.
- **Generative step** (subject/body drafting in the approved default voice spec) is best implemented using **UiPath native GenAI capabilities** invoked from the workflow. This is not a “pure Agent” process because the core is deterministic and must be strongly governed (exact-match, dedupe, same-day rules).
- **Action Center** is included only for **edge cases** (draft validation failure, ambiguous contacts if exact name returns multiples) to keep the standard path fully autonomous while still preventing unsafe or incomplete sends.

### 1.2 High-level architecture (services used)
- **Orchestrator**
  - **Time-based Trigger**: daily at **08:00**.
  - **Unattended job execution** on available unattended slots (11).
  - **Assets** for configuration (calendar name/id, voice spec, validation thresholds).
  - **Monitoring & alerting hooks**: job state, custom logs, and failure notifications.
- **Integration Service**
  - **Gmail connector** to send email from **connection “ninemush@gmail.com” (ID: 0a0d5ee1-a1e8-477a-a943-58161e6f3272)**.
  - Rationale: connector-based sending is more stable and auditable than UI automation, and avoids custom HTTP per platform rule.
- **Google access**
  - Calendar + Contacts access in the PDD is via **UiPath GSuite Activities** (Google APIs).
  - Rationale: quick, stable, no UI; also avoids building/maintaining bespoke HTTP integrations.
- **Data Service**
  - Stores persistent **sent-log** and run trace data to enforce deduplication (**once per person per year**, and at minimum also same-day).
  - Rationale vs Orchestrator Queue:
    - **Queue** is optimized for transactional work distribution and retries; this process is a daily batch with small volume and needs **queryable history** by person+year and linkage to Action Center tasks.
    - **Data Service** provides a schema, easy querying, and a clean audit trail for “already sent?” checks.
- **Action Center**
  - Human review tasks created only when needed (draft fails validation; ambiguous contact match).
  - Includes SLA, escalation, and structured form fields; outcomes persisted back to Data Service.
- **Storage Buckets**
  - Stores run artifacts (e.g., generated draft JSON, validation evidence, error screenshots) for troubleshooting and audit.
- **Test Manager**
  - Automated regression suite (mocked calendar/contacts, stubbed send) to prevent regressions and validate rules (exact match, personal-first, dedupe-per-year).
- **Maestro**
  - **Not required** for the base version (single scheduled batch, short-lived).
  - Optional later if you want a full “Birthday case lifecycle” with richer case views, manual interventions, and KPIs.

### 1.3 Deployment topology and licensing implications
- **Execution**: 100% **unattended**, no user session interaction.
- **Robot type**: standard unattended robots (not serverless assumed; design remains Modern-compatible where possible).
- **Licensing**: uses existing unattended capacity; Action Center usage is minimal (exception-only). Data Service and Storage Buckets store limited personal data (names/emails).

---

## 2. Process Components and Workflow Breakdown

### 2.1 Orchestrator process structure (new, non-conflicting names)
Create a new Orchestrator process name to avoid conflicts with existing deployments:
- **Main Process**: `BirthdayGreetingsV26_OrchestratorBatch`
- **Sub-process (optional)**: `BirthdayGreetingsV26_SendOneGreeting` (called as a library/workflow invoke within same project; not required as separate Orchestrator process unless you want reuse via queues/tools later)

### 2.2 Workflow components (REFramework-inspired, but right-sized)
This is a daily batch, low volume. Full REFramework is optional overhead; instead, implement a **lightweight dispatcher-performer pattern inside one process**:

1) **Init.xaml**
   - Read Orchestrator Assets
   - Initialize connections (GSuite auth context if used, Integration Service is connector-based)
   - Create Run record in Data Service (RunId, start time)

2) **GetBirthdays.xaml**
   - Read today’s birthday events from **built-in “Birthdays” feed**
   - Normalize event title → `FullNameNormalized`
   - Output list of “Work Items” (name + event metadata)

3) **ProcessBirthday.xaml** (loop over list)
   - Exact-match query in Google Contacts by full name
   - Select email: **Personal first**, else Home
   - **Dedup**: check Data Service if already sent for that person **in the current year** (and also block same-day reruns)
   - Draft generation (GenAI)
   - Validate draft
   - Send via Integration Service Gmail connector
   - Persist log (Data Service) + artifacts (Storage Bucket)

4) **Finalize.xaml**
   - Update Run record with totals + end time
   - Optionally send a daily summary email to self (same Gmail connector)

### 2.3 Human-in-the-loop steps (Action Center)

#### A) Task catalog: `BirthdayGreetingsV26_ContentReview`
Created when GenAI draft fails validation.
- **Trigger conditions**
  - Missing subject/body
  - Word count outside 40–90
  - Contains emojis (per spec)
  - Contains disallowed content markers (basic keyword rules)
- **Form schema (complete)**
  - `RunId` (String, read-only, required)
  - `FullName` (String, read-only, required)
  - `RecipientEmail` (String, read-only, required)
  - `ProposedSubject` (String, editable, required, max 120 chars)
  - `ProposedBody` (String, editable, required, max 1200 chars)
  - `ApprovalDecision` (Choice: `Approve`, `EditAndApprove`, `Reject`, required)
  - `ReviewerComments` (String, optional)
- **Validation rules**
  - If `ApprovalDecision` in (`Approve`,`EditAndApprove`) then `ProposedSubject` and `ProposedBody` required
  - Enforce no emojis (regex)
  - Enforce word count 40–90 (count words in body)
- **SLA**
  - Due: **6 hours** from creation (still “same day”)
  - Warning: 4 hours
  - Escalation: if overdue, notify via Gmail (to ninemush@gmail.com) and set `ApprovalDecision=Reject` after 23:30 local time (to avoid sending next day)

#### B) Task catalog: `BirthdayGreetingsV26_ContactDisambiguation`
Created when exact-match query returns multiple contacts with the same display name.
- **Form schema**
  - `RunId` (String, read-only, required)
  - `FullName` (String, read-only, required)
  - `CandidateContacts` (String, read-only, required) — formatted list
  - `SelectedRecipientEmail` (String, editable, required)
  - `Decision` (Choice: `SelectEmailAndContinue`, `Skip`, required)
  - `ReviewerComments` (String, optional)
- **SLA**
  - Due: 6 hours; warning at 4; same escalation approach as above.

### 2.4 How Action Center + Data Service work together
- Each Action Center task is created with the associated **Data Service record IDs**:
  - `BirthdayGreetingDraft` record (draft + status)
  - `BirthdaySentLog` record (planned send record in “PendingReview”)
- On completion, the workflow reads the task outcome and updates Data Service:
  - `DraftStatus` = Approved/Rejected
  - If approved: proceed to send and write final `MessageId`

---

## 3. UiPath Activities and Packages Required

> Package versions strictly follow the verified catalog list. If a capability is needed but not in the verified list, it is marked as “version not verified”.

### 3.1 Core packages
- **UiPath.System.Activities 26.2.4**
  - Log Message, Try/Catch, Rethrow, Delay, Read/Write Text File (local temp), etc.
- **UiPath.UIAutomation.Activities 25.10.29**
  - Take Screenshot (for error evidence, even though UI automation is not used)
- **UiPath.DataService.Activities 25.9.3**
  - Create Entity Record, Query Entity, Update Entity, Get Entity By Id
- **UiPath.GSuite.Activities 3.7.11**
  - Google Calendar read (via appropriate GSuite activities / Gmail message activities where applicable)
  - Google Contacts access (via GSuite package capabilities)
- **UiPath.IntegrationService.Activities — version not verified (not in verified catalog)**
  - Required to call Integration Service connector activities for Gmail connection `ninemush@gmail.com`

### 3.2 Mail package (only for fallback/notifications if needed)
- **UiPath.Mail.Activities 2.7.12**
  - Send Mail (used only for internal notifications if Integration Service send is unavailable; primary send is via Integration Service)

### 3.3 Action Center / Persistence
- **UiPath.Persistence.Activities — version not verified (not in verified catalog)**
  - Create Task, Wait for Task and Resume, Get Task, etc. (Action Center integration)

### 3.4 GenAI / Agents
- **UiPath GenAI Activities — version not verified (not in verified catalog)**
  - Generate Text / Chat Completions (native UiPath GenAI connection)
- **Agents tooling — version not verified (not in verified catalog)**
  - Agent invocation/bindings if implemented via Agent Builder; otherwise call GenAI directly from workflow.

---

## 4. Integration Points and API/System Connections

### 4.1 Google Calendar (Birthdays feed)
- **Method**: UiPath GSuite Activities (Google APIs), read-only.
- **Objects**: events for “today” from the built-in “Birthdays” calendar feed.
- **Key rule**: event title is treated as full name; normalize whitespace only; no fuzzy matching.

### 4.2 Google Contacts
- **Method**: UiPath GSuite Activities.
- **Lookup**: exact full name match.
- **Email selection**:
  - Prefer label **Personal**
  - Else label **Home**
  - Else skip

### 4.3 Gmail send (must use Integration Service connector)
- **Connector**: Gmail (Integration Service)
- **Connection name**: **ninemush@gmail.com**
- **Connection ID**: **0a0d5ee1-a1e8-477a-a943-58161e6f3272**
- **Operation**: Send email (subject + plain text body)
- **Return values**: capture `MessageId` and persist to Data Service.

### 4.4 Data Service (persistent storage)
- **Method**: UiPath.DataService.Activities 25.9.3
- **Operations**:
  - Query for dedupe: `FullNameNormalized + Year`
  - Create SentLog record after send (or create “PendingReview” before Action Center)
  - Update with `MessageId`, final text, status

### 4.5 Storage Buckets (run artifacts)
- Store:
  - Generated draft JSON (subject/body + validation metrics)
  - Error screenshots
  - Daily summary report (optional)
- Access method: Orchestrator Storage Bucket activities — **version not verified** (not in verified catalog)

---

## 5. Exception Handling Strategy

### 5.1 Business exceptions (handled, no retries)
- **No birthdays today** → end successfully.
- **No exact contact match** → skip person; log “Skipped_NoContact”.
- **No Personal/Home email** → skip person; log “Skipped_NoEligibleEmail”.
- **Already sent this year** (dedupe) → skip; log “Skipped_DedupeYear”.
- **Multiple exact-name contacts** → create Action Center task `BirthdayGreetingsV26_ContactDisambiguation`.
- **GenAI draft fails validation** → create Action Center task `BirthdayGreetingsV26_ContentReview`.

### 5.2 System exceptions (retries + fail fast where appropriate)
- Google API transient errors: retry 2–3 times with exponential backoff.
- Integration Service send failure: retry once; if still failing, mark record as “SendFailed” and fail job (so Orchestrator alerts).
- Data Service write failure: retry; if persistent, fail job (dedupe/audit correctness depends on it).

### 5.3 Observability and evidence
- Every catch block:
  - **Take Screenshot** (UiPath.UIAutomation.Activities 25.10.29) of desktop context (helps on classic robots; still captured on unattended sessions)
  - Write structured log fields: RunId, FullName, Step, ExceptionType, Message
  - Upload screenshot + context JSON to Storage Bucket

### 5.4 Dead-letter handling
- Any item that fails after send attempt but before log persistence is treated as critical:
  - Attempt immediate Data Service write retry
  - If unrecoverable: create Action Center task “Ops Review” (optional) and fail job to ensure investigation (prevents silent duplicates next run)

---

## 6. Security Considerations

- **Credentials**
  - Google auth handled via configured connections/scopes (GSuite activities + Integration Service connection).
  - No credentials stored in code.
- **Orchestrator Assets**
  - Store non-secret config in Text assets (calendar identifier/name, style prompt text, word count limits, timezone).
  - If any secret is needed later, use Orchestrator credential asset accessed via **UiPath.Credentials.Activities 3.0.0** (not required for current connector-based approach).
- **RBAC**
  - Limit who can edit the process, assets, and Data Service entities.
  - Action Center tasks assigned only to the SME (or a small reviewer group).
- **Data minimization**
  - Persist only what is needed: name, selected email, date/year, messageId, and optionally final sent subject/body (configurable).
- **Auditability**
  - Data Service provides immutable-ish audit via record history; Orchestrator logs provide run-level trace.

---

## 7. Test Strategy (with Test Manager)

### 7.1 Test levels
- **Unit tests (Studio)**: name normalization, email selection logic, validation rules (word count, emoji detection).
- **Integration tests**
  - Calendar read returns 0/1/many events.
  - Contacts query returns 0/1/many matches.
  - Gmail send mocked/stubbed where possible (or use a safe test recipient).
- **Regression suite (Test Manager)**
  - Scenarios:
    1) No birthdays → clean end
    2) Birthday + exact contact + Personal email → send + log
    3) Both Personal/Home → selects Personal
    4) No eligible email → skip
    5) Duplicate run same day/year → no second send
    6) GenAI draft invalid → Action Center → approved → send
    7) Multiple contacts → Action Center disambiguation

### 7.2 Test data strategy
- Use a controlled set of Contacts and a test calendar day where feasible.
- If production Birthdays feed cannot be safely manipulated, create a “test mode” asset to point to a controlled calendar (only enabled in non-prod).

---

## 7a. Governance Compliance
- **Naming conventions**
  - Processes, assets, entities, queues (if any) use `BirthdayGreetingsV26_*`.
- **Restricted activities**
  - No custom HTTP used for Gmail (Integration Service mandated).
- **Error handling**
  - Try/Catch around all external calls; screenshot-on-error; structured logging; no silent failures.
- **Data handling**
  - Minimal PII storage; restricted access to Data Service entities and Storage Buckets.

---

## 8. Data Model and Entity Design (Data Service)

### 8.1 Entity: `BGV26_Run`
Stores run-level metrics for operations.
- `RunId` (Text, required, unique)
- `StartTimeUtc` (DateTime, required)
- `EndTimeUtc` (DateTime, optional)
- `RunStatus` (Choice: Started, Completed, Failed, required)
- `BirthdaysFound` (Number, default 0)
- `SentCount` (Number, default 0)
- `SkippedCount` (Number, default 0)
- `ErrorCount` (Number, default 0)
- `OrchestratorJobKey` (Text, optional)

### 8.2 Entity: `BGV26_SentLog`
Primary dedupe/audit entity (dedupe **once per person per year**).
- `SentLogId` (Auto)
- `FullNameRaw` (Text, required)
- `FullNameNormalized` (Text, required)
- `RecipientEmail` (Text, required)
- `BirthDateObserved` (Date, optional) — if obtainable from event metadata; else null
- `GreetingYear` (Number, required) — e.g., 2026
- `SendDateLocal` (Date, required)
- `SendTimestampUtc` (DateTime, optional until sent)
- `Status` (Choice: PendingReview, ApprovedToSend, Sent, Skipped, SendFailed, Rejected, required)
- `SkipReason` (Choice: NoBirthdays, NoContact, NoEligibleEmail, DedupeYear, DuplicateRunSameDay, ReviewerRejected, Other; optional)
- `GmailMessageId` (Text, optional)
- `CalendarEventId` (Text, optional)
- `RunId` (Text, required; relationship by value to `BGV26_Run.RunId`)
- `FinalSubject` (Text, optional)
- `FinalBody` (Text, optional)

**Dedup query rule**: `FullNameNormalized == X AND GreetingYear == currentYear AND Status == Sent`.

### 8.3 Entity: `BGV26_Draft`
Stores drafts and validation results (linked to sent log).
- `DraftId` (Auto)
- `SentLogId` (Text/Reference, required) — if references supported; else store as Text foreign key
- `GeneratedSubject` (Text, required)
- `GeneratedBody` (Text, required)
- `WordCount` (Number, required)
- `ContainsEmoji` (Boolean, required)
- `ValidationStatus` (Choice: Passed, Failed, required)
- `ValidationNotes` (Text, optional)
- `ApprovedSubject` (Text, optional)
- `ApprovedBody` (Text, optional)
- `ReviewedBy` (Text, optional)
- `ReviewedAtUtc` (DateTime, optional)

---

## 8. Agent Architecture

> Agent use is intentionally constrained to the generative step; the workflow remains the system of record for rules (exact match, dedupe-per-year, same-day send, personal-first).

### 8.1 Agent Type
- **Autonomous agent** (invoked by the unattended workflow) for content generation + self-checking.

### 8.2 Agent Identity
- **Name**: `BGV26_EmailComposerAgent`
- **Purpose**: Generate a birthday email subject + body following the approved default style spec.
- **Behavioral system prompt (core)**
  - “You generate a warm, funny, lightly sarcastic birthday email. No emojis. Avoid sensitive topics. Output exactly: Subject line (short) and Body (40–90 words). Use only the provided person name. Do not invent personal facts.”

## 9. Orchestrator & Platform Deployment Specification

```orchestrator_artifacts
{
  "queues": [
    {
      "name": "birthdayGreetingsV26_Exceptions",
      "description": "Queue for non-blocking exceptions and reprocessing items (e.g., ambiguous contact match, transient integration failures) for birthday greetings run.",
      "maxRetries": 2,
      "uniqueReference": true
    }
  ],
  "assets": [
    {
      "name": "BGV26_GSuite_ServiceAccount_Credential",
      "type": "Credential",
      "value": "",
      "description": "Credential for Google Workspace/GSuite Activities authentication (service identity) to read Google Calendar 'Birthdays' feed and Google Contacts."
    },
    {
      "name": "BGV26_BirthdaysCalendarName",
      "type": "Text",
      "value": "Birthdays",
      "description": "Display name of the built-in Google Calendar feed used as source for birthdays."
    },
    {
      "name": "BGV26_TimeZone",
      "type": "Text",
      "value": "America/New_York",
      "description": "Time zone used to compute 'today' for birthday event retrieval and deduplication."
    },
    {
      "name": "BGV26_EmailStyleSpec",
      "type": "Text",
      "value": "Write a warm, funny, lightly sarcastic birthday email. No emojis. Provide one short subject line and an email body of 40–90 words. Keep it appropriate for workplace/friends; no sensitive or offensive content.",
      "description": "Default prompt/style specification passed to UiPath native GenAI generation."
    },
    {
      "name": "BGV26_EmailWordCountMin",
      "type": "Integer",
      "value": "40",
      "description": "Minimum allowed word count for generated email body."
    },
    {
      "name": "BGV26_EmailWordCountMax",
      "type": "Integer",
      "value": "90",
      "description": "Maximum allowed word count for generated email body."
    },
    {
      "name": "BGV26_AllowActionCenterFallback",
      "type": "Bool",
      "value": "true",
      "description": "If true, create an Action Center task when GenAI output fails validation or contact match is ambiguous."
    },
    {
      "name": "BGV26_GmailFromConnectionName",
      "type": "Text",
      "value": "ninemush@gmail.com",
      "description": "Integration Service Gmail connection name to be used for sending."
    },
    {
      "name": "BGV26_DedupeScope",
      "type": "Text",
      "value": "FullName+SendDate",
      "description": "Deduplication key scope for sent-log checks."
    }
  ],
  "machines": [
    {
      "name": "TMPL_Unattended_BirthdayGreetingsV26",
      "type": "Unattended",
      "slots": 1,
      "description": "Unattended machine template for daily scheduled execution of birthday greetings."
    }
  ],
  "triggers": [
    {
      "name": "TRG_BirthdayGreetingsV26_Daily_0800",
      "type": "Time",
      "cron": "0 0 8 ? * * *",
      "description": "Runs the birthdayGreetingsV26 job daily at 08:00."
    }
  ],
  "storageBuckets": [
    {
      "name": "SB_BirthdayGreetingsV26_Knowledge",
      "description": "Storage bucket for grounding content (e.g., approved tone/style spec, validation checklist, runbook snippets) referenced by the Agent configuration."
    }
  ],
  "environments": [
    {
      "name": "ENV_BirthdayGreetingsV26_Production",
      "type": "Production",
      "description": "Production environment for unattended execution of birthdayGreetingsV26."
    }
  ],
  "actionCenter": [
    {
      "taskCatalog": "AC_BirthdayGreetingsV26_HumanReview",
      "assignedRole": "BirthdayGreetings_Reviewer",
      "sla": "24 hours",
      "escalation": "If not completed within SLA, escalate to Orchestrator admins and hold sending for that recipient until resolved.",
      "description": "Human review/edit task for edge cases: GenAI draft validation failures or ambiguous contact match with multiple exact-name contacts."
    }
  ],
  "requirements": [
    {
      "name": "REQ-001: Daily unattended schedule at 08:00",
      "description": "Automation must run once per day at 8:00am via Orchestrator trigger and complete all greetings for that calendar date.",
      "source": "PDD Sections 1, 2, 4"
    },
    {
      "name": "REQ-002: Source birthdays only from built-in Google 'Birthdays' calendar",
      "description": "Retrieve today's birthday events from the built-in Google Calendar feed displayed as 'Birthdays'.",
      "source": "PDD Sections 2, 4, 8"
    },
    {
      "name": "REQ-003: Exact-name contact lookup and deterministic email selection",
      "description": "Perform an exact-match lookup in Google Contacts using the full name from the event title; choose email labeled 'Personal' first, else 'Home'; skip if neither exists.",
      "source": "PDD Sections 2, 4, 7"
    },
    {
      "name": "REQ-004: Same-day deduplication using persistent sent-log",
      "description": "Before sending, check a persistent sent-log in Data Service/Data Fabric; skip sending if already sent for same person on same date.",
      "source": "PDD Sections 4, 5, 8"
    },
    {
      "name": "REQ-005: Use UiPath native GenAI only (no OpenAI/Azure OpenAI usage)",
      "description": "Generate email subject and body using UiPath native GenAI capabilities/activities and approved style spec; do not use OpenAI/Azure OpenAI connectors.",
      "source": "PDD Sections 1, 2, 4, 6"
    },
    {
      "name": "REQ-006: Email content constraints",
      "description": "Generated email must be warm, funny, lightly sarcastic; no emojis; one short subject line; body 40–90 words; appropriate for sending.",
      "source": "PDD Sections 2, 4, 7"
    },
    {
      "name": "REQ-007: Send emails only via Integration Service Gmail connection ninemush@gmail.com",
      "description": "All emails must be sent via Integration Service Gmail connector using the 'ninemush@gmail.com' connection.",
      "source": "PDD Sections 1, 2, 4, 8"
    },
    {
      "name": "REQ-008: Human-in-the-loop for rare edge cases",
      "description": "If GenAI output fails validation or contact match is ambiguous, create an Action Center task and proceed only after approval/edits.",
      "source": "PDD Sections 4, 7"
    }
  ],
  "testCases": [
    {
      "name": "TC001 - No birthdays today",
      "description": "Validates that the job ends cleanly when there are no birthday events for today.",
      "steps": [
        {
          "action": "Run process on a date with no events in the 'Birthdays' calendar.",
          "expected": "Process completes successfully; no emails sent; no sent-log entries created."
        }
      ]
    },
    {
      "name": "TC002 - Single birthday, personal email available",
      "description": "Happy path: exact contact match and Personal email exists; generate and send email; log send.",
      "steps": [
        {
          "action": "Ensure one birthday event exists with title matching a Google Contact full name with a Personal email.",
          "expected": "Email sent via Gmail connection 'ninemush@gmail.com'; subject present; body 40–90 words; no emojis; sent-log entry created with messageId."
        }
      ]
    },
    {
      "name": "TC003 - Multiple emails; prefer Personal over Home",
      "description": "Ensures deterministic selection of Personal when multiple addresses exist.",
      "steps": [
        {
          "action": "Use a contact with both Personal and Home email labels for the same exact-name birthday event.",
          "expected": "Recipient email selected is the Personal email; email sent; log records selected email."
        }
      ]
    },
    {
      "name": "TC004 - Home email only",
      "description": "Sends to Home when Personal is missing but Home exists.",
      "steps": [
        {
          "action": "Use a contact with only Home email label for an exact-name birthday event.",
          "expected": "Recipient email selected is Home; email sent; log created."
        }
      ]
    },
    {
      "name": "TC005 - No Personal/Home email => skip",
      "description": "Skips sending when no suitable email label exists.",
      "steps": [
        {
          "action": "Use an exact-name contact with only Work/Other email labels (no Personal/Home).",
          "expected": "No email is sent for that person; no sent-log entry created; run continues for other birthdays."
        }
      ]
    },
    {
      "name": "TC006 - Same-day dedup prevents duplicates on rerun",
      "description": "Verifies that rerunning the job on same day does not resend to the same person.",
      "steps": [
        {
          "action": "Run process, confirm a sent-log entry exists for a person for today; rerun process the same day.",
          "expected": "Second run skips sending for that person and does not create an additional sent-log entry for same date."
        }
      ]
    },
    {
      "name": "TC007 - GenAI output fails validation => Action Center task",
      "description": "Creates human review task when draft missing subject/body or violates constraints; proceeds after approval.",
      "steps": [
        {
          "action": "Simulate/force a draft that fails validation (e.g., empty subject or body outside 40–90 words).",
          "expected": "Action Center task created in catalog AC_BirthdayGreetingsV26_HumanReview; upon completion, email is sent and logged."
        }
      ]
    },
    {
      "name": "TC008 - Ambiguous exact-name contact match => Action Center task",
      "description": "Handles multiple contacts with the same exact full name.",
      "steps": [
        {
          "action": "Create two Google Contacts with the same full name as the birthday event title, each with Personal/Home emails.",
          "expected": "Action Center task created requesting recipient resolution; after selection, email is sent to chosen address and logged."
        }
      ]
    }
  ],
  "testSets": [
    {
      "name": "Happy Path Tests",
      "description": "Core scenario validation for standard daily operation.",
      "testCaseNames": [
        "TC001 - No birthdays today",
        "TC002 - Single birthday, personal email available",
        "TC003 - Multiple emails; prefer Personal over Home",
        "TC004 - Home email only",
        "TC006 - Same-day dedup prevents duplicates on rerun"
      ]
    },
    {
      "name": "Exception Handling Tests",
      "description": "Validates edge cases and human-in-the-loop fallback behavior.",
      "testCaseNames": [
        "TC005 - No Personal/Home email => skip",
        "TC007 - GenAI output fails validation => Action Center task",
        "TC008 - Ambiguous exact-name contact match => Action Center task"
      ]
    }
  ],
  "agents": [
    {
      "name": "AG_BirthdayGreetingsV26_Composer",
      "agentType": "autonomous",
      "description": "Agent responsible for composing a compliant birthday email subject+body in the approved voice (warm, funny, lightly sarcastic) using UiPath native GenAI capabilities, and escalating to human review on validation failures.",
      "systemPrompt": "You generate birthday email drafts for a daily automation.\n\nHard constraints:\n- No emojis.\n- Output must include:\n  1) Subject: one short subject line.\n  2) Body: 40–90 words.\n- Tone: warm, funny, lightly sarcastic.\n- Keep content safe and appropriate (no offensive/explicit/sensitive content).\n- Do not mention policies, constraints, or that you are an AI.\n\nInputs you may receive:\n- FullName\n- Optional context: date, sender name\n\nReturn JSON with keys: subject, body.\nIf you cannot comply, return JSON with keys: needsReview=true, reason, suggestedSubject, suggestedBody.",
      "tools": [
        {
          "name": "ValidateDraftAndEscalate",
          "description": "Validates generated subject/body for presence, emoji-free, and word-count range; if invalid, requests human review.",
          "processReference": "birthday greetingsV26",
          "inputArguments": {
            "FullName": "String",
            "Subject": "String",
            "Body": "String"
          },
          "outputArguments": [
            "IsValid",
            "ValidationErrors",
            "ActionCenterTaskId"
          ]
        }
      ],
      "contextGrounding": {
        "storageBucket": "SB_BirthdayGreetingsV26_Knowledge",
        "documentSources": [
          "Approved style spec and validation checklist for birthday greetingsV26"
        ],
        "refreshStrategy": "on-change",
        "embeddingModel": "default"
      },
      "guardrails": [
        "No emojis under any circumstances.",
        "No hateful, sexual, violent, or sensitive personal data content.",
        "Body must be between 40 and 90 words."
      ],
      "escalationRules": [
        {
          "condition": "Generated output missing subject or body, contains emojis, violates word count, or otherwise deemed inappropriate by validation.",
          "target": "BirthdayGreetings_Reviewer",
          "actionCenterCatalog": "AC_BirthdayGreetingsV26_HumanReview",
          "priority": "High"
        }
      ],
      "maxIterations": 5,
      "temperature": 0.4
    }
  ],
  "maestroProcesses": [
    {
      "name": "Maestro_BirthdayGreetingsV26",
      "description": "End-to-end orchestration for daily birthday greeting run including optional human review through Action Center.",
      "serviceTasks": [
        {
          "name": "RunBirthdayGreetings",
          "processRef": "birthday greetingsV26",
          "description": "Runs the automation to fetch birthdays, resolve contacts, generate/send email, and log sends."
        }
      ],
      "userTasks": [
        {
          "name": "HumanReviewDraftOrRecipient",
          "actionCenterCatalog": "AC_BirthdayGreetingsV26_HumanReview",
          "assignee": "BirthdayGreetings_Reviewer",
          "description": "Review/edit GenAI draft or choose correct recipient when ambiguous, then approve for sending."
        }
      ],
      "gateways": [
        {
          "name": "NeedsHumanReview",
          "type": "exclusive",
          "conditions": [
            "requiresReview == true",
            "requiresReview == false"
          ],
          "description": "Routes to human review when automation flags a draft/recipient exception."
        }
      ],
      "sequenceFlows": [
        {
          "from": "RunBirthdayGreetings",
          "to": "NeedsHumanReview"
        },
        {
          "from": "NeedsHumanReview",
          "to": "HumanReviewDraftOrRecipient",
          "condition": "requiresReview == true"
        },
        {
          "from": "NeedsHumanReview",
          "to": "RunBirthdayGreetings",
          "condition": "requiresReview == false"
        }
      ],
      "crossReferences": {
        "orchestratorProcesses": [
          "birthday greetingsV26"
        ],
        "actionCenterCatalogs": [
          "AC_BirthdayGreetingsV26_HumanReview"
        ],
        "queues": [
          "birthdayGreetingsV26_Exceptions"
        ]
      }
    }
  ],
  "integrationServiceConnectors": [
    {
      "connectorName": "Gmail",
      "connectionName": "ninemush@gmail.com",
      "connectionId": "0a0d5ee1-a1e8-477a-a943-58161e6f3272",
      "usedActions": [
        "Send Email"
      ],
      "usedTriggers": [],
      "description": "Used to send the generated birthday email from the Gmail account ninemush@gmail.com.",
      "packageDependency": "UiPath.IntegrationService.Activities"
    },
    {
      "connectorName": "UiPath GenAI Activities",
      "connectionName": "prajwal.shambhu@uipath.com",
      "connectionId": "9d4f449a-0d3a-4755-9bba-1839fb337bcc",
      "usedActions": [
        "Generate Text"
      ],
      "usedTriggers": [],
      "description": "Used for native GenAI generation of subject and body; explicitly not using OpenAI/Azure OpenAI.",
      "packageDependency": "UiPath.IntegrationService.Activities"
    }
  ]
}
```