# Diagnostic Summary

## Run Metadata
- **Run ID:** e46e53c4-66e9-4fcf-9f43-b7883e4130af
- **Idea ID:** fcbe5f6d-60a1-45f7-8c96-5df24f1173b0
- **Status:** completed_with_warnings
- **Generation Mode:** baseline_openable
- **Triggered By:** chat
- **Created At:** Sun Apr 05 2026 04:51:10 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Sun Apr 05 2026 04:56:29 GMT+0000 (Coordinated Universal Time)
- **Duration:** 318.8s

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 23 |
| pipeline_sdd_validation | succeeded | 22 |
| spec_generation | succeeded | 238782 |
| spec_context_loading | succeeded | 6 |
| spec_prompt_assembly | succeeded | 2 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 36881 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 0 |
| spec_handoff | succeeded | 1 |
| build_pipeline | succeeded | 79971 |
| pipeline_build_pipeline | succeeded | 79971 |
| pipeline_decomposition | succeeded | 2 |
| pipeline_pre_complexity_estimation | succeeded | 1 |
| pipeline_workflow_budget_check | succeeded | 0 |
| pipeline_complexity_classification | succeeded | 0 |
| pipeline_xaml_emission | succeeded | 2872 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 19 |
| pipeline_validation | succeeded | 70320 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 207 |
| pipeline_packaging_dhg_guide | succeeded | 38 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_complete | succeeded | 1 |

## LLM Call Summary

| Stage | Model | Duration (ms) | Input Tokens | Output Tokens | Status |
|-------|-------|--------------|-------------|--------------|--------|
| iterative_correction:GetBirthdays:round_1 | gpt-5.2 | 26290 | 7548 | 0 | success |
| iterative_correction:Init:round_1 | gpt-5.2 | 43852 | 7660 | 0 | success |

**Totals:** 2 calls, 15208 input tokens, 0 output tokens, 70.1s total LLM time

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 21 |
| workflow_analyzer_autofix | 14 |
| activity_policy_filter | 6 |
| expression_lint | 3 |
| required_property_enforcement | 8 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 7
- **Total Warnings:** 17
- **Completeness:** structural

## Meta-Validation Summary

- **Engaged:** true
- **Mode:** Always
- **Corrections Applied:** 0
- **Corrections Skipped:** 4
- **Corrections Failed:** 1
- **Confidence Score:** 0.4411764705882353
- **Duration:** 45ms

## Remediations

- {"level":"workflow","file":"Main.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 68, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 66, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement Main — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"ProcessBirthday.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 223, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 220, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement ProcessBirthday — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Finalize.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 75: CStr() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InConfig.Contain...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in Finalize.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Finalize.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 343: ugs:GmailSendMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Finalize.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 315: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 451: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 497: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 76, col 186 (code: InvalidAttr): Attribute 'Settings\"]\"' has no space in starting.","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in InitAllSettings.xaml — [xml-wellformedness] XML parse error at line 76, col 186 (code: InvalidAttr): Attribute 'Settings\"]\"' has no space in starting.","estimatedEffortMinutes":15}
- {"level":"workflow","file":"KillAllProcesses.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 58, col 160 (code: InvalidAttr): Attribute 'chrome\"]\"' has no space in starting.","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in KillAllProcesses.xaml — [xml-wellformedness] XML parse error at line 58, col 160 (code: InvalidAttr): Attribute 'chrome\"]\"' has no space in starting.","estimatedEffortMinutes":15}
- {"level":"workflow","file":"Init.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [duplicate-file] Duplicate XAML file \"Init.xaml\" found in multiple locations: Init.xaml, Init.xaml; [malformed-quote] Line 473: attribute Message contains raw quote character mid-value; [malformed-quote] Line 478: attribute Message contains raw quote character mid-value; [malformed-quote] Line 530: attribute Message contains raw quote character mid-value; [malformed-quote] Line 539: attribute Message contains raw quote character mid-value","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in Init.xaml — [duplicate-file] Duplicate XAML file \"Init.xaml\" found in multiple locations: Init.xaml, Init.xaml; [malformed-quote] Line 473: attribute Message contains raw quote character mid-value; [malformed-quote] Line 478: attribute Message contains raw quote character mid-value; [malformed-quote] Line 530: attribute Message contains raw quote character mid-value; [malformed-quote] Line 539: attribute Message contains raw quote character mid-value","estimatedEffortMinutes":15}
- {"level":"workflow","file":"GetBirthdays.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 66: attribute Message contains raw quote character mid-value; [malformed-quote] Line 126: attribute Message contains raw quote character mid-value; [malformed-quote] Line 229: attribute Message contains raw quote character mid-value; [malformed-quote] Line 231: attribute Message contains raw quote character mid-value; [malformed-quote] Line 244: attribute Message contains raw quote character mid-value; [malformed-quote] Line 395: attribute Message contains raw quote character mid-value; [malformed-quote] Line 400: attribute Message contains raw quote character mid-value; [malformed-quote] Line 440: attribute Message contains raw quote character mid-value; [malformed-quote] Line 445: attribute Message contains raw quote character mid-value","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in GetBirthdays.xaml — [malformed-quote] Line 66: attribute Message contains raw quote character mid-value; [malformed-quote] Line 126: attribute Message contains raw quote character mid-value; [malformed-quote] Line 229: attribute Message contains raw quote character mid-value; [malformed-quote] Line 231: attribute Message contains raw quote character mid-value; [malformed-quote] Line 244: attribute Message contains raw quote character mid-value; [malformed-quote] Line 395: attribute Message contains raw quote character mid-value; [malformed-quote] Line 400: attribute Message contains raw quote character mid-value; [malformed-quote] Line 440: attribute Message contains raw quote character mid-value; [malformed-quote] Line 445: attribute Message contains raw quote character mid-value","estimatedEffortMinutes":15}
- {"level":"workflow","file":"HandleActionCenterTask.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [malformed-quote] Line 84: attribute Message contains raw quote character mid-value","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in HandleActionCenterTask.xaml — [malformed-quote] Line 84: attribute Message contains raw quote character mid-value","estimatedEffortMinutes":15}
- {"level":"activity","file":"Init.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"str_EmailWordCountMin\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"str_EmailWordCountMin\" in Init.xaml with the appropriate type. Expression context: Line 473: variable \"str_EmailWordCountMin\" is used in expression but not declared in this workflow","estimatedEffortMinutes":5,"inferredType":"x:String"}
- {"level":"activity","file":"Init.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"str_EmailWordCountMax\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"str_EmailWordCountMax\" in Init.xaml with the appropriate type. Expression context: Line 473: variable \"str_EmailWordCountMax\" is used in expression but not declared in this workflow","estimatedEffortMinutes":5,"inferredType":"x:String"}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"workflow","file":"Finalize.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: json_object_in_executable_attribute — JSON-like object payload in executable attribute: Condition=\"{&quot;type&quot;:","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve json_object_in_executable_attribute in Finalize.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"Finalize.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in Finalize.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"Process.xaml","description":"Stripped 32 placeholder token(s) from Process.xaml","developerAction":"Review Process.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"AgentInvocation_Stub.xaml","description":"Stripped 1 placeholder token(s) from AgentInvocation_Stub.xaml","developerAction":"Review AgentInvocation_Stub.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Init.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Init.xaml","description":"Catalog (fallback): Moved uds:CreateEntityRecord.EntityObject from attribute to child-element in Init.xaml"}
