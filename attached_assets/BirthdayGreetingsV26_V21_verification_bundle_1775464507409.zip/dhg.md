# Developer Handoff Guide

**Project:** BirthdayGreetingsV26
**Generated:** 2026-04-06
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Not Ready (34%)

**15 workflows: 7 fully generated, 0 with handoff blocks, 7 workflow-level stubs, 1 Studio-blocked**
**Total Estimated Effort: ~255 minutes (4.3 hours)**
**Remediations:** 25 total (0 property, 9 activity, 0 sequence, 0 structural-leaf, 8 workflow)
**Auto-Repairs:** 9
**Quality Warnings:** 73

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `Main.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 2 | `GetBirthdays.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 3 | `ProcessBirthday.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 4 | `ResolveContact.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 5 | `GenerateAndValidateDraft.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 6 | `HandleHumanReview.xaml` | Stub | 2 | 0 | 1 | 2 | 0 |
| 7 | `Finalize.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 8 | `Process.xaml` | Blocked | 2 | 2 | 0 | 0 | 0 |
| 9 | `InitAllSettings.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 10 | `GetTransactionData.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 11 | `SetTransactionStatus.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 12 | `CloseAllApplications.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 13 | `KillAllProcesses.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 14 | `Init.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 15 | `AgentInvocation_Stub.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 7 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `Finalize.xaml` | Generated with Remediations | Studio-openable |
| 2 | `GetTransactionData.xaml` | Fully Generated | Studio-openable |
| 3 | `SetTransactionStatus.xaml` | Fully Generated | Studio-openable |
| 4 | `CloseAllApplications.xaml` | Fully Generated | Studio-openable |
| 5 | `KillAllProcesses.xaml` | Fully Generated | Studio-openable |
| 6 | `Init.xaml` | Fully Generated | Studio-openable |
| 7 | `AgentInvocation_Stub.xaml` | Generated with Placeholders | Openable with warnings |

### AI-Resolved with Smart Defaults (9)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_PLACEHOLDER_CLEANUP` | `ResolveContact.xaml` | Stripped 1 placeholder token(s) from ResolveContact.xaml | 5 |
| 2 | `REPAIR_PLACEHOLDER_CLEANUP` | `Process.xaml` | Stripped 32 placeholder token(s) from Process.xaml | 5 |
| 3 | `REPAIR_PLACEHOLDER_CLEANUP` | `AgentInvocation_Stub.xaml` | Stripped 1 placeholder token(s) from AgentInvocation_Stub.xaml | 5 |
| 4 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (DOM): move-to-child-element ucs:BuildDataTable.DataTable in GetBirthdays.xaml | undefined |
| 5 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (DOM): move-to-child-element ucs:BuildDataTable.Columns in GetBirthdays.xaml | undefined |
| 6 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (DOM): move-to-child-element ugs:GoogleCalendarGetEvents.Events in GetBirthdays.xaml | undefined |
| 7 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in GetBirthdays.xaml | undefined |
| 8 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (DOM): move-to-child-element ucs:AddDataRow.DataTable in GetBirthdays.xaml | undefined |
| 9 | `REPAIR_GENERIC` | `GetBirthdays.xaml` | Catalog (DOM): move-to-child-element ucs:AddDataRow.ArrayRow in GetBirthdays.xaml | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `Main.xaml` | Studio-openable | — | — |
| 2 | `GetBirthdays.xaml` | Structurally invalid — not Studio-loadable | Unclassified | [EXPRESSION_IN_LITERAL_SLOT] Line 123: RetryInterval="TimeSpan.FromSeconds(ba... |
| 3 | `ProcessBirthday.xaml` | Studio-openable | — | — |
| 4 | `ResolveContact.xaml` | Openable with warnings | Unclassified | — |
| 5 | `GenerateAndValidateDraft.xaml` | Openable with warnings | Unclassified | — |
| 6 | `HandleHumanReview.xaml` | Studio-openable | — | — |
| 7 | `Finalize.xaml` | Studio-openable | — | — |
| 8 | `Process.xaml` | Structurally invalid — not Studio-loadable | Unclassified | [pseudo-xaml] Line 318: pseudo-XAML attribute Body="[str_EmailBody]"; [pseudo-xaml] Line 456: pseudo-XAML attribute Body="[str_EmailBody]"; [pseudo-xaml] Line 502: pseudo-XAML attribute Body="[str_EmailBody]" |
| 9 | `InitAllSettings.xaml` | Studio-openable | — | — |
| 10 | `GetTransactionData.xaml` | Studio-openable | — | — |
| 11 | `SetTransactionStatus.xaml` | Studio-openable | — | — |
| 12 | `CloseAllApplications.xaml` | Studio-openable | — | — |
| 13 | `KillAllProcesses.xaml` | Studio-openable | — | — |
| 14 | `Init.xaml` | Studio-openable | — | — |
| 15 | `AgentInvocation_Stub.xaml` | Openable with warnings | Unclassified | — |

**Summary:** 10 Studio-loadable, 3 with warnings, 2 not Studio-loadable

> **⚠ 2 workflow(s) are not Studio-loadable** — they will fail to open in UiPath Studio. Address the blockers listed above before importing.

**Blocked by category:**
- [EXPRESSION_IN_LITERAL_SLOT] Line 123: RetryInterval="TimeSpan.FromSeconds(backoffSeconds)" contains a VB expression or variable that is not bracket-wrapped — must be hh:mm:ss literal or [expression]: 1 workflow(s)
- [pseudo-xaml] Line 318: pseudo-XAML attribute Body="[str_EmailBody]"; [pseudo-xaml] Line 456: pseudo-XAML attribute Body="[str_EmailBody]": 1 workflow(s)

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**9 handoff block(s) requiring manual implementation**

#### 1. `HandleHumanReview.xaml` — — (activity)

- **Workflow File:** `HandleHumanReview.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "value" in HandleHumanReview.xaml with the appropriate type. Expression context: value
- **Estimated Effort:** 5 minutes

#### 2. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 3. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 4. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 5. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 6. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 7. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 8. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 9. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**98 items remaining — ~985 minutes (16.4 hours) total estimated effort**

### GenerateAndValidateDraft.xaml (9 items, ~90 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `GenerateAndValidateDraft.xaml` replaced with Studio-openable... | Resolve json_object_in_executable_attribute in GenerateAndValidateDraft.xaml | 10 |
| 2 | High | Workflow Stub | Entire workflow `GenerateAndValidateDraft.xaml` replaced with Studio-openable... | Resolve object_payload_in_target_value_slot in GenerateAndValidateDraft.xaml | 10 |
| 3 | Low | Quality Warning | invalid-activity-property: Line 177: property "Condition" is not a known prop... | Review and address | 10 |
| 4 | Low | Quality Warning | hardcoded-retry-count: Line 132: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 5 | Low | Quality Warning | hardcoded-retry-interval: Line 84: retry interval hardcoded as "{&quot;type&q... | Review and address | 10 |
| 6 | Low | Quality Warning | hardcoded-retry-interval: Line 132: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 7 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 370: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 8 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 386: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 9 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### GetBirthdays.xaml (6 items, ~60 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 10 | High | Workflow Stub | Entire workflow `GetBirthdays.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in GetBirthdays.xaml | 10 |
| 11 | Low | Quality Warning | hardcoded-retry-count: Line 166: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 12 | Low | Quality Warning | hardcoded-retry-interval: Line 123: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 13 | Low | Quality Warning | hardcoded-retry-interval: Line 166: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 14 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 300: Unbalanced parentheses: 1 open vs 2 close — remo... | Review and address | 10 |
| 15 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### HandleHumanReview.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 16 | High | Workflow Stub | Entire workflow `HandleHumanReview.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml | 10 |
| 17 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "value" in HandleHumanReview.xaml with the appropriate type.... | 5 |
| 18 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in HandleHumanReview.xaml — estimated 15 min | 15 |

### InitAllSettings.xaml (21 items, ~210 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 19 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in InitAllSettings.xaml | 10 |
| 20 | Low | Quality Warning | hardcoded-asset-name: Line 100: asset name "BGV26_GSuite_ServiceAccount_Crede... | Review and address | 10 |
| 21 | Low | Quality Warning | hardcoded-asset-name: Line 105: asset name "BGV26_BirthdaysCalendarName" is h... | Review and address | 10 |
| 22 | Low | Quality Warning | hardcoded-asset-name: Line 114: asset name "BGV26_TimeZone" is hardcoded — co... | Review and address | 10 |
| 23 | Low | Quality Warning | hardcoded-asset-name: Line 123: asset name "BGV26_EmailStyleSpec" is hardcode... | Review and address | 10 |
| 24 | Low | Quality Warning | hardcoded-asset-name: Line 132: asset name "BGV26_EmailWordCountMin" is hardc... | Review and address | 10 |
| 25 | Low | Quality Warning | hardcoded-asset-name: Line 141: asset name "BGV26_EmailWordCountMax" is hardc... | Review and address | 10 |
| 26 | Low | Quality Warning | hardcoded-asset-name: Line 150: asset name "BGV26_AllowActionCenterFallback" ... | Review and address | 10 |
| 27 | Low | Quality Warning | hardcoded-asset-name: Line 159: asset name "BGV26_GmailFromConnectionName" is... | Review and address | 10 |
| 28 | Low | Quality Warning | hardcoded-asset-name: Line 168: asset name "BGV26_DedupeScope" is hardcoded —... | Review and address | 10 |
| 29 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 30 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 31 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_GSuite_ServiceAccount_Creden... | Review and address | 10 |
| 32 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_BirthdaysCalendarName" for u... | Review and address | 10 |
| 33 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_TimeZone" for ui:GetAsset.As... | Review and address | 10 |
| 34 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailStyleSpec" for ui:GetAs... | Review and address | 10 |
| 35 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailWordCountMin" for ui:Ge... | Review and address | 10 |
| 36 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailWordCountMax" for ui:Ge... | Review and address | 10 |
| 37 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_AllowActionCenterFallback" f... | Review and address | 10 |
| 38 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_GmailFromConnectionName" for... | Review and address | 10 |
| 39 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_DedupeScope" for ui:GetAsset... | Review and address | 10 |

### Main.xaml (1 item, ~15 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 40 | High | Workflow Stub | Entire workflow `Main.xaml` replaced with Studio-openable stub | TODO: Implement Main — review SDD for workflow requirements | 15 |

### ProcessBirthday.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 41 | High | Workflow Stub | Entire workflow `ProcessBirthday.xaml` replaced with Studio-openable stub | TODO: Implement ProcessBirthday — review SDD for workflow requirements | 15 |
| 42 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### ResolveContact.xaml (18 items, ~195 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 43 | High | Workflow Stub | Entire workflow `ResolveContact.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in ResolveContact.xaml | 10 |
| 44 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in ResolveContact.xaml — estimated 15 min | 15 |
| 45 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in ResolveContact.xaml — estimated 15 min | 15 |
| 46 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in ResolveContact.xaml — estimated 15 min | 15 |
| 47 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 48 | Low | Quality Warning | invalid-activity-property: Line 244: property "Expression" is not a known pro... | Review and address | 10 |
| 49 | Low | Quality Warning | invalid-activity-property: Line 246: property "Key" is not a known property o... | Review and address | 10 |
| 50 | Low | Quality Warning | hardcoded-retry-count: Line 128: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 51 | Low | Quality Warning | hardcoded-retry-count: Line 176: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 52 | Low | Quality Warning | hardcoded-retry-count: Line 264: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 53 | Low | Quality Warning | hardcoded-retry-interval: Line 128: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 54 | Low | Quality Warning | hardcoded-retry-interval: Line 133: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 55 | Low | Quality Warning | hardcoded-retry-interval: Line 176: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 56 | Low | Quality Warning | hardcoded-retry-interval: Line 264: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 57 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 347: Unbalanced parentheses: 3 open vs 5 close — remo... | Review and address | 10 |
| 58 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 59 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 60 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### Unknown.xaml (8 items, ~40 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 61 | Medium | Activity Stub | Activity "unknown" stubbed | ugs:GmailSendMessage.Body has no valid source binding and no contract-valid f... | 5 |
| 62 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 63 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 64 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 65 | Medium | Activity Stub | Activity "unknown" stubbed | ugs:GmailSendMessage.Body has no valid source binding and no contract-valid f... | 5 |
| 66 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 67 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |
| 68 | Medium | Activity Stub | Activity "unknown" stubbed | umail:SendSmtpMailMessage.Body has no valid source binding and no contract-va... | 5 |

### AgentInvocation_Stub.xaml (1 item, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 69 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |

### Finalize.xaml (1 item, ~15 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 70 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Finalize.xaml — estimated 15 min | 15 |

### Process.xaml (25 items, ~265 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 71 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 72 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 73 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 74 | Low | Implementation Required | Contains 30 placeholder value(s) matching "\bTODO\b" [Developer Implementatio... | Implement in Studio | 10 |
| 75 | Low | Quality Warning | hardcoded-credential: Potential hardcoded credential detected (pattern: passw... | Review and address | 10 |
| 76 | Low | Quality Warning | invalid-type-argument: Line 70: x:TypeArguments="UiPath.Persistence.Activitie... | Review and address | 10 |
| 77 | Low | Quality Warning | hardcoded-retry-count: Line 124: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 78 | Low | Quality Warning | hardcoded-retry-count: Line 170: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 79 | Low | Quality Warning | hardcoded-retry-count: Line 446: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 80 | Low | Quality Warning | hardcoded-retry-count: Line 492: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 81 | Low | Quality Warning | hardcoded-retry-count: Line 538: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 82 | Low | Quality Warning | hardcoded-retry-interval: Line 124: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 83 | Low | Quality Warning | hardcoded-retry-interval: Line 170: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 84 | Low | Quality Warning | hardcoded-retry-interval: Line 446: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 85 | Low | Quality Warning | hardcoded-retry-interval: Line 492: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 86 | Low | Quality Warning | hardcoded-retry-interval: Line 538: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 87 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 90: Standalone "No" corrected to "False" in expressio... | Review and address | 10 |
| 88 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 109: Standalone "No" corrected to "False" in expressi... | Review and address | 10 |
| 89 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 214: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |
| 90 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 582: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |
| 91 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 92 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 93 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 94 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 95 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### KillAllProcesses.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 96 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "chrome" for ui:KillProcess.Process... | Review and address | 10 |
| 97 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "iexplore" for ui:KillProcess.Proce... | Review and address | 10 |
| 98 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "EXCEL" for ui:KillProcess.ProcessN... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Automate birthday greetings to friends and family

### PDD Summary

## 1. Executive Summary
The “birthday greetingsV26” project automates a daily personal workflow: at 8:00am, birthdays are checked in Google Calendar and a warm, funny, lightly sarcastic birthday email is sent from the user’s Gmail account. The current manual approach is simple but prone to missed sends when the user forgets. The to-be solution will run fully autonomously on unattended robots via UiPath Orchestrator Triggers, retrieve today’s birthday events from the built-in Google “Birthdays” calendar feed, resolve the recipient’s email address via Google Contacts (preferring “Personal” when multiple emails exist), generate a personalized message using UiPath native GenAI capabilities (no OpenAI/Azure OpenAI usage), send via the Gmail Integration Service connector for **ninemush@gmail.com**, and record a sent-log to prevent duplicates within the same day.

## 2. Process Scope
This automation is in scope to execute once per day at 8:00am and complete all birthday greetings for that same calendar date. It reads birthday events from the built-in Google “Birthdays” calendar feed (displayed as “Birthdays”), where each event title contains only the person’s full name. It then performs an exact-name lookup in Google Contacts to find a recipient email labeled “Personal” or “Home,” prioritizing “Personal.” If no valid email is found, the automation skips that person without further action.

The email is sent exclusively from the Gmail account connected in UiPath Integration Service as **Gmail – ninemush@gmail.com**. The content is AI-generated using UiPath native capabilities (UiPath GenAI Activities / Agents) and follows an approved default style specification (warm, funny, lightly sarcastic; no emojis; one short subject line; 40–90 words). Photo usage (e.g., Google Photos) and any relationship-based personalization are explicitly out of scope for this iteration.

## 3. As-Is Process Description

![As-Is Process Map](/api/ideas/fcbe5f6d-60a1-45f7-8c96-5df24f1173b0/process-...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Automation type: Hybrid (Workflow + Native GenAI), unattended-first, exception-only human-in-the-loop.**

- **Deterministic steps** (schedule, calendar read, exact contact lookup, email selection, dedupe, send, logging) are best implemented as **unattended workflow automation** for reliability and operability.
- **Generative step** (subject/body drafting in the approved default voice spec) is best implemented using **UiPath native GenAI capabilities** invoked from the workflow. This is not a “pure Agent” process because the core is deterministic and must be strongly governed (exact-match, dedupe, same-day rules).
- **Action Center** is included only for **edge cases** (draft validation failure, ambiguous contacts if exact name returns multiples) to keep the standard path fully autonomous while still preventing unsafe or incomplete sends.

### 1.2 High-level architecture (services used)
- **Orchestrator**
  - **Time-based Trigger**: daily at **08:00**.
  - **Unattended job execution** on available unattended slots (11).
  - **Assets** for configuration (calendar name/id, voice spec, validation thresholds).
  - **Monitoring & alerting hooks**: job state, custom logs, and failure notifications.
- **Integration Service**
  - **Gmail connector** to send email from **connection “ninemush@gmail.com” (ID: 0a0d5ee1-a1e8-477a-a943-58161e6f3272)**.
  - Rationale: connector-based sending is more stable and auditable than UI automation, and avoids custom HTTP per platform rule.
- **Google access**
  - Calendar + Contacts access in the PDD is via **UiPath GSuite Activities** (Google APIs).
  - Rationale: quick, stable, no UI; also avoids building/maintaining bespoke HTTP integrations.
- **Data Service**
  - Stores persistent **sent-log** and run trace data to enforce deduplication (**once per person per year**, and at minimum also same-day).
  - Rationale vs Orchestrator Queue:
    - **Queue** ...

**Automation Type:** hybrid
**Rationale:** The calendar/contact lookup + sending are deterministic and best as RPA, while drafting “warm/funny/sarcastic” unique messages is generative and best handled by a UiPath GenAI-powered agent step with guardrails and fallback.
**Feasibility Complexity:** medium
**Effort Estimate:** 1-2 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | 8am Daily Birthday Run Trigger | System | Orchestrator Triggers | start | — |
| 2 | Get Today’s Birthday Events (Built-in Birthdays Calendar) | System | Google Calendar (UiPath GSuite Activities) | task | — |
| 3 | Any birthdays today? | System | Google Calendar (UiPath GSuite Activities) | decision | — |
| 4 | No Birthdays Today End | System | Orchestrator | end | — |
| 5 | For Each Birthday Event: Normalize Full Name | System | Workflow | task | — |
| 6 | Exact Match Contact by Full Name | System | Google Contacts (UiPath GSuite Activities) | task | — |
| 7 | Personal/Home email available? | System | Google Contacts (UiPath GSuite Activities) | decision | — |
| 8 | Skip Person (No Email) | System | Workflow | task | — |
| 9 | Select Recipient Email (Prefer Personal) | System | Google Contacts (UiPath GSuite Activities) | task | — |
| 10 | Already Sent Today for This Person? | System | Data Service / Data Fabric | decision | — |
| 11 | Skip Duplicate Send | System | Workflow | task | — |
| 12 | Generate Birthday Email Draft (Your Voice) | System | UiPath Agents + UiPath GenAI Activities | agent-task | — |
| 13 | Draft Safe/Complete? (no sensitive content, has subject+body) | System | UiPath Agents | agent-decision | — |
| 14 | Create Human Review Task (Edge Case) | System | Action Center | task | — |
| 15 | Apply Approved/Edited Text from Action Center | System | Action Center | task | — |
| 16 | Send Birthday Email | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 17 | Send Birthday Email (Post-Review) | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 18 | Record Sent Log (name, email, date, messageId) | System | Data Service / Data Fabric | task | — |
| 19 | More birthday events remaining? | System | Workflow | decision | — |
| 20 | Process Next Event | System | Workflow | task | — |
| 21 | Birthday Batch Completed End | System | Orchestrator | end | — |
| 22 | Loop Back to Next Contact Lookup | System | Workflow | task | — |
| 23 | Merge Skips Back to Loop | System | Workflow | task | — |
| 24 | Merge Duplicate Skips Back to Loop | System | Workflow | task | — |
| 25 | Continue Loop | System | Workflow | task | — |
| 26 | Return to “More events remaining?” decision | System | Workflow | task | — |
| 27 | Loop to Contact Lookup | System | Workflow | task | — |
| 28 | Loop Connection | System | Workflow | task | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath GSuite Activities)
- Orchestrator
- Workflow
- Google Contacts (UiPath GSuite Activities)
- Data Service / Data Fabric
- UiPath Agents + UiPath GenAI Activities
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

### User Roles Involved

- System

### Decision Points (Process Map Topology)

**Any birthdays today?**
  - [No] → No Birthdays Today End
  - [Yes] → For Each Birthday Event: Normalize Full Name

**Personal/Home email available?**
  - [No] → Skip Person (No Email)
  - [Yes] → Select Recipient Email (Prefer Personal)

**Already Sent Today for This Person?**
  - [Yes] → Skip Duplicate Send
  - [No] → Generate Birthday Email Draft (Your Voice)

**More birthday events remaining?**
  - [Yes] → Process Next Event
  - [No] → Birthday Batch Completed End

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Standard |
| Action Center | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.UIAutomation.Activities` |
| 3 | `UiPath.ComplexScenarios.Activities` |
| 4 | `UiPath.GSuite.Activities` |
| 5 | `UiPath.WebAPI.Activities` |
| 6 | `Newtonsoft.Json` |
| 7 | `UiPath.Persistence.Activities` |
| 8 | `UiPath.DataService.Activities` |
| 9 | `UiPath.Mail.Activities` |
| 10 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath GSuite Activities)
- Orchestrator
- Workflow
- Google Contacts (UiPath GSuite Activities)
- Data Service / Data Fabric
- UiPath Agents + UiPath GenAI Activities
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

## 7. Credential & Asset Inventory

**Total:** 17 activities (0 hardcoded, 17 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `[BGV26_GSuite_ServiceAccount_Credential]` | Credential | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[BGV26_BirthdaysCalendarName]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 2 | `[BGV26_TimeZone]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 3 | `[BGV26_EmailStyleSpec]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 4 | `[BGV26_EmailWordCountMin]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 5 | `[BGV26_EmailWordCountMax]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 6 | `[BGV26_AllowActionCenterFallback]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 7 | `[BGV26_GmailFromConnectionName]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 8 | `[BGV26_DedupeScope]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `InitAllSettings.xaml` | 102 | GetCredential | `[BGV26_GSuite_ServiceAccount_Credential]` | Credential | — | No |
| `InitAllSettings.xaml` | 107 | GetAsset | `[BGV26_BirthdaysCalendarName]` | Unknown | — | No |
| `InitAllSettings.xaml` | 108 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 116 | GetAsset | `[BGV26_TimeZone]` | Unknown | — | No |
| `InitAllSettings.xaml` | 117 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 125 | GetAsset | `[BGV26_EmailStyleSpec]` | Unknown | — | No |
| `InitAllSettings.xaml` | 126 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 134 | GetAsset | `[BGV26_EmailWordCountMin]` | Unknown | — | No |
| `InitAllSettings.xaml` | 135 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 143 | GetAsset | `[BGV26_EmailWordCountMax]` | Unknown | — | No |
| `InitAllSettings.xaml` | 144 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 152 | GetAsset | `[BGV26_AllowActionCenterFallback]` | Unknown | — | No |
| `InitAllSettings.xaml` | 153 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 161 | GetAsset | `[BGV26_GmailFromConnectionName]` | Unknown | — | No |
| `InitAllSettings.xaml` | 162 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 170 | GetAsset | `[BGV26_DedupeScope]` | Unknown | — | No |
| `InitAllSettings.xaml` | 171 | GetAsset | `UNKNOWN` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 0 aligned, 10 SDD-only, 10 XAML-only

> **Warning:** 10 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 10 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `BGV26_GSuite_ServiceAccount_Credential` | credential | **SDD Only** | type: Credential, description: Credential for Google Workspace/GSuite Activities authentication (service identity) to read Google Calendar 'Birthdays' feed and Google Contacts. | — | — |
| 2 | `BGV26_BirthdaysCalendarName` | asset | **SDD Only** | type: Text, value: Birthdays, description: Display name of the built-in Google Calendar feed used as source for birthdays. | — | — |
| 3 | `BGV26_TimeZone` | asset | **SDD Only** | type: Text, value: America/New_York, description: Time zone used to compute 'today' for birthday event retrieval and deduplication. | — | — |
| 4 | `BGV26_EmailStyleSpec` | asset | **SDD Only** | type: Text, value: Write a warm, funny, lightly sarcastic birthday email. No emojis. Provide one short subject line and an email body of 40–90 words. Keep it appropriate for workplace/friends; no sensitive or offensive content., description: Default prompt/style specification passed to UiPath native GenAI generation. | — | — |
| 5 | `BGV26_EmailWordCountMin` | asset | **SDD Only** | type: Integer, value: 40, description: Minimum allowed word count for generated email body. | — | — |
| 6 | `BGV26_EmailWordCountMax` | asset | **SDD Only** | type: Integer, value: 90, description: Maximum allowed word count for generated email body. | — | — |
| 7 | `BGV26_AllowActionCenterFallback` | asset | **SDD Only** | type: Bool, value: true, description: If true, create an Action Center task when GenAI output fails validation or contact match is ambiguous. | — | — |
| 8 | `BGV26_GmailFromConnectionName` | asset | **SDD Only** | type: Text, value: ninemush@gmail.com, description: Integration Service Gmail connection name to be used for sending. | — | — |
| 9 | `BGV26_DedupeScope` | asset | **SDD Only** | type: Text, value: FullName+SendDate, description: Deduplication key scope for sent-log checks. | — | — |
| 10 | `[BGV26_BirthdaysCalendarName]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 107 |
| 11 | `[BGV26_TimeZone]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 116 |
| 12 | `[BGV26_EmailStyleSpec]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 125 |
| 13 | `[BGV26_EmailWordCountMin]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 134 |
| 14 | `[BGV26_EmailWordCountMax]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 143 |
| 15 | `[BGV26_AllowActionCenterFallback]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 152 |
| 16 | `[BGV26_GmailFromConnectionName]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 161 |
| 17 | `[BGV26_DedupeScope]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 170 |
| 18 | `[BGV26_GSuite_ServiceAccount_Credential]` | credential | **XAML Only** | — | `InitAllSettings.xaml` | 102 |
| 19 | `birthdayGreetingsV26_Exceptions` | queue | **SDD Only** | maxRetries: 2, uniqueReference: true, description: Queue for non-blocking exceptions and reprocessing items (e.g., ambiguous contact match, transient integration failures) for birthday greetings run. | — | — |
| 20 | `[in_QueueName]` | queue | **XAML Only** | — | `GetTransactionData.xaml` | 62 |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### Queues to Provision

| # | Queue Name | Activities | Unique Reference | Auto Retry | SLA | Action |
|---|-----------|------------|-----------------|------------|-----|--------|
| 1 | `[in_QueueName]` | GetTransactionItem | Recommended | Yes (3x) | — | Verify exists |

### SDD-Defined Queues (Not Yet in XAML)

| # | Queue Name | Unique Reference | Max Retries | SLA | Note |
|---|-----------|-----------------|-------------|-----|------|
| 1 | `birthdayGreetingsV26_Exceptions` | Yes | 2x | — | Defined in SDD but no matching XAML activity — verify implementation |

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | No |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

> **Note:** This is a Performer process — a separate Dispatcher process is needed to populate the queue.

## 10. Exception Handling Coverage

**Coverage:** 4/25 high-risk activities inside TryCatch (16%)

### Files Without TryCatch

- `ProcessBirthday.xaml`
- `InitAllSettings.xaml`
- `GetTransactionData.xaml`
- `KillAllProcesses.xaml`
- `AgentInvocation_Stub.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:102` | Get BGV26_GSuite_ServiceAccount_Credential |
| 2 | `InitAllSettings.xaml:107` | Get BGV26_BirthdaysCalendarName |
| 3 | `InitAllSettings.xaml:108` | ui:GetAsset |
| 4 | `InitAllSettings.xaml:116` | Get BGV26_TimeZone |
| 5 | `InitAllSettings.xaml:117` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:125` | Get BGV26_EmailStyleSpec |
| 7 | `InitAllSettings.xaml:126` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:134` | Get BGV26_EmailWordCountMin |
| 9 | `InitAllSettings.xaml:135` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:143` | Get BGV26_EmailWordCountMax |
| 11 | `InitAllSettings.xaml:144` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:152` | Get BGV26_AllowActionCenterFallback |
| 13 | `InitAllSettings.xaml:153` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:161` | Get BGV26_GmailFromConnectionName |
| 15 | `InitAllSettings.xaml:162` | ui:GetAsset |
| 16 | `InitAllSettings.xaml:170` | Get BGV26_DedupeScope |
| 17 | `InitAllSettings.xaml:171` | ui:GetAsset |
| 18 | `GetTransactionData.xaml:62` | Get Queue Item |
| 19 | `GetTransactionData.xaml:63` | ui:GetTransactionItem |
| 20 | `SetTransactionStatus.xaml:67` | Set Success |
| 21 | `SetTransactionStatus.xaml:89` | Set Failed |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_BirthdayGreetingsV26_Daily_0800 | SDD-specified: TRG_BirthdayGreetingsV26_Daily_0800 | Cron: 0 0 8 ? * * * | Runs the birthdayGreetingsV26 job daily at 08:00. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| placeholder-value | warning | 4 | Contains 1 placeholder value(s) matching "\bTODO\b" [Developer Implementation Required] |
| hardcoded-credential | warning | 1 | Potential hardcoded credential detected (pattern: password\s*[:=]\s*["'](?!\[)[^...) |
| invalid-activity-property | warning | 3 | Line 244: property "Expression" is not a known property of Switch |
| invalid-type-argument | warning | 1 | Line 70: x:TypeArguments="UiPath.Persistence.Activities.FormTask" may not be a valid .NET type |
| hardcoded-retry-count | warning | 10 | Line 166: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| hardcoded-retry-interval | warning | 13 | Line 123: retry interval hardcoded as "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;TimeSpan.From... |
| hardcoded-asset-name | warning | 9 | Line 100: asset name "BGV26_GSuite_ServiceAccount_Credential" is hardcoded — consider using a Config.xlsx entry or workf... |
| EXPRESSION_SYNTAX | warning | 6 | Line 300: Unbalanced parentheses: 1 open vs 2 close — removed 1 extra closing paren(s) | max nesting depth: 1, first imb... |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 2 | Line 370: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption i... |
| BARE_TOKEN_QUOTED | warning | 14 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |
| RETRY_INTERVAL_DEFAULTED | warning | 10 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `[BGV26_GSuite_ServiceAccount_Credential]` | Yes |
| 5 | Assets | Provision asset: `[BGV26_BirthdaysCalendarName]` | Yes |
| 6 | Assets | Provision asset: `[BGV26_TimeZone]` | Yes |
| 7 | Assets | Provision asset: `[BGV26_EmailStyleSpec]` | Yes |
| 8 | Assets | Provision asset: `[BGV26_EmailWordCountMin]` | Yes |
| 9 | Assets | Provision asset: `[BGV26_EmailWordCountMax]` | Yes |
| 10 | Assets | Provision asset: `[BGV26_AllowActionCenterFallback]` | Yes |
| 11 | Assets | Provision asset: `[BGV26_GmailFromConnectionName]` | Yes |
| 12 | Assets | Provision asset: `[BGV26_DedupeScope]` | Yes |
| 13 | Queues | Create queue: `[in_QueueName]` | Yes |
| 14 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 15 | Testing | Run smoke test in target environment | Yes |
| 16 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 17 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 18 | Governance | Peer code review completed | Yes |
| 19 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 20 | Governance | Business process owner validation obtained | Yes |
| 21 | Governance | CoE approval obtained | Yes |
| 22 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Not Ready — 32/50 (34%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 2/10 | Only 16% of high-risk activities covered by TryCatch; 5 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | Queue configuration looks good |
| Build Quality | 0/10 | 73 quality warnings — significant remediation needed; 25 remediations — stub replacements need developer attention; 13/15 workflow(s) are Studio-loadable (2 blocked — 13% not loadable) |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Action Required:** Address the items above before deploying to production. Focus on sections with the lowest scores first.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 98 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 848 | 848 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 10536 | 5344 | 0 | 0 | 0 | 5192 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 12316 | 9116 | 0 | 2860 | 0 | 340 |
| executable-path-validator | Yes | 673 | 603 | 0 | 0 | 0 | 70 |
| post-emission-dependency-analyzer | Yes | 13 | 13 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "GetTransactionData.xaml",
    "SetTransactionStatus.xaml",
    "CloseAllApplications.xaml",
    "KillAllProcesses.xaml",
    "AgentInvocation_Stub.xaml"
  ],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "ResolveContact.xaml",
      "description": "Stripped 1 placeholder token(s) from ResolveContact.xaml",
      "developerAction": "Review ResolveContact.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "Process.xaml",
      "description": "Stripped 32 placeholder token(s) from Process.xaml",
      "developerAction": "Review Process.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "AgentInvocation_Stub.xaml",
      "description": "Stripped 1 placeholder token(s) from AgentInvocation_Stub.xaml",
      "developerAction": "Review AgentInvocation_Stub.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ucs:BuildDataTable.DataTable in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ucs:BuildDataTable.Columns in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ugs:GoogleCalendarGetEvents.Events in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ucs:AddDataRow.DataTable in GetBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ucs:AddDataRow.ArrayRow in GetBirthdays.xaml"
    }
  ],
  "remediations": [
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 531, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 527, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement Main — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ProcessBirthday.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 75, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 73, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement ProcessBirthday — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ResolveContact.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 347: Unbalanced brackets: 1 open vs 0 close (diff: +1) | first imbalance near position 266, fragment: \"&amp; c.ToString()))&quot;}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in ResolveContact.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ResolveContact.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 347: String.Join() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in ResolveContact.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ResolveContact.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 347: .Select() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in ResolveContact.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "HandleHumanReview.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 322: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in HandleHumanReview.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Finalize.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 134: ugs:GmailSendMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Finalize.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 315: umail:SendSmtpMailMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 451: umail:SendSmtpMailMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 497: umail:SendSmtpMailMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "HandleHumanReview.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"value\" in HandleHumanReview.xaml with the appropriate type. Expression context: value",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "GetBirthdays.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in GetBirthdays.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "ResolveContact.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in ResolveContact.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: json_object_in_executable_attribute — JSON-like object payload in executable attribute: Condition=\"{&quot;type&quot;:",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve json_object_in_executable_attribute in GenerateAndValidateDraft.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in GenerateAndValidateDraft.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "HandleHumanReview.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in InitAllSettings.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "ResolveContact.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "hardcoded-credential",
      "file": "Process.xaml",
      "detail": "Potential hardcoded credential detected (pattern: password\\s*[:=]\\s*[\"'](?!\\[)[^...)",
      "severity": "warning"
    },
    {
      "check": "placeholder-value",
      "file": "Process.xaml",
      "detail": "Contains 30 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "AgentInvocation_Stub.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ProcessBirthday.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "invalid-activity-property",
      "file": "ResolveContact.xaml",
      "detail": "Line 244: property \"Expression\" is not a known property of Switch",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "ResolveContact.xaml",
      "detail": "Line 246: property \"Key\" is not a known property of Sequence",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 177: property \"Condition\" is not a known property of ui:ShouldRetry",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "Process.xaml",
      "detail": "Line 70: x:TypeArguments=\"UiPath.Persistence.Activities.FormTask\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "GetBirthdays.xaml",
      "detail": "Line 166: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GetBirthdays.xaml",
      "detail": "Line 123: retry interval hardcoded as \"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;TimeSpan.FromSeconds(backoffSeconds)&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GetBirthdays.xaml",
      "detail": "Line 166: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "ResolveContact.xaml",
      "detail": "Line 128: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "ResolveContact.xaml",
      "detail": "Line 176: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "ResolveContact.xaml",
      "detail": "Line 264: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ResolveContact.xaml",
      "detail": "Line 128: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ResolveContact.xaml",
      "detail": "Line 133: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:05&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ResolveContact.xaml",
      "detail": "Line 176: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ResolveContact.xaml",
      "detail": "Line 264: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 132: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 84: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:10&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 132: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 124: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 170: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 446: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 492: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Process.xaml",
      "detail": "Line 538: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 124: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 170: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 446: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 492: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Process.xaml",
      "detail": "Line 538: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 100: asset name \"BGV26_GSuite_ServiceAccount_Credential\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 105: asset name \"BGV26_BirthdaysCalendarName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 114: asset name \"BGV26_TimeZone\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 123: asset name \"BGV26_EmailStyleSpec\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 132: asset name \"BGV26_EmailWordCountMin\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 141: asset name \"BGV26_EmailWordCountMax\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 150: asset name \"BGV26_AllowActionCenterFallback\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 159: asset name \"BGV26_GmailFromConnectionName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 168: asset name \"BGV26_DedupeScope\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "GetBirthdays.xaml",
      "detail": "Line 300: Unbalanced parentheses: 1 open vs 2 close — removed 1 extra closing paren(s) | max nesting depth: 1, first imbalance near position 214, fragment: \"ot; &amp; rawEventTitle.Trim())&quot;}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentEv...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "ResolveContact.xaml",
      "detail": "Line 347: Unbalanced parentheses: 3 open vs 5 close — removed 2 extra closing paren(s) | max nesting depth: 1, first imbalance near position 257, fragment: \"&amp; c.ToString()))&quot;}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 370: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationNo...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 386: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationNo...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 90: Standalone \"No\" corrected to \"False\" in expression: No",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 109: Standalone \"No\" corrected to \"False\" in expression: No",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 214: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 582: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_GSuite_ServiceAccount_Credential\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_BirthdaysCalendarName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_TimeZone\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailStyleSpec\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailWordCountMin\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailWordCountMax\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_AllowActionCenterFallback\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_GmailFromConnectionName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_DedupeScope\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"chrome\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"iexplore\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"EXCEL\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "GetBirthdays.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "ResolveContact.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "ResolveContact.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "ResolveContact.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Process.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 255,
  "studioCompatibility": [
    {
      "file": "GetBirthdays.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ResolveContact.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[EXPRESSION-SYNTAX] Expression syntax errors that could not be auto-corrected"
      ],
      "failureCategory": "expression-syntax",
      "failureSummary": "Expression syntax errors that could not be auto-corrected"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "HandleHumanReview.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Finalize.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "Process.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "GetTransactionData.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "SetTransactionStatus.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CloseAllApplications.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "KillAllProcesses.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "Init.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "AgentInvocation_Stub.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "ProcessBirthday.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetBirthdays",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ProcessBirthday",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ResolveContact",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GenerateAndValidateDraft",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "HandleHumanReview",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Finalize",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process.xaml",
      "targetWorkflow": "AgentInvocation_Stub",
      "targetDeclaredArguments": [
        "in_AgentName",
        "in_InputData",
        "out_AgentResult",
        "out_DecisionResult"
      ],
      "providedBindings": {
        "Nothing": "[str_AgentOutput]"
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_AgentName",
        "in_InputData",
        "in_AgentName",
        "in_InputData"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process.xaml",
      "targetWorkflow": "AgentInvocation_Stub",
      "targetDeclaredArguments": [
        "in_AgentName",
        "in_InputData",
        "out_AgentResult",
        "out_DecisionResult"
      ],
      "providedBindings": {
        "Nothing": "[bool_AgentDecisionResult]"
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_AgentName",
        "in_InputData",
        "in_AgentName",
        "in_InputData"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications.xaml",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "d6793669e31410227db9fa2d9de4421faaaf57555e82b08ccb4c67b1dd556959",
      "postRepair": "d6793669e31410227db9fa2d9de4421faaaf57555e82b08ccb4c67b1dd556959",
      "postNormalization": "397f28e8538feabfb99ddaa86b487fe7618821f0633f4ae7bd202c4a43628734",
      "preCanonicalization": "397f28e8538feabfb99ddaa86b487fe7618821f0633f4ae7bd202c4a43628734",
      "archivedFile": "e1acc2b2e5b16aa0b8c149f720d42e57219b609b0db3538262abb99a5a45072c",
      "postFinalValidationInput": "e1acc2b2e5b16aa0b8c149f720d42e57219b609b0db3538262abb99a5a45072c",
      "preArchive": "e1acc2b2e5b16aa0b8c149f720d42e57219b609b0db3538262abb99a5a45072c"
    },
    {
      "workflowFile": "GetBirthdays.xaml",
      "postGeneration": "1bda84966cc2bf60e01704539fc2807c0a515cb6a8fdad627abd975e2ba4d2c3",
      "postRepair": "1bda84966cc2bf60e01704539fc2807c0a515cb6a8fdad627abd975e2ba4d2c3",
      "postNormalization": "1bda84966cc2bf60e01704539fc2807c0a515cb6a8fdad627abd975e2ba4d2c3",
      "preCanonicalization": "228d11ddf86f9e49087b7bc27afee3482f3b1fa81946e39e825c7bb385235be8",
      "archivedFile": "63a99c0c26ebe048a059395bb13ae5b84c17a6d0d8c7e0f804c48a7eaf216467",
      "postFinalValidationInput": "63a99c0c26ebe048a059395bb13ae5b84c17a6d0d8c7e0f804c48a7eaf216467",
      "preArchive": "63a99c0c26ebe048a059395bb13ae5b84c17a6d0d8c7e0f804c48a7eaf216467"
    },
    {
      "workflowFile": "ProcessBirthday.xaml",
      "postGeneration": "0f17542b539c625fce5af584db18be14e5c11c7c70b701a2f6d2221fb5b6dd11",
      "postRepair": "0f17542b539c625fce5af584db18be14e5c11c7c70b701a2f6d2221fb5b6dd11",
      "postNormalization": "8b31ecf5e55e17182735399e04e5f6e1ac831ef7c9b5df99944ad9f289bcf61b",
      "preCanonicalization": "8b31ecf5e55e17182735399e04e5f6e1ac831ef7c9b5df99944ad9f289bcf61b",
      "archivedFile": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "postFinalValidationInput": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "preArchive": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0"
    },
    {
      "workflowFile": "ResolveContact.xaml",
      "postGeneration": "b59153d1ecd9a02776168374d1a165f8a3b6c8072a306b9a0325f00507149a5d",
      "postRepair": "b59153d1ecd9a02776168374d1a165f8a3b6c8072a306b9a0325f00507149a5d",
      "postNormalization": "b59153d1ecd9a02776168374d1a165f8a3b6c8072a306b9a0325f00507149a5d",
      "preCanonicalization": "c1d5fc91d00a953d2686cd7423a3d416bb5de8f7ce65c225955dcfcd945ce915",
      "archivedFile": "340733339069cc67f1cf7e73ec97fa72cd9c5cc98e98bbf3503040a93a53da7d",
      "postFinalValidationInput": "340733339069cc67f1cf7e73ec97fa72cd9c5cc98e98bbf3503040a93a53da7d",
      "preArchive": "340733339069cc67f1cf7e73ec97fa72cd9c5cc98e98bbf3503040a93a53da7d"
    },
    {
      "workflowFile": "GenerateAndValidateDraft.xaml",
      "postGeneration": "57e882f1952d21a05ba0e8535370cae3f2f69f524316559277127dbca9031943",
      "postRepair": "57e882f1952d21a05ba0e8535370cae3f2f69f524316559277127dbca9031943",
      "postNormalization": "57e882f1952d21a05ba0e8535370cae3f2f69f524316559277127dbca9031943",
      "preCanonicalization": "443439a291ec7afa4203526c9f7440cea8edb26ecd2d23e7a568b6761f6cb501",
      "archivedFile": "2141e8a83066468eb48942a0cb63d9bbd05d7938541b29471d105a7bf2c1dad3",
      "postFinalValidationInput": "2141e8a83066468eb48942a0cb63d9bbd05d7938541b29471d105a7bf2c1dad3",
      "preArchive": "2141e8a83066468eb48942a0cb63d9bbd05d7938541b29471d105a7bf2c1dad3"
    },
    {
      "workflowFile": "HandleHumanReview.xaml",
      "postGeneration": "b4d33e09400b01bf6f7d3df44ab6c2005407a51066afc95d722dedb31fb7dfc0",
      "postRepair": "b4d33e09400b01bf6f7d3df44ab6c2005407a51066afc95d722dedb31fb7dfc0",
      "postNormalization": "b4d33e09400b01bf6f7d3df44ab6c2005407a51066afc95d722dedb31fb7dfc0",
      "preCanonicalization": "be2e53d558f0c4c9c1e7e3c19fa9cc843ca7de7fa74de32bda34dcdd7af7b08c",
      "archivedFile": "dd6896c2e5bd469e26e9650dc0aeab8b7f837d489fb1a0e934f8135598ec60ba",
      "postFinalValidationInput": "dd6896c2e5bd469e26e9650dc0aeab8b7f837d489fb1a0e934f8135598ec60ba",
      "preArchive": "dd6896c2e5bd469e26e9650dc0aeab8b7f837d489fb1a0e934f8135598ec60ba"
    },
    {
      "workflowFile": "Process.xaml",
      "postGeneration": "02947e682f6c0f403fb2ce21ec6d0c2eca86658e8fded972eea396cbd49c9f70",
      "postRepair": "02947e682f6c0f403fb2ce21ec6d0c2eca86658e8fded972eea396cbd49c9f70",
      "postNormalization": "02947e682f6c0f403fb2ce21ec6d0c2eca86658e8fded972eea396cbd49c9f70",
      "preCanonicalization": "1fbde86835565552191331fae8355adcdc87be034d7623bca076f1951fcde6d1",
      "archivedFile": "67f3ab1ae5a55feca6d9d3c0c760f08dd39d52bed8b9e3d9f634f92272f7f0e2",
      "postFinalValidationInput": "67f3ab1ae5a55feca6d9d3c0c760f08dd39d52bed8b9e3d9f634f92272f7f0e2",
      "preArchive": "67f3ab1ae5a55feca6d9d3c0c760f08dd39d52bed8b9e3d9f634f92272f7f0e2"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "postRepair": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "postNormalization": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "preCanonicalization": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
      "archivedFile": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
      "postFinalValidationInput": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
      "preArchive": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa"
    },
    {
      "workflowFile": "Init.xaml",
      "postGeneration": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "postRepair": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "postNormalization": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "preCanonicalization": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "archivedFile": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "postFinalValidationInput": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "preArchive": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741"
    },
    {
      "workflowFile": "AgentInvocation_Stub.xaml",
      "postGeneration": "1ab25d7751f64ffc740db6d7b8f0efeba0144d7b5753315417db00cee0cd2630",
      "postRepair": "1ab25d7751f64ffc740db6d7b8f0efeba0144d7b5753315417db00cee0cd2630",
      "postNormalization": "1ab25d7751f64ffc740db6d7b8f0efeba0144d7b5753315417db00cee0cd2630",
      "preCanonicalization": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "archivedFile": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "postFinalValidationInput": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "preArchive": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  },
  "invokeSerializationFixes": [
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] START | RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | CalendarName=\\&quot; &amp; In_CalendarName &amp; \\&quot; \"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] START | RunId=\" & In_RunId & \" | CalendarName=\" & In_CalendarName & \" | TimeZone=\" & In_TimeZone]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] Querying Google Calendar | Start=\\&quot; &amp; calendarStartUtc.ToString(\\&quot;o\\&quot;) &amp; \\&quot; | End=\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] Querying Google Calendar | Start=\" & calendarStartUtc.ToString(\"o\") & \" | End=\" & calendarEndUtc.ToString(\"o\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] Google Calendar API call succeeded | RunId=\\&quot; &amp; In_RunId&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] Google Calendar API call succeeded | RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] GoogleCalendarGetEvents returned Nothing (null). Treating as zero events. RunId=\\&quot; &amp; In_RunId&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] GoogleCalendarGetEvents returned Nothing (null). Treating as zero events. RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] Skipped event with empty title | RunId=\\&quot; &amp; In_RunId&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] Skipped event with empty title | RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] Work item added | FullNameNormalized=\\&quot; &amp; normalizedName &amp; \\&quot; | EventId=\\&quot; &amp; calend\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] Work item added | FullNameNormalized=\" & normalizedName & \" | EventId=\" & calendarEventId & \" | RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] END | BirthdaysFound=\\&quot; &amp; birthdayCount.ToString() &amp; \\&quot; | RunId=\\&quot; &amp; In_RunId&quot;\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] END | BirthdaysFound=\" & birthdayCount.ToString() & \" | RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] START — RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | FullNameNormalized=\\&quot; &amp; In_FullNameNorma\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] START — RunId=\" & In_RunId & \" | FullNameNormalized=\" & In_FullNameNormalized]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] GSuite Contacts search completed for name='\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;'. Result \"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] GSuite Contacts search completed for name='\" & In_FullNameNormalized & \"'. Result null=\" & (contactsSearchResult Is Nothing).ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][WARN] GoogleContactsSearchContacts returned Nothing for name='\\&quot; &amp; In_FullNameNormalized &amp; \\&qu\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][WARN] GoogleContactsSearchContacts returned Nothing for name='\" & In_FullNameNormalized & \"'. Treating as zero matches.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] Match count for '\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;': \\&quot; &amp; matchCount.ToString\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] Match count for '\" & In_FullNameNormalized & \"': \" & matchCount.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] No exact contact match for '\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;'. Setting skip=NoContact\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] No exact contact match for '\" & In_FullNameNormalized & \"'. Setting skip=NoContact.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] Email resolution for '\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;' — Personal='\\&quot; &amp; If(\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] Email resolution for '\" & In_FullNameNormalized & \"' — Personal='\" & If(String.IsNullOrEmpty(personalEmail), \"(none)\", personalEmail) & \"' Home='\" & If(String.IsNullOrEmpty(homeEmail), \"(none)\", homeEmail) & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] Selected Personal email for '\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;': \\&quot; &amp; resolve\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] Selected Personal email for '\" & In_FullNameNormalized & \"': \" & resolvedEmail]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] Selected Home email for '\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;' (no Personal label found):\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] Selected Home email for '\" & In_FullNameNormalized & \"' (no Personal label found): \" & resolvedEmail]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] No Personal or Home email found for '\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;'. Setting skip=\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] No Personal or Home email found for '\" & In_FullNameNormalized & \"'. Setting skip=NoEligibleEmail.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][WARN] Ambiguous match: \\&quot; &amp; matchCount.ToString() &amp; \\&quot; contacts found for '\\&quot; &amp; I\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][WARN] Ambiguous match: \" & matchCount.ToString() & \" contacts found for '\" & In_FullNameNormalized & \"'. Action Center disambiguation required.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][INFO] END — RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | Name='\\&quot; &amp; In_FullNameNormalized &amp; \\&q\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][INFO] END — RunId=\" & In_RunId & \" | Name='\" & In_FullNameNormalized & \"' | ShouldSkip=\" & Out_ShouldSkip.ToString() & \" | SkipReason='\" & Out_SkipReason & \"' | IsAmbiguous=\" & Out_IsAmbiguous.ToString() & \" | RecipientEmail='\" & If(String.IsNullOrEmpty(Out_RecipientEmail), \"(none)\", Out_RecipientEmail) & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ResolveContact][ERROR] GSuite API exception for '\\&quot; &amp; In_FullNameNormalized &amp; \\&quot;' RunId=\\&quot; &amp; In_R\"",
      "canonicalizedForm": "Message=\"[\"[ResolveContact][ERROR] GSuite API exception for '\" & In_FullNameNormalized & \"' RunId=\" & In_RunId & \" | ExceptionType=\" & ex.GetType().Name & \" | Message=\" & ex.Message]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;contactsSearchResult&quot;}\"",
      "canonicalizedForm": "Result=\"[contactsSearchResult]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ugs:GoogleContactsSearchContacts",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;contactEmailLabels&quot;}\"",
      "canonicalizedForm": "Result=\"[contactEmailLabels]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ugs:GoogleContactsGetContact",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] START — FullName='\\&quot; &amp; In_FullName &amp; \\&quot;' RunId='\\&quot; &amp; In_RunId &amp; \\&q\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] START — FullName='\" & In_FullName & \"' RunId='\" & In_RunId & \"' WordCountRange=[\" & In_WordCountMin.ToString() & \"-\" & In_WordCountMax.ToString() & \"]\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=\\&quot; &amp; genAiPrompt.Length.ToString() &amp; \\&quot;). Invokin\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] GenAI prompt assembled (length=\" & genAiPrompt.Length.ToString() & \"). Invoking GenAI activity.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] GenAI invocation attempt \\&quot; &amp; genAiAttempt.ToString() &amp; \\&quot; for FullName='\\&quot;\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] GenAI invocation attempt \" & genAiAttempt.ToString() & \" for FullName='\" & In_FullName & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] GenAI response received (length=\\&quot; &amp; If(genAiRawResponse IsNot Nothing, genAiRawResponse.\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] GenAI response received (length=\" & If(genAiRawResponse IsNot Nothing, genAiRawResponse.Length.ToString(), \"NULL\") & \") on attempt \" & genAiAttempt.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] JSON parsed. Subject length=\\&quot; &amp; parsedSubject.Length.ToString() &amp; \\&quot; Body lengt\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] JSON parsed. Subject length=\" & parsedSubject.Length.ToString() & \" Body length=\" & parsedBody.Length.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] Validation complete — FullName='\\&quot; &amp; In_FullName &amp; \\&quot;' Passed=\\&quot; &amp; vali\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] Validation complete — FullName='\" & In_FullName & \"' Passed=\" & validationPassed.ToString() & \" WordCount=\" & wordCount.ToString() & \" ContainsEmoji=\" & containsEmoji.ToString() & \" Notes='\" & If(String.IsNullOrEmpty(validationNotes), \"none\", validationNotes) & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Exception=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New System.Exception(\\&quot;GenAI returned null or empty response for FullName='\\&quot; &amp; In_FullName &amp; \\&quot;'. Cannot par\"",
      "canonicalizedForm": "Exception=\"[New System.Exception(\"GenAI returned null or empty response for FullName='\" & In_FullName & \"'. Cannot parse subject/body.\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Throw",
      "propertyName": "Exception",
      "rationale": "JSON expression leak in Exception normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] ENTER | TaskType=\\&quot; &amp; In_TaskType &amp; \\&quot; | RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | F\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] ENTER | TaskType=\" & In_TaskType & \" | RunId=\" & In_RunId & \" | FullName=\" & In_FullName & \" | RecipientEmail=\" & In_RecipientEmail & \" | SentLogId=\" & In_SentLogId & \" | DraftId=\" & In_DraftId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Creating Action Center task | Title=\\&quot; &amp; taskTitle &amp; \\&quot; | SentLogId=\\&quot; &amp; In_Se\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Creating Action Center task | Title=\" & taskTitle & \" | SentLogId=\" & In_SentLogId & \" | DraftId=\" & In_DraftId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] ERROR: Action Center task creation failed | TaskType=\\&quot; &amp; In_TaskType &amp; \\&quot; | FullName=\\\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] ERROR: Action Center task creation failed | TaskType=\" & In_TaskType & \" | FullName=\" & In_FullName & \" | RunId=\" & In_RunId & \" | SentLogId=\" & In_SentLogId & \" | Consequence=PersonSkipped\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Waiting for reviewer response | TaskType=\\&quot; &amp; In_TaskType &amp; \\&quot; | FullName=\\&quot; &amp;\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Waiting for reviewer response | TaskType=\" & In_TaskType & \" | FullName=\" & In_FullName & \" | RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] ERROR: WaitForFormTaskAndResume failed | TaskType=\\&quot; &amp; In_TaskType &amp; \\&quot; | FullName=\\&qu\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] ERROR: WaitForFormTaskAndResume failed | TaskType=\" & In_TaskType & \" | FullName=\" & In_FullName & \" | RunId=\" & In_RunId & \" | Consequence=PersonSkipped\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Reviewer response received | TaskType=\\&quot; &amp; In_TaskType &amp; \\&quot; | FullName=\\&quot; &amp; In\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Reviewer response received | TaskType=\" & In_TaskType & \" | FullName=\" & In_FullName & \" | RunId=\" & In_RunId & \" | FormDataCount=\" & taskFormData.Count.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Reviewer decision extracted | Decision=\\&quot; &amp; reviewDecision &amp; \\&quot; | FullName=\\&quot; &amp\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Reviewer decision extracted | Decision=\" & reviewDecision & \" | FullName=\" & In_FullName & \" | RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Decision=APPROVED | FullName=\\&quot; &amp; In_FullName &amp; \\&quot; | RunId=\\&quot; &amp; In_RunId &amp;\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Decision=APPROVED | FullName=\" & In_FullName & \" | RunId=\" & In_RunId & \" | Decision=\" & reviewDecision]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Decision=REJECTED/SKIP | FullName=\\&quot; &amp; In_FullName &amp; \\&quot; | RunId=\\&quot; &amp; In_RunId \"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Decision=REJECTED/SKIP | FullName=\" & In_FullName & \" | RunId=\" & In_RunId & \" | Decision=\" & reviewDecision & \" | ReviewerComments=\" & reviewerComments]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Info] Entered Finalize. RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | RunStatus=\\&quot; &amp; In_RunStatus &amp; \\&\"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Info] Entered Finalize. RunId=\" & In_RunId & \" | RunStatus=\" & In_RunStatus & \" | BirthdaysFound=\" & In_BirthdaysFound.ToString() & \" | SentCount=\" & In_SentCount.ToString() & \" | SkippedCount=\" & In_SkippedCount.ToString() & \" | ErrorCount=\" & In_ErrorCount.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Info] Attempting Data Service UpdateEntity for BGV26_Run. RunId=\\&quot; &amp; In_RunId&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Info] Attempting Data Service UpdateEntity for BGV26_Run. RunId=\" & In_RunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Info] BGV26_Run record updated successfully in Data Service. RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | EndTimeU\"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Info] BGV26_Run record updated successfully in Data Service. RunId=\" & In_RunId & \" | EndTimeUtc=\" & endTimeUtc.ToString(\"yyyy-MM-dd HH:mm:ss\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Warn] Data Service UpdateEntity for BGV26_Run FAILED. RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | ExceptionType=\\\"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Warn] Data Service UpdateEntity for BGV26_Run FAILED. RunId=\" & In_RunId & \" | ExceptionType=\" & dataServiceException.GetType().Name & \" | Message=\" & dataServiceException]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Info] Attempting to send daily summary email. To=\\&quot; &amp; operatorEmail &amp; \\&quot; | ConnectionName=\\&quot\"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Info] Attempting to send daily summary email. To=\" & operatorEmail & \" | ConnectionName=\" & In_GmailConnectionName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Info] Daily summary email sent successfully. To=\\&quot; &amp; operatorEmail &amp; \\&quot; | Subject=\\&quot; &amp; \"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Info] Daily summary email sent successfully. To=\" & operatorEmail & \" | Subject=\" & summarySubject]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Warn] Summary email send FAILED. To=\\&quot; &amp; operatorEmail &amp; \\&quot; | RunId=\\&quot; &amp; In_RunId &amp;\"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Warn] Summary email send FAILED. To=\" & operatorEmail & \" | RunId=\" & In_RunId & \" | Error=\" & emailException]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Finalize][Info] Finalize complete. RunId=\\&quot; &amp; In_RunId &amp; \\&quot; | FinalRunStatus=\\&quot; &amp; In_RunStatus &a\"",
      "canonicalizedForm": "Message=\"[\"[Finalize][Info] Finalize complete. RunId=\" & In_RunId & \" | FinalRunStatus=\" & In_RunStatus & \" | DataServiceUpdated=\" & dataServiceUpdateSucceeded.ToString() & \" | SummaryEmailSent=\" & summaryEmailSucceeded.ToString() & \" | EndTimeUtc=\" & endTimeUtc.ToString(\"yyyy-MM-dd HH:mm:ss\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "To=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;operatorEmail&quot;}\"",
      "canonicalizedForm": "To=\"[operatorEmail]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ugs:GmailSendMessage",
      "propertyName": "To",
      "rationale": "JSON expression leak in To normalized to VB expression"
    }
  ],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_Config",
      "offendingExpression": "io_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_Config\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_QueueName",
      "offendingExpression": "in_QueueName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_QueueName\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionItem",
      "offendingExpression": "out_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_TransactionNumber",
      "offendingExpression": "io_TransactionNumber",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_TransactionNumber\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[GetBirthdays] START | RunId=&quot; &amp; In_RunId &amp; &quot; | CalendarName=&quot; &amp; In_CalendarName &amp; &quot; | TimeZone=&quot; &amp; In_TimeZone]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_CalendarName",
      "offendingExpression": "[&quot;[GetBirthdays] START | RunId=&quot; &amp; In_RunId &amp; &quot; | CalendarName=&quot; &amp; In_CalendarName &amp; &quot; | TimeZone=&quot; &amp; In_TimeZone]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_CalendarName\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_TimeZone",
      "offendingExpression": "[&quot;[GetBirthdays] START | RunId=&quot; &amp; In_RunId &amp; &quot; | CalendarName=&quot; &amp; In_CalendarName &amp; &quot; | TimeZone=&quot; &amp; In_TimeZone]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_TimeZone\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "calendarStartUtc",
      "offendingExpression": "[&quot;[GetBirthdays] Querying Google Calendar | Start=&quot; &amp; calendarStartUtc.ToString(&quot;o&quot;) &amp; &quot; | End=&quot; &amp; calendarEndUtc.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"calendarStartUtc\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "calendarEndUtc",
      "offendingExpression": "[&quot;[GetBirthdays] Querying Google Calendar | Start=&quot; &amp; calendarStartUtc.ToString(&quot;o&quot;) &amp; &quot; | End=&quot; &amp; calendarEndUtc.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"calendarEndUtc\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[GetBirthdays] Google Calendar API call succeeded | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[GetBirthdays] GoogleCalendarGetEvents returned Nothing (null). Treating as zero events. RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[GetBirthdays] Skipped event with empty title | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "normalizedName",
      "offendingExpression": "[&quot;[GetBirthdays] Work item added | FullNameNormalized=&quot; &amp; normalizedName &amp; &quot; | EventId=&quot; &amp; calendarEventId &amp; &quot; | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"normalizedName\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "calendarEventId",
      "offendingExpression": "[&quot;[GetBirthdays] Work item added | FullNameNormalized=&quot; &amp; normalizedName &amp; &quot; | EventId=&quot; &amp; calendarEventId &amp; &quot; | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"calendarEventId\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "birthdayCount",
      "offendingExpression": "[&quot;[GetBirthdays] END | BirthdaysFound=&quot; &amp; birthdayCount.ToString() &amp; &quot; | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"birthdayCount\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "In_TimeZone",
      "offendingExpression": "[TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(In_TimeZone))]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_TimeZone\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "todayLocal",
      "offendingExpression": "[TimeZoneInfo.ConvertTimeToUtc(New DateTime(todayLocal.Year, todayLocal.Month, todayLocal.Day, 0, 0, 0), TimeZoneInfo.FindSystemTimeZoneById(In_TimeZone))]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"todayLocal\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "todayLocal",
      "offendingExpression": "[TimeZoneInfo.ConvertTimeToUtc(New DateTime(todayLocal.Year, todayLocal.Month, todayLocal.Day, 23, 59, 59), TimeZoneInfo.FindSystemTimeZoneById(In_TimeZone))]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"todayLocal\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentEvent",
      "offendingExpression": "[If(currentEvent IsNot Nothing AndAlso currentEvent.Summary IsNot Nothing, currentEvent.Summary.ToString(), String.Empty)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentEvent\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "birthdayWorkItems",
      "offendingExpression": "[birthdayWorkItems.Rows.Count]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"birthdayWorkItems\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[ResolveContact][INFO] START — RunId=&quot; &amp; In_RunId &amp; &quot; | FullNameNormalized=&quot; &amp; In_FullNameNormalized]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullNameNormalized",
      "offendingExpression": "[&quot;[ResolveContact][INFO] START — RunId=&quot; &amp; In_RunId &amp; &quot; | FullNameNormalized=&quot; &amp; In_FullNameNormalized]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullNameNormalized\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ugs:GoogleContactsSearchContacts",
      "propertyName": "Result",
      "referencedSymbol": "contactsSearchResult",
      "offendingExpression": "[contactsSearchResult]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"contactsSearchResult\" referenced in Result but not declared in workflow \"ResolveContact\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "contactsSearchResult",
      "offendingExpression": "[&quot;[ResolveContact][INFO] GSuite Contacts search completed for name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos;. Result null=&quot; &amp; (contactsSearchResult Is Nothing).ToString",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"contactsSearchResult\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullNameNormalized",
      "offendingExpression": "[&quot;[ResolveContact][WARN] GoogleContactsSearchContacts returned Nothing for name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos;. Treating as zero matches.&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullNameNormalized\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "matchCount",
      "offendingExpression": "[&quot;[ResolveContact][INFO] Match count for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos;: &quot; &amp; matchCount.ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"matchCount\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullNameNormalized",
      "offendingExpression": "[&quot;[ResolveContact][INFO] No exact contact match for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos;. Setting skip=NoContact.&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullNameNormalized\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ugs:GoogleContactsGetContact",
      "propertyName": "Result",
      "referencedSymbol": "contactEmailLabels",
      "offendingExpression": "[contactEmailLabels]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"contactEmailLabels\" referenced in Result but not declared in workflow \"ResolveContact\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullNameNormalized",
      "offendingExpression": "[&quot;[ResolveContact][INFO] Email resolution for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; — Personal=&apos;&quot; &amp; If(String.IsNullOrEmpty(personalEmail), &quot;(none)&quot;,",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullNameNormalized\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "personalEmail",
      "offendingExpression": "[Not String.IsNullOrWhiteSpace(personalEmail)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"personalEmail\" referenced in Condition but not declared in workflow \"ResolveContact\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "resolvedEmail",
      "offendingExpression": "[&quot;[ResolveContact][INFO] Selected Personal email for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos;: &quot; &amp; resolvedEmail]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedEmail\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "homeEmail",
      "offendingExpression": "[Not String.IsNullOrWhiteSpace(homeEmail)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"homeEmail\" referenced in Condition but not declared in workflow \"ResolveContact\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "resolvedEmail",
      "offendingExpression": "[&quot;[ResolveContact][INFO] Selected Home email for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; (no Personal label found): &quot; &amp; resolvedEmail]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedEmail\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullNameNormalized",
      "offendingExpression": "[&quot;[ResolveContact][INFO] No Personal or Home email found for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos;. Setting skip=NoEligibleEmail.&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullNameNormalized\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullNameNormalized",
      "offendingExpression": "[&quot;[ResolveContact][WARN] Ambiguous match: &quot; &amp; matchCount.ToString() &amp; &quot; contacts found for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos;. Action Center disambiguat",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullNameNormalized\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[ResolveContact][INFO] END — RunId=&quot; &amp; In_RunId &amp; &quot; | Name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; | ShouldSkip=&quot; &amp; Out_ShouldSkip.ToString() &amp",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullNameNormalized",
      "offendingExpression": "[&quot;[ResolveContact][INFO] END — RunId=&quot; &amp; In_RunId &amp; &quot; | Name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; | ShouldSkip=&quot; &amp; Out_ShouldSkip.ToString() &amp",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullNameNormalized\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Out_ShouldSkip",
      "offendingExpression": "[&quot;[ResolveContact][INFO] END — RunId=&quot; &amp; In_RunId &amp; &quot; | Name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; | ShouldSkip=&quot; &amp; Out_ShouldSkip.ToString() &amp",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"Out_ShouldSkip\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Out_SkipReason",
      "offendingExpression": "[&quot;[ResolveContact][INFO] END — RunId=&quot; &amp; In_RunId &amp; &quot; | Name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; | ShouldSkip=&quot; &amp; Out_ShouldSkip.ToString() &amp",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"Out_SkipReason\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Out_IsAmbiguous",
      "offendingExpression": "[&quot;[ResolveContact][INFO] END — RunId=&quot; &amp; In_RunId &amp; &quot; | Name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; | ShouldSkip=&quot; &amp; Out_ShouldSkip.ToString() &amp",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"Out_IsAmbiguous\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Out_RecipientEmail",
      "offendingExpression": "[&quot;[ResolveContact][INFO] END — RunId=&quot; &amp; In_RunId &amp; &quot; | Name=&apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; | ShouldSkip=&quot; &amp; Out_ShouldSkip.ToString() &amp",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"Out_RecipientEmail\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "ex",
      "offendingExpression": "[&quot;[ResolveContact][ERROR] GSuite API exception for &apos;&quot; &amp; In_FullNameNormalized &amp; &quot;&apos; RunId=&quot; &amp; In_RunId &amp; &quot; | ExceptionType=&quot; &amp; ex.GetType().N",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"ex\" referenced in Message but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "contactsSearchResult",
      "offendingExpression": "[If(TypeOf contactsSearchResult Is IEnumerable(Of Object), DirectCast(contactsSearchResult, IEnumerable(Of Object)).Count(), 0)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"contactsSearchResult\" referenced in child element <Assign.Value> but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "contactsSearchResult",
      "offendingExpression": "[DirectCast(contactsSearchResult, IEnumerable(Of Object)).First()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"contactsSearchResult\" referenced in child element <Assign.Value> but not declared in workflow \"ResolveContact\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; In_FullName &amp; &quot;&apos; RunId=&apos;&quot; &amp; In_RunId &amp; &quot;&apos; WordCountRange=[&quot; &amp; In_WordCountMin.T",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; In_FullName &amp; &quot;&apos; RunId=&apos;&quot; &amp; In_RunId &amp; &quot;&apos; WordCountRange=[&quot; &amp; In_WordCountMin.T",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_WordCountMin",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; In_FullName &amp; &quot;&apos; RunId=&apos;&quot; &amp; In_RunId &amp; &quot;&apos; WordCountRange=[&quot; &amp; In_WordCountMin.T",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_WordCountMin\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_WordCountMax",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; In_FullName &amp; &quot;&apos; RunId=&apos;&quot; &amp; In_RunId &amp; &quot;&apos; WordCountRange=[&quot; &amp; In_WordCountMin.T",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_WordCountMax\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] GenAI invocation attempt &quot; &amp; genAiAttempt.ToString() &amp; &quot; for FullName=&apos;&quot; &amp; In_FullName &amp; &quot;&apos;&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "genAiRawResponse",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] GenAI response received (length=&quot; &amp; If(genAiRawResponse IsNot Nothing, genAiRawResponse.Length.ToString(), &quot;NULL&quot;) &amp; &quot;) on attempt &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"genAiRawResponse\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "genAiAttempt",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] GenAI response received (length=&quot; &amp; If(genAiRawResponse IsNot Nothing, genAiRawResponse.Length.ToString(), &quot;NULL&quot;) &amp; &quot;) on attempt &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"genAiAttempt\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[New System.Exception(&quot;GenAI returned null or empty response for FullName=&apos;&quot; &amp; In_FullName &amp; &quot;&apos;. Cannot parse subject/body.&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Exception but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "parsedSubject",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] JSON parsed. Subject length=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; Body length=&quot; &amp; parsedBody.Length.ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"parsedSubject\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "parsedBody",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] JSON parsed. Subject length=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; Body length=&quot; &amp; parsedBody.Length.ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"parsedBody\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "In_WordCountMin",
      "offendingExpression": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&lt;&quot;,&quot;right&quot;:&quot;In_WordCountMin&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_WordCountMin\" referenced in Condition but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "In_WordCountMax",
      "offendingExpression": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;In_WordCountMax&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_WordCountMax\" referenced in Condition but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[&quot;[GenerateAndValidateDraft] Validation complete — FullName=&apos;&quot; &amp; In_FullName &amp; &quot;&apos; Passed=&quot; &amp; validationPassed.ToString() &amp; &quot; WordCount=&quot; &amp; w",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Message but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "genAiAttempt",
      "offendingExpression": "[genAiAttempt + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"genAiAttempt\" referenced in child element <Assign.Value> but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "validationNotes",
      "offendingExpression": "[String.IsNullOrWhiteSpace(validationNotes)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationNotes\" referenced in child element <Assign.Value> but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_TaskType",
      "offendingExpression": "[&quot;[HandleHumanReview] ENTER | TaskType=&quot; &amp; In_TaskType &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RecipientEmail=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_TaskType\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[HandleHumanReview] ENTER | TaskType=&quot; &amp; In_TaskType &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RecipientEmail=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[&quot;[HandleHumanReview] ENTER | TaskType=&quot; &amp; In_TaskType &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RecipientEmail=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RecipientEmail",
      "offendingExpression": "[&quot;[HandleHumanReview] ENTER | TaskType=&quot; &amp; In_TaskType &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RecipientEmail=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RecipientEmail\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_SentLogId",
      "offendingExpression": "[&quot;[HandleHumanReview] ENTER | TaskType=&quot; &amp; In_TaskType &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RecipientEmail=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_SentLogId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_DraftId",
      "offendingExpression": "[&quot;[HandleHumanReview] ENTER | TaskType=&quot; &amp; In_TaskType &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RecipientEmail=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_DraftId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskTitle",
      "offendingExpression": "[&quot;[HandleHumanReview] Creating Action Center task | Title=&quot; &amp; taskTitle &amp; &quot; | SentLogId=&quot; &amp; In_SentLogId &amp; &quot; | DraftId=&quot; &amp; In_DraftId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskTitle\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_TaskType",
      "offendingExpression": "[&quot;[HandleHumanReview] ERROR: Action Center task creation failed | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_TaskType\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[&quot;[HandleHumanReview] ERROR: Action Center task creation failed | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[HandleHumanReview] ERROR: Action Center task creation failed | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_SentLogId",
      "offendingExpression": "[&quot;[HandleHumanReview] ERROR: Action Center task creation failed | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_SentLogId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_TaskType",
      "offendingExpression": "[&quot;[HandleHumanReview] Waiting for reviewer response | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_TaskType\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[&quot;[HandleHumanReview] Waiting for reviewer response | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[HandleHumanReview] Waiting for reviewer response | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_TaskType",
      "offendingExpression": "[&quot;[HandleHumanReview] ERROR: WaitForFormTaskAndResume failed | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_TaskType\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_FullName",
      "offendingExpression": "[&quot;[HandleHumanReview] ERROR: WaitForFormTaskAndResume failed | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_FullName\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[HandleHumanReview] ERROR: WaitForFormTaskAndResume failed | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskFormData",
      "offendingExpression": "[&quot;[HandleHumanReview] Reviewer response received | TaskType=&quot; &amp; In_TaskType &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | For",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskFormData\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "reviewDecision",
      "offendingExpression": "[&quot;[HandleHumanReview] Reviewer decision extracted | Decision=&quot; &amp; reviewDecision &amp; &quot; | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"reviewDecision\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "reviewDecision",
      "offendingExpression": "[&quot;[HandleHumanReview] Decision=APPROVED | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | Decision=&quot; &amp; reviewDecision]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"reviewDecision\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "reviewDecision",
      "offendingExpression": "[&quot;[HandleHumanReview] Decision=REJECTED/SKIP | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | Decision=&quot; &amp; reviewDecision &amp; &quot; | Revi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"reviewDecision\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "reviewerComments",
      "offendingExpression": "[&quot;[HandleHumanReview] Decision=REJECTED/SKIP | FullName=&quot; &amp; In_FullName &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | Decision=&quot; &amp; reviewDecision &amp; &quot; | Revi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"reviewerComments\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "Reject",
      "offendingExpression": "[Reject]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Reject\" referenced in child element <Assign.Value> but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "Reject",
      "offendingExpression": "[Reject]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Reject\" referenced in child element <Assign.Value> but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "value",
      "offendingExpression": "[value]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"value\" referenced in child element <Assign.Value> but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[Finalize][Info] Entered Finalize. RunId=&quot; &amp; In_RunId &amp; &quot; | RunStatus=&quot; &amp; In_RunStatus &amp; &quot; | BirthdaysFound=&quot; &amp; In_BirthdaysFound.ToString() &amp; &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunStatus",
      "offendingExpression": "[&quot;[Finalize][Info] Entered Finalize. RunId=&quot; &amp; In_RunId &amp; &quot; | RunStatus=&quot; &amp; In_RunStatus &amp; &quot; | BirthdaysFound=&quot; &amp; In_BirthdaysFound.ToString() &amp; &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunStatus\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_BirthdaysFound",
      "offendingExpression": "[&quot;[Finalize][Info] Entered Finalize. RunId=&quot; &amp; In_RunId &amp; &quot; | RunStatus=&quot; &amp; In_RunStatus &amp; &quot; | BirthdaysFound=&quot; &amp; In_BirthdaysFound.ToString() &amp; &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_BirthdaysFound\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_SentCount",
      "offendingExpression": "[&quot;[Finalize][Info] Entered Finalize. RunId=&quot; &amp; In_RunId &amp; &quot; | RunStatus=&quot; &amp; In_RunStatus &amp; &quot; | BirthdaysFound=&quot; &amp; In_BirthdaysFound.ToString() &amp; &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_SentCount\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_SkippedCount",
      "offendingExpression": "[&quot;[Finalize][Info] Entered Finalize. RunId=&quot; &amp; In_RunId &amp; &quot; | RunStatus=&quot; &amp; In_RunStatus &amp; &quot; | BirthdaysFound=&quot; &amp; In_BirthdaysFound.ToString() &amp; &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_SkippedCount\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_ErrorCount",
      "offendingExpression": "[&quot;[Finalize][Info] Entered Finalize. RunId=&quot; &amp; In_RunId &amp; &quot; | RunStatus=&quot; &amp; In_RunStatus &amp; &quot; | BirthdaysFound=&quot; &amp; In_BirthdaysFound.ToString() &amp; &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_ErrorCount\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "In_RunId",
      "offendingExpression": "[&quot;[Finalize][Info] Attempting Data Service UpdateEntity for BGV26_Run. RunId=&quot; &amp; In_RunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"In_RunId\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "endTimeUtc",
      "offendingExpression": "[&quot;[Finalize][Info] BGV26_Run record updated successfully in Data Service. RunId=&quot; &amp; In_RunId &amp; &quot; | EndTimeUtc=&quot; &amp; endTimeUtc.ToString(&quot;yyyy-MM-dd HH:mm:ss&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"endTimeUtc\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dataServiceException",
      "offendingExpression": "[&quot;[Finalize][Warn] Data Service UpdateEntity for BGV26_Run FAILED. RunId=&quot; &amp; In_RunId &amp; &quot; | ExceptionType=&quot; &amp; dataServiceException.GetType().Name &amp; &quot; | Message",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dataServiceException\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "operatorEmail",
      "offendingExpression": "[&quot;[Finalize][Info] Attempting to send daily summary email. To=&quot; &amp; operatorEmail &amp; &quot; | ConnectionName=&quot; &amp; In_GmailConnectionName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"operatorEmail\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ugs:GmailSendMessage",
      "propertyName": "To",
      "referencedSymbol": "operatorEmail",
      "offendingExpression": "[operatorEmail]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"operatorEmail\" referenced in To but not declared in workflow \"Finalize\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "operatorEmail",
      "offendingExpression": "[&quot;[Finalize][Info] Daily summary email sent successfully. To=&quot; &amp; operatorEmail &amp; &quot; | Subject=&quot; &amp; summarySubject]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"operatorEmail\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "summarySubject",
      "offendingExpression": "[&quot;[Finalize][Info] Daily summary email sent successfully. To=&quot; &amp; operatorEmail &amp; &quot; | Subject=&quot; &amp; summarySubject]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"summarySubject\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "operatorEmail",
      "offendingExpression": "[&quot;[Finalize][Warn] Summary email send FAILED. To=&quot; &amp; operatorEmail &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | Error=&quot; &amp; emailException]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"operatorEmail\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "emailException",
      "offendingExpression": "[&quot;[Finalize][Warn] Summary email send FAILED. To=&quot; &amp; operatorEmail &amp; &quot; | RunId=&quot; &amp; In_RunId &amp; &quot; | Error=&quot; &amp; emailException]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"emailException\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dataServiceUpdateSucceeded",
      "offendingExpression": "[&quot;[Finalize][Info] Finalize complete. RunId=&quot; &amp; In_RunId &amp; &quot; | FinalRunStatus=&quot; &amp; In_RunStatus &amp; &quot; | DataServiceUpdated=&quot; &amp; dataServiceUpdateSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dataServiceUpdateSucceeded\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "summaryEmailSucceeded",
      "offendingExpression": "[&quot;[Finalize][Info] Finalize complete. RunId=&quot; &amp; In_RunId &amp; &quot; | FinalRunStatus=&quot; &amp; In_RunStatus &amp; &quot; | DataServiceUpdated=&quot; &amp; dataServiceUpdateSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"summaryEmailSucceeded\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "endTimeUtc",
      "offendingExpression": "[&quot;[Finalize][Info] Finalize complete. RunId=&quot; &amp; In_RunId &amp; &quot; | FinalRunStatus=&quot; &amp; In_RunStatus &amp; &quot; | DataServiceUpdated=&quot; &amp; dataServiceUpdateSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"endTimeUtc\" referenced in Message but not declared in workflow \"Finalize\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "No",
      "offendingExpression": "[No]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"No\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "No",
      "offendingExpression": "[No]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"No\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_AgentName",
      "offendingExpression": "in_AgentName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_AgentName\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_InputData",
      "offendingExpression": "in_InputData",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_InputData\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_AgentResult",
      "offendingExpression": "out_AgentResult",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_AgentResult\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_AgentName",
      "offendingExpression": "in_AgentName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_AgentName\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_InputData",
      "offendingExpression": "in_InputData",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_InputData\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_DecisionResult",
      "offendingExpression": "out_DecisionResult",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_DecisionResult\" referenced in Key but not declared in workflow \"Process\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Init.xaml",
      "workflow": "Init",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_Config",
      "offendingExpression": "out_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_Config\" referenced in Key but not declared in workflow \"Init\" — expression replaced with \"Nothing\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 118 symbol scope defect(s), 4 sentinel replacement(s), 89 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;rawCalendarEvents&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(rawEventTitle)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ProcessBirthday — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactsSearchResult&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Switch",
      "propertyName": "Expression",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(matchCount = 0, \\&quot;zero\\&quot;, If(matchCount = 1, \\&quot;one\\&quot;, \\&quot;many\\&quot;))&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Expression — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:ShouldRetry",
      "propertyName": "Condition",
      "originalValue": "{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isGenAiSuccess&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(genAiRawResponse)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedSubject)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedBody)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&lt;&quot;,&quot;right&quot;:&quot;In_WordCountMin&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;In_WordCountMax&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskCreationFailed&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskWaitFailed&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;reviewDecision = \\&quot;Approve\\&quot; OrElse reviewDecision = \\&quot;EditAndApprove\\&quot; OrElse reviewDecision = \\&quot;SelectEm",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    }
  ],
  "sentinelReplacements": [
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ProcessBirthday — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: ProcessBirthday — this workflow was auto-generated as a placeholder\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "umail:SendSmtpMailMessage",
      "propertyName": "To",
      "originalValue": "TODO: Set recipient email",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "todo_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"TODO: Set recipient email\" in executable property To replaced with platform-safe value \"Nothing\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "umail:SendSmtpMailMessage",
      "propertyName": "To",
      "originalValue": "TODO: Set recipient email",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "todo_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"TODO: Set recipient email\" in executable property To replaced with platform-safe value \"Nothing\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "umail:SendSmtpMailMessage",
      "propertyName": "To",
      "originalValue": "TODO: Set recipient email",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "todo_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"TODO: Set recipient email\" in executable property To replaced with platform-safe value \"Nothing\" — not executable, degradation substitute"
    }
  ],
  "unresolvableJsonDefects": [
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;todayLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarStartUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarEndUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_BirthdayWorkItems&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawEventTitle&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;normalizedName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarEventId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_BirthdayWorkItems&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayWorkItems&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;System.Text.RegularExpressions.Regex.Replace(rawEventTitle.Trim(), \\&quot;\\\\s+\\&quot;, \\&quot; \\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentEvent IsNot Nothing AndAlso currentEvent.Id IsNot Nothing, currentEvent.Id.ToString(), \\&quot;UNKNOWN_\\&quot; &amp; rawEv",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayWorkItems&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;gsuiteLookupSucceeded&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;matchCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;matchCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;firstMatchedContact&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;personalEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;homeEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;candidateSummaryBuilder&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(contactEmailLabels IsNot Nothing, \\&quot;\\&quot;, String.Empty)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(contactEmailLabels IsNot Nothing, \\&quot;\\&quot;, String.Empty)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(\\&quot;; \\&quot;, DirectCast(contactsSearchResult, IEnumerable(Of Object)).Select(Function(c, i) \\&quot;[\\&quot; &amp; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiPrompt&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiAttempt&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isGenAiSuccess&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiAttempt&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isGenAiSuccess&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;parsedSubject&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;parsedBody&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationNotes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationNotes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationNotes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;wordCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationNotes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationNotes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;containsEmoji&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationNotes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationPassed&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;In_StyleSpec &amp; System.Environment.NewLine &amp; System.Environment.NewLine &amp; \\&quot;Recipient Full Name: \\&quot; &amp; In_F",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(jsonToken(\\&quot;subject\\&quot;) IsNot Nothing, jsonToken(\\&quot;subject\\&quot;).ToString().Trim(), \\&quot;\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(jsonToken(\\&quot;body\\&quot;) IsNot Nothing, jsonToken(\\&quot;body\\&quot;).ToString().Trim(), \\&quot;\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationNotes &amp; If(validationNotes.Length &gt; 0, \\&quot;; \\&quot;, \\&quot;\\&quot;) &amp; \\&quot;FAIL:SubjectEmpty\\&quot;&quo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationNotes &amp; If(validationNotes.Length &gt; 0, \\&quot;; \\&quot;, \\&quot;\\&quot;) &amp; \\&quot;FAIL:BodyEmpty\\&quot;&quot;}",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrWhiteSpace(parsedBody), 0, parsedBody.Split(New Char(){\\&quot; \\&quot;c, System.Environment.NewLine(0), System.En",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationNotes &amp; If(validationNotes.Length &gt; 0, \\&quot;; \\&quot;, \\&quot;\\&quot;) &amp; \\&quot;FAIL:WordCount=\\&quot; &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationNotes &amp; If(validationNotes.Length &gt; 0, \\&quot;; \\&quot;, \\&quot;\\&quot;) &amp; \\&quot;FAIL:WordCount=\\&quot; &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;System.Text.RegularExpressions.Regex.IsMatch(parsedSubject &amp; \\&quot; \\&quot; &amp; parsedBody, emojiRegexPattern)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationNotes &amp; If(validationNotes.Length &gt; 0, \\&quot;; \\&quot;, \\&quot;\\&quot;) &amp; \\&quot;FAIL:ContainsEmoji\\&quot;&qu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isContentReview&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskCreationFailed&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskWaitFailed&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewerComments&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedSubjectLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedBodyLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedEmailLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_ShouldSkip&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_ReviewDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_ApprovedSubject&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_ApprovedBody&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_ResolvedRecipientEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_ShouldSkip&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;Out_ReviewDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;draftUpdateFailed&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;In_TaskType&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;ContentReview\\&quot;&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskFormData.ContainsKey(\\&quot;ApprovalDecision\\&quot;) AndAlso taskFormData(\\&quot;ApprovalDecision\\&quot;) IsNot Nothing, tas",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskFormData.ContainsKey(\\&quot;ReviewerComments\\&quot;) AndAlso taskFormData(\\&quot;ReviewerComments\\&quot;) IsNot Nothing, tas",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskFormData.ContainsKey(\\&quot;ProposedSubject\\&quot;) AndAlso taskFormData(\\&quot;ProposedSubject\\&quot;) IsNot Nothing, taskF",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskFormData.ContainsKey(\\&quot;ProposedBody\\&quot;) AndAlso taskFormData(\\&quot;ProposedBody\\&quot;) IsNot Nothing, taskFormDat",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskFormData.ContainsKey(\\&quot;SelectedRecipientEmail\\&quot;) AndAlso taskFormData(\\&quot;SelectedRecipientEmail\\&quot;) IsNot ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewDecision&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedSubjectLocal&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedBodyLocal&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedEmailLocal&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewDecision&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;endTimeUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;summarySubject&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;summaryBody&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dataServiceUpdateSucceeded&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dataServiceException&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;summaryEmailSucceeded&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;emailException&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Format(\\&quot;[BGV26] Birthday Run Summary – {0} | Status: {1} | Sent: {2}\\&quot;, DateTime.Now.ToString(\\&quot;yyyy-MM-dd\\&",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Format(\\&quot;Birthday Greetings V26 – Daily Run Summary{0}RunId: {1}{0}Status: {2}{0}End Time (UTC): {3}{0}{0}Birthdays Fou",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Data Service update failed for RunId=\\&quot; &amp; In_RunId&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Summary email send failed for RunId=\\&quot; &amp; In_RunId &amp; \\&quot; to \\&quot; &amp; operatorEmail&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    }
  ],
  "requiredPropertyBindings": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initializing BirthdayGreetingsV26 ===&quot;]",
      "resolvedValue": "[&quot;=== Initializing BirthdayGreetingsV26 ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initializing BirthdayGreetingsV26 ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Init.xaml",
      "resolvedValue": "Init.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Init.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_SystemReady]",
      "resolvedValue": "[bool_SystemReady]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_SystemReady",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization complete&quot;]",
      "resolvedValue": "[&quot;Initialization complete&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization complete&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetTransactionData.xaml",
      "resolvedValue": "GetTransactionData.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetTransactionData.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Process.xaml",
      "resolvedValue": "Process.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Process.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryNumber]",
      "resolvedValue": "[int_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryNumber",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "0",
      "resolvedValue": "0",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "0",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetBirthdays.xaml",
      "resolvedValue": "GetBirthdays.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetBirthdays.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ProcessBirthday.xaml",
      "resolvedValue": "ProcessBirthday.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ProcessBirthday.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ResolveContact.xaml",
      "resolvedValue": "ResolveContact.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ResolveContact.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GenerateAndValidateDraft.xaml",
      "resolvedValue": "GenerateAndValidateDraft.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GenerateAndValidateDraft.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "HandleHumanReview.xaml",
      "resolvedValue": "HandleHumanReview.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "HandleHumanReview.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Finalize.xaml",
      "resolvedValue": "Finalize.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Finalize.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "resolvedValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; Da",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "resolvedValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== BirthdayGreetingsV26 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "resolvedValue": "[&quot;=== BirthdayGreetingsV26 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== BirthdayGreetingsV26 Complete. Transactions processed: &quot; &amp; i",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: GetBirthdays ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: GetBirthdays ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: GetBirthdays ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Compute todayLocal from configured time zone failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Compute todayLocal from configured time zone failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Compute todayLocal from configured time zone failed (&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] RetryScope: Google Calendar API call with up to 3 attempts failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] RetryScope: Google Calendar API call with up to 3 attempts failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] RetryScope: Google Calendar API call with up to 3 attempts failed",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for GoogleCalendarGetEvents: Read today&apos;s events from Birthdays feed, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for GoogleCalendarGetEvents: Read today&apos;s events from Birthdays feed, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for GoogleCalendarGetEvents: Read today&apos;s events fro",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] GoogleCalendarGetEvents: Read today&apos;s events from Birthdays feed failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] GoogleCalendarGetEvents: Read today&apos;s events from Birthdays feed failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] GoogleCalendarGetEvents: Read today&apos;s events from ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Delay",
      "propertyName": "Duration",
      "sourceBinding": "attribute-value",
      "originalValue": "TimeSpan.FromSeconds(backoffSeconds)",
      "resolvedValue": "TimeSpan.FromSeconds(backoffSeconds)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TimeSpan.FromSeconds(backoffSeconds)",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;rawCalendarEvents&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;rawCalendarEvents&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;rawCalendarEven",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if rawCalendarEvents is Nothing (null response guard)&quot;]",
      "resolvedValue": "[&quot;Then path: Check if rawCalendarEvents is Nothing (null response guard)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if rawCalendarEvents is Nothing (null response guard)&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if rawCalendarEvents is Nothing (null response guard)&quot;]",
      "resolvedValue": "[&quot;Else path: Check if rawCalendarEvents is Nothing (null response guard)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if rawCalendarEvents is Nothing (null response guard)&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawCalendarEvents&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawCalendarEvents&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawCalendarEvents",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing item in: ForEach event in rawCalendarEvents: normalise and add to work item table&quot;]",
      "resolvedValue": "[&quot;Processing item in: ForEach event in rawCalendarEvents: normalise and add to work item table&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing item in: ForEach event in rawCalendarEvents: normalise and add",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] ForEach event in rawCalendarEvents: normalise and add to work item table failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] ForEach event in rawCalendarEvents: normalise and add to work item table failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] ForEach event in rawCalendarEvents: normalise and add to work ite",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(rawEventTitle)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(rawEventTitle)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Skip event if raw title is empty or whitespace&quot;]",
      "resolvedValue": "[&quot;Then path: Skip event if raw title is empty or whitespace&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Skip event if raw title is empty or whitespace&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Skip event if raw title is empty or whitespace&quot;]",
      "resolvedValue": "[&quot;Else path: Skip event if raw title is empty or whitespace&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Skip event if raw title is empty or whitespace&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "AddDataRow",
      "propertyName": "DataTable",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayWorkItems&quot;}",
      "resolvedValue": "[birthdayWorkItems]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayWorkItems&",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetBirthdays ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetBirthdays ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetBirthdays ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: ResolveContact ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: ResolveContact ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: ResolveContact ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Try block: TryCatch: Guard entire GSuite lookup against auth/quota failures&quot;]",
      "resolvedValue": "[&quot;Try block: TryCatch: Guard entire GSuite lookup against auth/quota failures&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Try block: TryCatch: Guard entire GSuite lookup against auth/quota failur",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in TryCatch: Guard entire GSuite lookup against auth/quota failures: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in TryCatch: Guard entire GSuite lookup against auth/quota failures: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in TryCatch: Guard entire GSuite lookup against auth/quota failures",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] TryCatch: Guard entire GSuite lookup against auth/quota failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] TryCatch: Guard entire GSuite lookup against auth/quota failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] TryCatch: Guard entire GSuite lookup against auth/quota failures ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for RetryScope: Execute GSuite Contacts search with up to 3 attempts and backoff, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for RetryScope: Execute GSuite Contacts search with up to 3 attempts and backoff, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for RetryScope: Execute GSuite Contacts search with up to",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] RetryScope: Execute GSuite Contacts search with up to 3 attempts and backoff failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] RetryScope: Execute GSuite Contacts search with up to 3 attempts and backoff failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] RetryScope: Execute GSuite Contacts search with up to 3",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Search Google Contacts by exact full name, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Search Google Contacts by exact full name, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Search Google Contacts by exact full name, screenshot",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Search Google Contacts by exact full name failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Search Google Contacts by exact full name failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Search Google Contacts by exact full name failed after ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactsSearchResult&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactsSearchResult&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactsSearchR",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Evaluate match count from search result — handle null result defensively&quot;]",
      "resolvedValue": "[&quot;Then path: Evaluate match count from search result — handle null result defensively&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Evaluate match count from search result — handle null result d",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Evaluate match count from search result — handle null result defensively&quot;]",
      "resolvedValue": "[&quot;Else path: Evaluate match count from search result — handle null result defensively&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Evaluate match count from search result — handle null result d",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[0]",
      "resolvedValue": "[0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Default case: Branch on match count: zero, one, or many contacts found&quot;]",
      "resolvedValue": "[&quot;Default case: Branch on match count: zero, one, or many contacts found&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Default case: Branch on match count: zero, one, or many contacts found&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Switch default: Branch on match count: zero, one, or many contacts found&quot;]",
      "resolvedValue": "[&quot;Switch default: Branch on match count: zero, one, or many contacts found&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Switch default: Branch on match count: zero, one, or many contacts found&",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "GoogleContactsGetContact",
      "propertyName": "ResourceName",
      "sourceBinding": "attribute-value",
      "originalValue": "firstMatchedContact.ToString()",
      "resolvedValue": "firstMatchedContact.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "firstMatchedContact.ToString()",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for [Case: one] Retrieve contact detail by resource name to get email labels, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for [Case: one] Retrieve contact detail by resource name to get email labels, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for [Case: one] Retrieve contact detail by resource name ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] [Case: one] Retrieve contact detail by resource name to get email labels failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] [Case: one] Retrieve contact detail by resource name to get email labels failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] [Case: one] Retrieve contact detail by resource name to",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: [Case: one] If Personal email found, prefer it; else try Home; else skip&quot;]",
      "resolvedValue": "[&quot;Then path: [Case: one] If Personal email found, prefer it; else try Home; else skip&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: [Case: one] If Personal email found, prefer it; else try Home;",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: [Case: one] If Personal email found, prefer it; else try Home; else skip&quot;]",
      "resolvedValue": "[&quot;Else path: [Case: one] If Personal email found, prefer it; else try Home; else skip&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: [Case: one] If Personal email found, prefer it; else try Home;",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: [Case: one, No Personal] Check if Home email available&quot;]",
      "resolvedValue": "[&quot;Then path: [Case: one, No Personal] Check if Home email available&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: [Case: one, No Personal] Check if Home email available&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: [Case: one, No Personal] Check if Home email available&quot;]",
      "resolvedValue": "[&quot;Else path: [Case: one, No Personal] Check if Home email available&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: [Case: one, No Personal] Check if Home email available&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ResolveContact ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ResolveContact ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ResolveContact ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: GenerateAndValidateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: GenerateAndValidateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: GenerateAndValidateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=&quot; &amp; genAiPrompt.Length.ToString() &amp; &quot;). Invoking GenAI activity.&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=&quot; &amp; genAiPrompt.Length.ToString() &amp; &quot;). Invoking GenAI activity.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=&quot; &amp; ge",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[0]",
      "resolvedValue": "[0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Retry loop: invoke GenAI with up to 2 attempts on rate-limit or timeout failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Retry loop: invoke GenAI with up to 2 attempts on rate-limit or timeout failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Retry loop: invoke GenAI with up to 2 attempts on rate-limit or t",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "https://cloud.uipath.com/genai/v1/generateText",
      "resolvedValue": "https://cloud.uipath.com/genai/v1/generateText",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "https://cloud.uipath.com/genai/v1/generateText",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "POST",
      "resolvedValue": "POST",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "POST",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Invoke UiPath native GenAI to generate birthday email subject and body, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Invoke UiPath native GenAI to generate birthday email subject and body, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Invoke UiPath native GenAI to generate birthday email",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Invoke UiPath native GenAI to generate birthday email subject and body failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Invoke UiPath native GenAI to generate birthday email subject and body failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Invoke UiPath native GenAI to generate birthday email s",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(genAiRawResponse)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(genAiRawResponse)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Guard: if GenAI response is null or whitespace, throw parse-ready exception&quot;]",
      "resolvedValue": "[&quot;Then path: Guard: if GenAI response is null or whitespace, throw parse-ready exception&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Guard: if GenAI response is null or whitespace, throw parse-re",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Guard: if GenAI response is null or whitespace, throw parse-ready exception&quot;]",
      "resolvedValue": "[&quot;Else path: Guard: if GenAI response is null or whitespace, throw parse-ready exception&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Guard: if GenAI response is null or whitespace, throw parse-re",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiRawResponse&quot;}",
      "resolvedValue": "[genAiRawResponse]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiRawResponse&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Parse GenAI JSON response — extract subject and body fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Parse GenAI JSON response — extract subject and body fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Parse GenAI JSON response — extract subject and body fields faile",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract &apos;subject&apos; string from parsed JSON token failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract &apos;subject&apos; string from parsed JSON token failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract &apos;subject&apos; string from parsed JSON token failed ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract &apos;body&apos; string from parsed JSON token failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract &apos;body&apos; string from parsed JSON token failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract &apos;body&apos; string from parsed JSON token failed (&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[]",
      "resolvedValue": "[]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedSubject)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedSubject)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validation Check 1: Subject must be non-empty&quot;]",
      "resolvedValue": "[&quot;Then path: Validation Check 1: Subject must be non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validation Check 1: Subject must be non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validation Check 1: Subject must be non-empty&quot;]",
      "resolvedValue": "[&quot;Else path: Validation Check 1: Subject must be non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validation Check 1: Subject must be non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedBody)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedBody)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validation Check 2: Body must be non-empty&quot;]",
      "resolvedValue": "[&quot;Then path: Validation Check 2: Body must be non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validation Check 2: Body must be non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validation Check 2: Body must be non-empty&quot;]",
      "resolvedValue": "[&quot;Else path: Validation Check 2: Body must be non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validation Check 2: Body must be non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validation Check 3: Word count below minimum&quot;]",
      "resolvedValue": "[&quot;Then path: Validation Check 3: Word count below minimum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validation Check 3: Word count below minimum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validation Check 3: Word count below minimum&quot;]",
      "resolvedValue": "[&quot;Else path: Validation Check 3: Word count below minimum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validation Check 3: Word count below minimum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validation Check 4: Word count above maximum&quot;]",
      "resolvedValue": "[&quot;Then path: Validation Check 4: Word count above maximum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validation Check 4: Word count above maximum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validation Check 4: Word count above maximum&quot;]",
      "resolvedValue": "[&quot;Else path: Validation Check 4: Word count above maximum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validation Check 4: Word count above maximum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Append ContainsEmoji failure note if emoji detected&quot;]",
      "resolvedValue": "[&quot;Then path: Append ContainsEmoji failure note if emoji detected&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Append ContainsEmoji failure note if emoji detected&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Append ContainsEmoji failure note if emoji detected&quot;]",
      "resolvedValue": "[&quot;Else path: Append ContainsEmoji failure note if emoji detected&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Append ContainsEmoji failure note if emoji detected&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GenerateAndValidateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GenerateAndValidateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GenerateAndValidateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Build task title based on task type&quot;]",
      "resolvedValue": "[&quot;Then path: Build task title based on task type&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Build task title based on task type&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Build task title based on task type&quot;]",
      "resolvedValue": "[&quot;Else path: Build task title based on task type&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Build task title based on task type&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;formSchemaPath&quot;}",
      "resolvedValue": "[formSchemaPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;formSchemaPath&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create Action Center form task for human review failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create Action Center form task for human review failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create Action Center form task for human review failed (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskCreationFailed&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskCreationFailed&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskCreationFai",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Route based on task creation success or failure&quot;]",
      "resolvedValue": "[&quot;Then path: Route based on task creation success or failure&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Route based on task creation success or failure&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Route based on task creation success or failure&quot;]",
      "resolvedValue": "[&quot;Else path: Route based on task creation success or failure&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Route based on task creation success or failure&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Wait for reviewer to complete the Action Center form task failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Wait for reviewer to complete the Action Center form task failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Wait for reviewer to complete the Action Center form task failed ",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskWaitFailed&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskWaitFailed&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskWaitFailed&",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Route based on wait success or infrastructure failure&quot;]",
      "resolvedValue": "[&quot;Then path: Route based on wait success or infrastructure failure&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Route based on wait success or infrastructure failure&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Route based on wait success or infrastructure failure&quot;]",
      "resolvedValue": "[&quot;Else path: Route based on wait success or infrastructure failure&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Route based on wait success or infrastructure failure&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on task type to extract the correct form fields&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on task type to extract the correct form fields&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on task type to extract the correct form fields&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on task type to extract the correct form fields&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on task type to extract the correct form fields&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on task type to extract the correct form fields&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;reviewDecision = \\&quot;Approve\\&quot; OrElse reviewDecision = \\&quot;EditAndApprove\\&quot; OrElse reviewDecision = \\&quot;SelectEmailAndContinue\\&quot;&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;reviewDecision = \\&quot;Approve\\&quot; OrElse reviewDecision = \\&quot;EditAndApprove\\&quot; OrElse reviewDecision = \\&quot;SelectEmailAndContinue\\&quot;&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;reviewDecis",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on reviewer decision to set output arguments&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on reviewer decision to set output arguments&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on reviewer decision to set output arguments&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on reviewer decision to set output arguments&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on reviewer decision to set output arguments&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on reviewer decision to set output arguments&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "BGV26_Draft",
      "resolvedValue": "BGV26_Draft",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGV26_Draft",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;Id\\&quot;, In_DraftId}, {\\&quot;ValidationStatus\\&quot;, If(Out_ShouldSkip, \\&quot;Failed\\&quot;, \\&quot;Passed\\&quot;)}, {\\&quot;ApprovedSubject\\&quot;, Out_ApprovedSubject}, {\\&quot;ApprovedBody\\&quot;, Out_ApprovedBody}, {\\&quot;ReviewedBy\\&quot;, If(taskFormData.ContainsKey(\\&quot;ReviewerComments\\&quot;), \\&quot;ActionCenter\\&quot;, \\&quot;ActionCenter\\&quot;)}, {\\&quot;ReviewedAtUtc\\&quot;, DateTime.UtcNow.ToString(\\&quot;o\\&quot;)}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"Id\", In_DraftId}, {\"ValidationStatus\", If(Out_ShouldSkip, \"Failed\", \"Passed\")}, {\"ApprovedSubject\", Out_ApprovedSubject}, {\"ApprovedBody\", Out_ApprovedBody}, {\"ReviewedBy\", If(taskFormData.ContainsKey(\"ReviewerComments\"), \"ActionCenter\", \"ActionCenter\")}, {\"ReviewedAtUtc\", DateTime.UtcNow.ToString(\"o\")}}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictiona",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update BGV26_Draft record with reviewer outcome failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update BGV26_Draft record with reviewer outcome failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update BGV26_Draft record with reviewer outcome failed (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Finalize ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Finalize ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Finalize ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow]",
      "resolvedValue": "[DateTime.UtcNow]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "BGV26_Run",
      "resolvedValue": "BGV26_Run",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGV26_Run",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;RunId\\&quot;, In_RunId}, {\\&quot;EndTimeUtc\\&quot;, endTimeUtc}, {\\&quot;RunStatus\\&quot;, In_RunStatus}, {\\&quot;BirthdaysFound\\&quot;, In_BirthdaysFound}, {\\&quot;SentCount\\&quot;, In_SentCount}, {\\&quot;SkippedCount\\&quot;, In_SkippedCount}, {\\&quot;ErrorCount\\&quot;, In_ErrorCount}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"RunId\", In_RunId}, {\"EndTimeUtc\", endTimeUtc}, {\"RunStatus\", In_RunStatus}, {\"BirthdaysFound\", In_BirthdaysFound}, {\"SentCount\", In_SentCount}, {\"SkippedCount\", In_SkippedCount}, {\"ErrorCount\", In_ErrorCount}}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictiona",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update BGV26_Run record with EndTimeUtc, status, and counters failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update BGV26_Run record with EndTimeUtc, status, and counters failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update BGV26_Run record with EndTimeUtc, status, and counters fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "GmailSendMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "GmailSendMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;summarySubject&quot;}",
      "resolvedValue": "[summarySubject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;summarySubject&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Send daily summary email via Integration Service Gmail connector failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Send daily summary email via Integration Service Gmail connector failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Send daily summary email via Integration Service Gmail connector ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Finalize ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Finalize ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Finalize ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization: 8am Daily Birthday Run Trigger&quot;]",
      "resolvedValue": "[&quot;Initialization: 8am Daily Birthday Run Trigger&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization: 8am Daily Birthday Run Trigger&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Get Today’s Birthday Events (Built-in Birthdays Calendar)",
      "resolvedValue": "Executing: Get Today’s Birthday Events (Built-in Birthdays Calendar)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Get Today’s Birthday Events (Built-in Birthdays Calendar)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "resolvedValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: For Each Birthday Event: Normalize Full Name",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: No Birthdays Today End",
      "resolvedValue": "Executing: No Birthdays Today End",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: No Birthdays Today End",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "resolvedValue": "Executing: For Each Birthday Event: Normalize Full Name",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: For Each Birthday Event: Normalize Full Name",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Exact Match Contact by Full Name",
      "resolvedValue": "Executing: Exact Match Contact by Full Name",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Exact Match Contact by Full Name",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Skip Person (No Email), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Skip Person (No Email), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Skip Person (No Email), screenshot captured&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Skip Person (No Email) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Skip Person (No Email) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Skip Person (No Email) failed after retries — &quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Select Recipient Email (Prefer Personal), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Select Recipient Email (Prefer Personal), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Select Recipient Email (Prefer Personal), screenshot ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Select Recipient Email (Prefer Personal) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Select Recipient Email (Prefer Personal) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Select Recipient Email (Prefer Personal) failed after r",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Skip Duplicate Send",
      "resolvedValue": "Executing: Skip Duplicate Send",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Skip Duplicate Send",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Skip Duplicate Send",
      "resolvedValue": "Executing: Skip Duplicate Send",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Skip Duplicate Send",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Invoking agent for: Generate Birthday Email Draft (Your Voice)&quot;]",
      "resolvedValue": "[&quot;Invoking agent for: Generate Birthday Email Draft (Your Voice)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Invoking agent for: Generate Birthday Email Draft (Your Voice)&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "AgentInvocation_Stub.xaml",
      "resolvedValue": "AgentInvocation_Stub.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "AgentInvocation_Stub.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_AgentOutput]",
      "resolvedValue": "[str_AgentOutput]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AgentOutput",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AgentOutput]",
      "resolvedValue": "[str_AgentOutput]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AgentOutput",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Agent completed: Generate Birthday Email Draft (Your Voice)&quot;]",
      "resolvedValue": "[&quot;Agent completed: Generate Birthday Email Draft (Your Voice)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Agent completed: Generate Birthday Email Draft (Your Voice)&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Generate Birthday Email Draft (Your Voice) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Generate Birthday Email Draft (Your Voice) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Generate Birthday Email Draft (Your Voice) failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Invoking agent decision for: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "resolvedValue": "[&quot;Invoking agent decision for: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Invoking agent decision for: Draft Safe/Complete? (no sensitive content, ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "AgentInvocation_Stub.xaml",
      "resolvedValue": "AgentInvocation_Stub.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "AgentInvocation_Stub.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_AgentDecisionResult]",
      "resolvedValue": "[bool_AgentDecisionResult]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_AgentDecisionResult",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set email subject",
      "resolvedValue": "TODO: Set email subject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set email subject",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Body",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_EmailBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_EmailBody",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set SMTP server",
      "resolvedValue": "TODO: Set SMTP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set SMTP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Agent decision completed: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "resolvedValue": "[&quot;Agent decision completed: Draft Safe/Complete? (no sensitive content, has subject+body)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Agent decision completed: Draft Safe/Complete? (no sensitive content, has",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Draft Safe/Complete? (no sensitive content, has subject+body) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Draft Safe/Complete? (no sensitive content, has subject+body) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Draft Safe/Complete? (no sensitive content, has subject+body) fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create Human Review Task (Edge Case) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create Human Review Task (Edge Case) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create Human Review Task (Edge Case) failed (&quot; &amp; excepti",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Apply Approved/Edited Text from Action Center failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Apply Approved/Edited Text from Action Center failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Apply Approved/Edited Text from Action Center failed (&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set email subject",
      "resolvedValue": "TODO: Set email subject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set email subject",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Body",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_EmailBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_EmailBody",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set SMTP server",
      "resolvedValue": "TODO: Set SMTP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set SMTP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Send Birthday Email, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Send Birthday Email, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Send Birthday Email, screenshot captured&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Send Birthday Email failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Send Birthday Email failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Send Birthday Email failed after retries — &quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set email subject",
      "resolvedValue": "TODO: Set email subject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set email subject",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Body",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_EmailBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_EmailBody",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "SendSmtpMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set SMTP server",
      "resolvedValue": "TODO: Set SMTP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set SMTP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Send Birthday Email (Post-Review), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Send Birthday Email (Post-Review), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Send Birthday Email (Post-Review), screenshot capture",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Send Birthday Email (Post-Review) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Send Birthday Email (Post-Review) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Send Birthday Email (Post-Review) failed after retries ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Server",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP server",
      "resolvedValue": "TODO: Set IMAP server",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP server",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Email",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP email",
      "resolvedValue": "TODO: Set IMAP email",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP email",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "GetImapMailMessage",
      "propertyName": "Password",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set IMAP password",
      "resolvedValue": "TODO: Set IMAP password",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set IMAP password",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Record Sent Log (name, email, date, messageId), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Record Sent Log (name, email, date, messageId), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Record Sent Log (name, email, date, messageId), scree",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Record Sent Log (name, email, date, messageId) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Record Sent Log (name, email, date, messageId) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Record Sent Log (name, email, date, messageId) failed a",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Process Next Event",
      "resolvedValue": "Executing: Process Next Event",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Process Next Event",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Birthday Batch Completed End",
      "resolvedValue": "Executing: Birthday Batch Completed End",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Birthday Batch Completed End",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Process Next Event",
      "resolvedValue": "Executing: Process Next Event",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Process Next Event",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Loop Back to Next Contact Lookup",
      "resolvedValue": "Executing: Loop Back to Next Contact Lookup",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Loop Back to Next Contact Lookup",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Merge Skips Back to Loop",
      "resolvedValue": "Executing: Merge Skips Back to Loop",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 44,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Merge Skips Back to Loop",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Merge Duplicate Skips Back to Loop",
      "resolvedValue": "Executing: Merge Duplicate Skips Back to Loop",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 45,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Merge Duplicate Skips Back to Loop",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Continue Loop",
      "resolvedValue": "Executing: Continue Loop",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 46,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Continue Loop",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Return to “More events remaining?” decision",
      "resolvedValue": "Executing: Return to “More events remaining?” decision",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 47,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Return to “More events remaining?” decision",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Loop to Contact Lookup",
      "resolvedValue": "Executing: Loop to Contact Lookup",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 48,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Loop to Contact Lookup",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Loop Connection",
      "resolvedValue": "Executing: Loop Connection",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 49,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Loop Connection",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: No Birthdays Today End&quot;]",
      "resolvedValue": "[&quot;Completed: No Birthdays Today End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 50,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: No Birthdays Today End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Birthday Batch Completed End&quot;]",
      "resolvedValue": "[&quot;Completed: Birthday Batch Completed End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 51,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Birthday Batch Completed End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 52,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "WorkbookPath",
      "sourceBinding": "variable",
      "originalValue": "[str_ConfigPath]",
      "resolvedValue": "[str_ConfigPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ConfigPath",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Settings]",
      "resolvedValue": "[dt_Settings]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Settings",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Constants]",
      "resolvedValue": "[dt_Constants]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Constants",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
      "resolvedValue": "[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_GSuite_ServiceAccount_Credential&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_GSuite_ServiceAccount_Credential&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_GSuite_ServiceAccount_Credential&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_TempUser]",
      "resolvedValue": "[str_TempUser]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempUser",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_BirthdaysCalendarName&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_BirthdaysCalendarName&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_BirthdaysCalendarName&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_TimeZone&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_TimeZone&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_TimeZone&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_EmailStyleSpec&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_EmailStyleSpec&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_EmailStyleSpec&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_EmailWordCountMin&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_EmailWordCountMin&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_EmailWordCountMin&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_EmailWordCountMax&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_EmailWordCountMax&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_EmailWordCountMax&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_AllowActionCenterFallback&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_AllowActionCenterFallback&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_AllowActionCenterFallback&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_GmailFromConnectionName&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_GmailFromConnectionName&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_GmailFromConnectionName&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_DedupeScope&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_DedupeScope&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_DedupeScope&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[out_TransactionItem IsNot Nothing]",
      "resolvedValue": "[out_TransactionItem IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[out_TransactionItem IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_TransactionNumber",
        "sourceWorkflow": "GetTransactionData",
        "precedenceTier": 1
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber + 1]",
      "resolvedValue": "[io_TransactionNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "resolvedValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;No more transactions in queue&quot;]",
      "resolvedValue": "[&quot;No more transactions in queue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;No more transactions in queue&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetTransactionData ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_Status = &quot;Successful&quot;]",
      "resolvedValue": "[in_Status = &quot;Successful&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_Status = &quot;Successful&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "resolvedValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "resolvedValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Closing all applications...&quot;]",
      "resolvedValue": "[&quot;Closing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Closing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications closed&quot;]",
      "resolvedValue": "[&quot;All applications closed&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications closed&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "resolvedValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "KillAllProcesses.xaml",
      "resolvedValue": "KillAllProcesses.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "KillAllProcesses.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "resolvedValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Force killing all application processes...&quot;]",
      "resolvedValue": "[&quot;Force killing all application processes...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Force killing all application processes...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;chrome&quot;]",
      "resolvedValue": "[&quot;chrome&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;chrome&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;iexplore&quot;]",
      "resolvedValue": "[&quot;iexplore&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;iexplore&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;EXCEL&quot;]",
      "resolvedValue": "[&quot;EXCEL&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;EXCEL&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All processes terminated&quot;]",
      "resolvedValue": "[&quot;All processes terminated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All processes terminated&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Started ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Started ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Started ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_Config]",
      "resolvedValue": "[io_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 1
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Complete ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Complete ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Complete ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "AgentInvocation_Stub.xaml",
      "workflow": "AgentInvocation_Stub",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: AgentInvocation_Stub ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: AgentInvocation_Stub ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: AgentInvocation_Stub ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ResolveContact.xaml",
      "workflow": "ResolveContact",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "GmailSendMessage",
      "propertyName": "Body",
      "failureReason": "Required property \"Body\" on GmailSendMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "AddDataRow",
      "propertyName": "DataTable",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayWorkItems&quot;}",
      "resolvedValue": "[birthdayWorkItems]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiRawResponse&quot;}",
      "resolvedValue": "[genAiRawResponse]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;formSchemaPath&quot;}",
      "resolvedValue": "[formSchemaPath]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;Id\\&quot;, In_DraftId}, {\\&quot;ValidationStatus\\&quot;, If(Out_ShouldSkip, \\&quot;Failed\\&quot;, \\&quot;Passed\\&quot;)}, {\\&quot;ApprovedSubject\\&quot;, Out_ApprovedSubject}, {\\&quot;ApprovedBody\\&quot;, Out_ApprovedBody}, {\\&quot;ReviewedBy\\&quot;, If(taskFormData.ContainsKey(\\&quot;ReviewerComments\\&quot;), \\&quot;ActionCenter\\&quot;, \\&quot;ActionCenter\\&quot;)}, {\\&quot;ReviewedAtUtc\\&quot;, DateTime.UtcNow.ToString(\\&quot;o\\&quot;)}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"Id\", In_DraftId}, {\"ValidationStatus\", If(Out_ShouldSkip, \"Failed\", \"Passed\")}, {\"ApprovedSubject\", Out_ApprovedSubject}, {\"ApprovedBody\", Out_ApprovedBody}, {\"ReviewedBy\", If(taskFormData.ContainsKey(\"ReviewerComments\"), \"ActionCenter\", \"ActionCenter\")}, {\"ReviewedAtUtc\", DateTime.UtcNow.ToString(\"o\")}}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;RunId\\&quot;, In_RunId}, {\\&quot;EndTimeUtc\\&quot;, endTimeUtc}, {\\&quot;RunStatus\\&quot;, In_RunStatus}, {\\&quot;BirthdaysFound\\&quot;, In_BirthdaysFound}, {\\&quot;SentCount\\&quot;, In_SentCount}, {\\&quot;SkippedCount\\&quot;, In_SkippedCount}, {\\&quot;ErrorCount\\&quot;, In_ErrorCount}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"RunId\", In_RunId}, {\"EndTimeUtc\", endTimeUtc}, {\"RunStatus\", In_RunStatus}, {\"BirthdaysFound\", In_BirthdaysFound}, {\"SentCount\", In_SentCount}, {\"SkippedCount\", In_SkippedCount}, {\"ErrorCount\", In_ErrorCount}}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "GmailSendMessage",
      "propertyName": "Subject",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;summarySubject&quot;}",
      "resolvedValue": "[summarySubject]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    }
  ],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "378 required property binding(s) resolved; 108 unresolved required property defect(s); 7 structured expression(s) lowered; 107 invalid generic substitution(s) blocked",
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "397f28e8538feabfb99ddaa86b487fe7618821f0633f4ae7bd202c4a43628734",
      "canonicalizedHash": "e1acc2b2e5b16aa0b8c149f720d42e57219b609b0db3538262abb99a5a45072c",
      "archivedHash": "e1acc2b2e5b16aa0b8c149f720d42e57219b609b0db3538262abb99a5a45072c",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GetBirthdays.xaml",
      "preCanonicalizationHash": "228d11ddf86f9e49087b7bc27afee3482f3b1fa81946e39e825c7bb385235be8",
      "canonicalizedHash": "63a99c0c26ebe048a059395bb13ae5b84c17a6d0d8c7e0f804c48a7eaf216467",
      "archivedHash": "63a99c0c26ebe048a059395bb13ae5b84c17a6d0d8c7e0f804c48a7eaf216467",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ProcessBirthday.xaml",
      "preCanonicalizationHash": "8b31ecf5e55e17182735399e04e5f6e1ac831ef7c9b5df99944ad9f289bcf61b",
      "canonicalizedHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "archivedHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ResolveContact.xaml",
      "preCanonicalizationHash": "c1d5fc91d00a953d2686cd7423a3d416bb5de8f7ce65c225955dcfcd945ce915",
      "canonicalizedHash": "340733339069cc67f1cf7e73ec97fa72cd9c5cc98e98bbf3503040a93a53da7d",
      "archivedHash": "340733339069cc67f1cf7e73ec97fa72cd9c5cc98e98bbf3503040a93a53da7d",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "preCanonicalizationHash": "443439a291ec7afa4203526c9f7440cea8edb26ecd2d23e7a568b6761f6cb501",
      "canonicalizedHash": "2141e8a83066468eb48942a0cb63d9bbd05d7938541b29471d105a7bf2c1dad3",
      "archivedHash": "2141e8a83066468eb48942a0cb63d9bbd05d7938541b29471d105a7bf2c1dad3",
      "identical": true,
      "mutated": true
    },
    {
      "file": "HandleHumanReview.xaml",
      "preCanonicalizationHash": "be2e53d558f0c4c9c1e7e3c19fa9cc843ca7de7fa74de32bda34dcdd7af7b08c",
      "canonicalizedHash": "dd6896c2e5bd469e26e9650dc0aeab8b7f837d489fb1a0e934f8135598ec60ba",
      "archivedHash": "dd6896c2e5bd469e26e9650dc0aeab8b7f837d489fb1a0e934f8135598ec60ba",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Finalize.xaml",
      "preCanonicalizationHash": "d050f6dc10a986c3f9886a78ee4cd19dbb85b2e0f3a4be5f9d3bd28906d804d3",
      "canonicalizedHash": "8f78822cac6173bb4ffa7aacf0e89449562185f1a248025d94225339bae08f59",
      "archivedHash": "8f78822cac6173bb4ffa7aacf0e89449562185f1a248025d94225339bae08f59",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Process.xaml",
      "preCanonicalizationHash": "1fbde86835565552191331fae8355adcdc87be034d7623bca076f1951fcde6d1",
      "canonicalizedHash": "67f3ab1ae5a55feca6d9d3c0c760f08dd39d52bed8b9e3d9f634f92272f7f0e2",
      "archivedHash": "67f3ab1ae5a55feca6d9d3c0c760f08dd39d52bed8b9e3d9f634f92272f7f0e2",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
      "canonicalizedHash": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
      "archivedHash": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
      "identical": true,
      "mutated": false
    },
    {
      "file": "GetTransactionData.xaml",
      "preCanonicalizationHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
      "canonicalizedHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
      "archivedHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
      "identical": true,
      "mutated": false
    },
    {
      "file": "SetTransactionStatus.xaml",
      "preCanonicalizationHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "canonicalizedHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "archivedHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "identical": true,
      "mutated": false
    },
    {
      "file": "CloseAllApplications.xaml",
      "preCanonicalizationHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "canonicalizedHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "archivedHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "identical": true,
      "mutated": false
    },
    {
      "file": "KillAllProcesses.xaml",
      "preCanonicalizationHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
      "canonicalizedHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
      "archivedHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Init.xaml",
      "preCanonicalizationHash": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "canonicalizedHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "archivedHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "identical": true,
      "mutated": true
    },
    {
      "file": "AgentInvocation_Stub.xaml",
      "preCanonicalizationHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "canonicalizedHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "archivedHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
      "identical": true,
      "mutated": false
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "GetBirthdays.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "ResolveContact.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "pattern": "json_object_in_executable_attribute",
      "detail": "JSON-like object payload in executable attribute: Condition=\"{&quot;type&quot;:"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "HandleHumanReview.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "InitAllSettings.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: AssetName=\"[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "AgentInvocation_Stub.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
        "allowed": true,
        "reason": "Workflow \"AgentInvocation_Stub.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Finalize.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8f78822cac6173bb4ffa7aacf0e89449562185f1a248025d94225339bae08f59",
        "allowed": true,
        "reason": "Workflow \"Finalize.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GenerateAndValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "2141e8a83066468eb48942a0cb63d9bbd05d7938541b29471d105a7bf2c1dad3",
        "allowed": true,
        "reason": "Workflow \"GenerateAndValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "63a99c0c26ebe048a059395bb13ae5b84c17a6d0d8c7e0f804c48a7eaf216467",
        "allowed": true,
        "reason": "Workflow \"GetBirthdays.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "HandleHumanReview.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "dd6896c2e5bd469e26e9650dc0aeab8b7f837d489fb1a0e934f8135598ec60ba",
        "allowed": true,
        "reason": "Workflow \"HandleHumanReview.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e1acc2b2e5b16aa0b8c149f720d42e57219b609b0db3538262abb99a5a45072c",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "67f3ab1ae5a55feca6d9d3c0c760f08dd39d52bed8b9e3d9f634f92272f7f0e2",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessBirthday.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
        "allowed": true,
        "reason": "Workflow \"ProcessBirthday.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ResolveContact.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "340733339069cc67f1cf7e73ec97fa72cd9c5cc98e98bbf3503040a93a53da7d",
        "allowed": true,
        "reason": "Workflow \"ResolveContact.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "AgentInvocation_Stub.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "Finalize.xaml": 1,
      "GenerateAndValidateDraft.xaml": 1,
      "GetBirthdays.xaml": 1,
      "GetTransactionData.xaml": 1,
      "HandleHumanReview.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "ProcessBirthday.xaml": 1,
      "ResolveContact.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 15,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 15,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "AgentInvocation_Stub.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fdc87ad04df95db8fc3080bd2ab91536acc02ebe73db70d298e975336e3d9c39",
        "allowed": true,
        "reason": "Workflow \"AgentInvocation_Stub.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Finalize.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8f78822cac6173bb4ffa7aacf0e89449562185f1a248025d94225339bae08f59",
        "allowed": true,
        "reason": "Workflow \"Finalize.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GenerateAndValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "2141e8a83066468eb48942a0cb63d9bbd05d7938541b29471d105a7bf2c1dad3",
        "allowed": true,
        "reason": "Workflow \"GenerateAndValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "63a99c0c26ebe048a059395bb13ae5b84c17a6d0d8c7e0f804c48a7eaf216467",
        "allowed": true,
        "reason": "Workflow \"GetBirthdays.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "26b0d2b246b0c371b47ba7ac61c0d1fa6d46cea925e198aec98b3d77a622fd2c",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "HandleHumanReview.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "dd6896c2e5bd469e26e9650dc0aeab8b7f837d489fb1a0e934f8135598ec60ba",
        "allowed": true,
        "reason": "Workflow \"HandleHumanReview.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8709fbb611059dd6068853fdda2fc4ef2e0785b7dc0dc7dc79e8e69ad2d22caa",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e1acc2b2e5b16aa0b8c149f720d42e57219b609b0db3538262abb99a5a45072c",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "67f3ab1ae5a55feca6d9d3c0c760f08dd39d52bed8b9e3d9f634f92272f7f0e2",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessBirthday.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "965737a6e652078c619883190c324b0832bbe453384fcd4ce418808fc3eed6a0",
        "allowed": true,
        "reason": "Workflow \"ProcessBirthday.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ResolveContact.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "340733339069cc67f1cf7e73ec97fa72cd9c5cc98e98bbf3503040a93a53da7d",
        "allowed": true,
        "reason": "Workflow \"ResolveContact.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "AgentInvocation_Stub.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "Finalize.xaml": 1,
      "GenerateAndValidateDraft.xaml": 1,
      "GetBirthdays.xaml": 1,
      "GetTransactionData.xaml": 1,
      "HandleHumanReview.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "ProcessBirthday.xaml": 1,
      "ResolveContact.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 15,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 15,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 848,
        "approved": 848,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 10536,
        "approved": 5344,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 5192
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 12316,
        "approved": 9116,
        "deprecated": 0,
        "nonEmissionApproved": 2860,
        "targetIncompatible": 0,
        "unknown": 340
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 673,
        "approved": 603,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 70
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 13,
        "approved": 13,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
