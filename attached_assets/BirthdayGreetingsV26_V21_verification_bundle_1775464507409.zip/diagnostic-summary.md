# Diagnostic Summary

## Run Metadata
- **Run ID:** 3e85dea5-f5c1-4c3d-8e2c-04a5b84cfc6e
- **Idea ID:** fcbe5f6d-60a1-45f7-8c96-5df24f1173b0
- **Status:** completed_with_warnings
- **Generation Mode:** baseline_openable
- **Triggered By:** chat
- **Created At:** Mon Apr 06 2026 08:25:08 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Mon Apr 06 2026 08:30:23 GMT+0000 (Coordinated Universal Time)
- **Duration:** 314.5s

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 18 |
| pipeline_sdd_validation | succeeded | 19 |
| spec_generation | succeeded | 304488 |
| spec_context_loading | succeeded | 4 |
| spec_prompt_assembly | succeeded | 2 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 46940 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 1 |
| spec_handoff | succeeded | 1 |
| build_pipeline | succeeded | 9793 |
| pipeline_build_pipeline | succeeded | 9792 |
| pipeline_decomposition | succeeded | 3 |
| pipeline_pre_complexity_estimation | succeeded | 1 |
| pipeline_workflow_budget_check | succeeded | 0 |
| pipeline_complexity_classification | succeeded | 1 |
| pipeline_xaml_emission | succeeded | 2516 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 24 |
| pipeline_validation | succeeded | 266 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 420 |
| pipeline_packaging_dhg_guide | succeeded | 61 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_complete | succeeded | 0 |

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 17 |
| workflow_analyzer_autofix | 9 |
| activity_policy_filter | 7 |
| expression_lint | 3 |
| required_property_enforcement | 8 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 12
- **Total Warnings:** 36
- **Completeness:** structural

## Meta-Validation Summary

- **Engaged:** true
- **Mode:** Always
- **Corrections Applied:** 0
- **Corrections Skipped:** 4
- **Corrections Failed:** 1
- **Confidence Score:** 0.4411764705882353
- **Duration:** 74ms

## Remediations

- {"level":"workflow","file":"Main.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 531, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 527, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement Main — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"ProcessBirthday.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 75, col 15: Expected closing tag 'InvokeWorkflowFile.Arguments' (opened in line 73, col 15) instead of closing tag 'ui:InvokeWorkflowFile.Arguments'. (code: InvalidTag)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement ProcessBirthday — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ResolveContact.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 347: Unbalanced brackets: 1 open vs 0 close (diff: +1) | first imbalance near position 266, fragment: \"&amp; c.ToString()))&quot;}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in ResolveContact.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ResolveContact.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 347: String.Join() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in ResolveContact.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ResolveContact.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 347: .Select() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in ResolveContact.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"HandleHumanReview.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 322: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in HandleHumanReview.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Finalize.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 134: ugs:GmailSendMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Finalize.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 315: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 451: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 497: umail:SendSmtpMailMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"activity","file":"HandleHumanReview.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"value\" in HandleHumanReview.xaml with the appropriate type. Expression context: value","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"umail:SendSmtpMailMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"workflow","file":"GetBirthdays.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in GetBirthdays.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"ResolveContact.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in ResolveContact.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"GenerateAndValidateDraft.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: json_object_in_executable_attribute — JSON-like object payload in executable attribute: Condition=\"{&quot;type&quot;:","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve json_object_in_executable_attribute in GenerateAndValidateDraft.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"GenerateAndValidateDraft.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in GenerateAndValidateDraft.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"HandleHumanReview.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve malformed_attribute_quoting in InitAllSettings.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"ResolveContact.xaml","description":"Stripped 1 placeholder token(s) from ResolveContact.xaml","developerAction":"Review ResolveContact.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"Process.xaml","description":"Stripped 32 placeholder token(s) from Process.xaml","developerAction":"Review Process.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"AgentInvocation_Stub.xaml","description":"Stripped 1 placeholder token(s) from AgentInvocation_Stub.xaml","developerAction":"Review AgentInvocation_Stub.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (DOM): move-to-child-element ucs:BuildDataTable.DataTable in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (DOM): move-to-child-element ucs:BuildDataTable.Columns in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (DOM): move-to-child-element ugs:GoogleCalendarGetEvents.Events in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (DOM): move-to-child-element ForEach.Values in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (DOM): move-to-child-element ucs:AddDataRow.DataTable in GetBirthdays.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetBirthdays.xaml","description":"Catalog (DOM): move-to-child-element ucs:AddDataRow.ArrayRow in GetBirthdays.xaml"}
