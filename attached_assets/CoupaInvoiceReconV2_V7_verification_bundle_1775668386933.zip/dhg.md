# Developer Handoff Guide

**Project:** CoupaInvoiceReconV2
**Generated:** 2026-04-08
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Mostly Ready (70%)

**13 workflows: 5 fully generated, 2 with handoff blocks, 6 workflow-level stubs**
**Total Estimated Effort: ~1875 minutes (31.3 hours)**
**Remediations:** 186 total (0 property, 90 activity, 0 sequence, 0 structural-leaf, 6 workflow)
**Auto-Repairs:** 8
**Quality Warnings:** 48

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `Main.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 2 | `Dispatcher.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 3 | `Performer.xaml` | Stub | 2 | 0 | 11 | 2 | 0 |
| 4 | `InvoiceProcessor.xaml` | Stub | 2 | 0 | 13 | 2 | 0 |
| 5 | `CoupaInteractionHelper.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 6 | `ActionCenterCallbackHandler.xaml` | Handoff | 2 | 0 | 13 | 13 | 0 |
| 7 | `Process.xaml` | Handoff | 2 | 0 | 3 | 3 | 0 |
| 8 | `InitAllSettings.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 9 | `GetTransactionData.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 10 | `SetTransactionStatus.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 11 | `CloseAllApplications.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 12 | `KillAllProcesses.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 13 | `Init.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 5 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `GetTransactionData.xaml` | Generated with Remediations | Studio-openable |
| 2 | `SetTransactionStatus.xaml` | Fully Generated | Studio-openable |
| 3 | `CloseAllApplications.xaml` | Fully Generated | Studio-openable |
| 4 | `KillAllProcesses.xaml` | Fully Generated | Studio-openable |
| 5 | `Init.xaml` | Generated with Remediations | Studio-openable |

### AI-Resolved with Smart Defaults (8)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_PLACEHOLDER_CLEANUP` | `Process.xaml` | Stripped 4 placeholder token(s) from Process.xaml | 5 |
| 2 | `REPAIR_GENERIC` | `ActionCenterCallbackHandler.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in ActionCenterCallbackHandler.xaml | undefined |
| 3 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 4 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ui:GetCredential.Username in InitAllSettings.xaml | undefined |
| 5 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ui:GetCredential.Password in InitAllSettings.xaml | undefined |
| 6 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 7 | `REPAIR_GENERIC` | `GetTransactionData.xaml` | Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml | undefined |
| 8 | `REPAIR_GENERIC` | `unknown` | Proactively added Newtonsoft.Json@13.0.4 — required by UiPath.WebAPI.Activities | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `Main.xaml` | Studio-openable | — | — |
| 2 | `Dispatcher.xaml` | Studio-openable | — | — |
| 3 | `Performer.xaml` | Studio-openable | — | — |
| 4 | `InvoiceProcessor.xaml` | Studio-openable | — | — |
| 5 | `CoupaInteractionHelper.xaml` | Studio-openable | — | — |
| 6 | `ActionCenterCallbackHandler.xaml` | Openable with warnings | Unclassified | — |
| 7 | `Process.xaml` | Openable with warnings | Unclassified | — |
| 8 | `InitAllSettings.xaml` | Studio-openable | — | — |
| 9 | `GetTransactionData.xaml` | Studio-openable | — | — |
| 10 | `SetTransactionStatus.xaml` | Studio-openable | — | — |
| 11 | `CloseAllApplications.xaml` | Studio-openable | — | — |
| 12 | `KillAllProcesses.xaml` | Studio-openable | — | — |
| 13 | `Init.xaml` | Studio-openable | — | — |

**Summary:** 11 Studio-loadable, 2 with warnings, 0 not Studio-loadable

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**90 handoff block(s) requiring manual implementation**

#### 1. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "maxConsecutiveFailures" in Performer.xaml with the appropriate type. Expression context: maxConsecutiveFailures
- **Estimated Effort:** 5 minutes

#### 2. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "maxTransactionSeconds" in Performer.xaml with the appropriate type. Expression context: maxTransactionSeconds
- **Estimated Effort:** 5 minutes

#### 3. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "enableEvidenceSnapshots" in Performer.xaml with the appropriate type. Expression context: enableEvidenceSnapshots
- **Estimated Effort:** 5 minutes

#### 4. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 5. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "transactionItem" in Performer.xaml with the appropriate type. Expression context: transactionItem
- **Estimated Effort:** 5 minutes

#### 6. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 7. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...
- **Estimated Effort:** 5 minutes

#### 8. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 9. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 10. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 11. `Performer.xaml` — — (activity)

- **Workflow File:** `Performer.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 12. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 13. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 14. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "InvoiceId" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{"CoupaInvoiceId", I...
- **Estimated Effort:** 5 minutes

#### 15. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "SupplierName" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{"CoupaInvoiceId", I...
- **Estimated Effort:** 5 minutes

#### 16. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "PONumber" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{"CoupaInvoiceId", I...
- **Estimated Effort:** 5 minutes

#### 17. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "InvoiceAmount" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{"CoupaInvoiceId", I...
- **Estimated Effort:** 5 minutes

#### 18. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "CorrelationId" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{"CoupaInvoiceId", I...
- **Estimated Effort:** 5 minutes

#### 19. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...
- **Estimated Effort:** 5 minutes

#### 20. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "GetInvoiceDetails" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...
- **Estimated Effort:** 5 minutes

#### 21. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...
- **Estimated Effort:** 5 minutes

#### 22. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 23. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 24. `InvoiceProcessor.xaml` — — (activity)

- **Workflow File:** `InvoiceProcessor.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 25. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "tolerancePct" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: tolerancePct
- **Estimated Effort:** 5 minutes

#### 26. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "rejectCommentInsufficientData" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: rejectCommentInsufficientData
- **Estimated Effort:** 5 minutes

#### 27. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "rejectCommentPOMismatch" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: rejectCommentPOMismatch
- **Estimated Effort:** 5 minutes

#### 28. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "rejectCommentOutOfTolerance" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: rejectCommentOutOfTolerance
- **Estimated Effort:** 5 minutes

#### 29. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "coupaBaseUrl" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: coupaBaseUrl
- **Estimated Effort:** 5 minutes

#### 30. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "enableEvidenceSnapshots" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: enableEvidenceSnapshots
- **Estimated Effort:** 5 minutes

#### 31. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__[pendingCases]
- **Estimated Effort:** 5 minutes

#### 32. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "pendingCases" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__[pendingCases]
- **Estimated Effort:** 5 minutes

#### 33. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "invoiceCaseId" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: invoiceCaseId
- **Estimated Effort:** 5 minutes

#### 34. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 35. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "ProcessingStatus" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 36. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "__STRUCTURED_OBJECT__" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...
- **Estimated Effort:** 5 minutes

#### 37. `ActionCenterCallbackHandler.xaml` — — (activity)

- **Workflow File:** `ActionCenterCallbackHandler.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "value" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: value
- **Estimated Effort:** 5 minutes

#### 38. `Process.xaml` — — (activity)

- **Workflow File:** `Process.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "Provide" in Process.xaml with the appropriate type. Expression context: Provide Data
- **Estimated Effort:** 5 minutes

#### 39. `Process.xaml` — — (activity)

- **Workflow File:** `Process.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "Data" in Process.xaml with the appropriate type. Expression context: Provide Data
- **Estimated Effort:** 5 minutes

#### 40. `Process.xaml` — — (activity)

- **Workflow File:** `Process.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "Approved" in Process.xaml with the appropriate type. Expression context: Approved
- **Estimated Effort:** 5 minutes

#### 41. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 42. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** While.Condition has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 43. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 44. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 45. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 46. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 47. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 48. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 49. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 50. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 51. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 52. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 53. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:CreateEntityRecord.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 54. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 55. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 56. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 57. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 58. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 59. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 60. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 61. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 62. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 63. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:GetEntityById.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 64. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 65. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 66. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 67. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** While.Condition has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 68. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 69. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 70. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 71. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 72. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 73. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 74. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 75. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 76. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 77. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 78. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:CreateEntityRecord.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 79. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 80. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 81. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 82. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 83. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 84. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 85. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 86. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 87. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 88. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:GetEntityById.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 89. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 90. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**234 items remaining — ~2355 minutes (39.3 hours) total estimated effort**

### CoupaInteractionHelper.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `CoupaInteractionHelper.xaml` replaced with Studio-openable stub | TODO: Implement CoupaInteractionHelper — review SDD for workflow requirements | 15 |
| 2 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### Dispatcher.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 3 | High | Workflow Stub | Entire workflow `Dispatcher.xaml` replaced with Studio-openable stub | TODO: Implement Dispatcher — review SDD for workflow requirements | 15 |
| 4 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### InitAllSettings.xaml (23 items, ~240 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 5 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in InitAllSettings.xaml | 10 |
| 6 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 7 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 8 | Low | Quality Warning | hardcoded-asset-name: Line 266: asset name "Coupa_IRV2_Credentials" is hardco... | Review and address | 10 |
| 9 | Low | Quality Warning | hardcoded-asset-name: Line 292: asset name "Coupa_IRV2_BaseUrl" is hardcoded ... | Review and address | 10 |
| 10 | Low | Quality Warning | hardcoded-asset-name: Line 323: asset name "Coupa_IRV2_TolerancePercent" is h... | Review and address | 10 |
| 11 | Low | Quality Warning | hardcoded-asset-name: Line 354: asset name "Coupa_IRV2_RejectComment_POMismat... | Review and address | 10 |
| 12 | Low | Quality Warning | hardcoded-asset-name: Line 385: asset name "Coupa_IRV2_RejectComment_OutOfTol... | Review and address | 10 |
| 13 | Low | Quality Warning | hardcoded-asset-name: Line 416: asset name "Coupa_IRV2_RejectComment_Insuffic... | Review and address | 10 |
| 14 | Low | Quality Warning | hardcoded-asset-name: Line 447: asset name "Coupa_IRV2_MaxTransactionSeconds"... | Review and address | 10 |
| 15 | Low | Quality Warning | hardcoded-asset-name: Line 478: asset name "Coupa_IRV2_MaxConsecutiveSystemFa... | Review and address | 10 |
| 16 | Low | Quality Warning | hardcoded-asset-name: Line 509: asset name "Coupa_IRV2_EnableEvidenceSnapshot... | Review and address | 10 |
| 17 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 18 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 19 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_Credentials" for ui:Get... | Review and address | 10 |
| 20 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_BaseUrl" for ui:GetAsse... | Review and address | 10 |
| 21 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_TolerancePercent" for u... | Review and address | 10 |
| 22 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_RejectComment_POMismatc... | Review and address | 10 |
| 23 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_RejectComment_OutOfTole... | Review and address | 10 |
| 24 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_RejectComment_Insuffici... | Review and address | 10 |
| 25 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_MaxTransactionSeconds" ... | Review and address | 10 |
| 26 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_MaxConsecutiveSystemFai... | Review and address | 10 |
| 27 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_EnableEvidenceSnapshots... | Review and address | 10 |

### InvoiceProcessor.xaml (47 items, ~540 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 28 | High | Workflow Stub | Entire workflow `InvoiceProcessor.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in InvoiceProcessor.xaml | 10 |
| 29 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the ap... | 5 |
| 30 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the ap... | 5 |
| 31 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "InvoiceId" in InvoiceProcessor.xaml with the appropriate ty... | 5 |
| 32 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "SupplierName" in InvoiceProcessor.xaml with the appropriate... | 5 |
| 33 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "PONumber" in InvoiceProcessor.xaml with the appropriate typ... | 5 |
| 34 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "InvoiceAmount" in InvoiceProcessor.xaml with the appropriat... | 5 |
| 35 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "CorrelationId" in InvoiceProcessor.xaml with the appropriat... | 5 |
| 36 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the ap... | 5 |
| 37 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "GetInvoiceDetails" in InvoiceProcessor.xaml with the approp... | 5 |
| 38 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the ap... | 5 |
| 39 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the ap... | 5 |
| 40 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the ap... | 5 |
| 41 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in InvoiceProcessor.xaml with the ap... | 5 |
| 42 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 43 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 44 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 45 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 46 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 47 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 48 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 49 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 50 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 51 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 52 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 53 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 54 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 55 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_NAMESPACES` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 56 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_REFERENCES` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 57 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 58 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 59 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 60 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 61 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 62 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 63 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 64 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 65 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InvoiceProcessor.xaml — estimated 15 min | 15 |
| 66 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InvoiceProcessor.xaml — move attribute to... | 15 |
| 67 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InvoiceProcessor.xaml — move attribute to... | 15 |
| 68 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InvoiceProcessor.xaml — move attribute to... | 15 |
| 69 | Low | Quality Warning | hardcoded-retry-count: Line 52: retry count hardcoded as 3 — consider externa... | Review and address | 10 |
| 70 | Low | Quality Warning | hardcoded-retry-count: Line 127: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 71 | Low | Quality Warning | hardcoded-retry-interval: Line 52: retry interval hardcoded as "00:00:05" — c... | Review and address | 10 |
| 72 | Low | Quality Warning | hardcoded-retry-interval: Line 127: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 73 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 74 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### Main.xaml (3 items, ~45 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 75 | High | Workflow Stub | Entire workflow `Main.xaml` replaced with Studio-openable stub | TODO: Implement Main — review SDD for workflow requirements | 15 |
| 76 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 77 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |

### Performer.xaml (37 items, ~425 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 78 | High | Workflow Stub | Entire workflow `Performer.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in Performer.xaml | 10 |
| 79 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "maxConsecutiveFailures" in Performer.xaml with the appropri... | 5 |
| 80 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "maxTransactionSeconds" in Performer.xaml with the appropria... | 5 |
| 81 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "enableEvidenceSnapshots" in Performer.xaml with the appropr... | 5 |
| 82 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropria... | 5 |
| 83 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "transactionItem" in Performer.xaml with the appropriate typ... | 5 |
| 84 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropria... | 5 |
| 85 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropria... | 5 |
| 86 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropria... | 5 |
| 87 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropria... | 5 |
| 88 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropria... | 5 |
| 89 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in Performer.xaml with the appropria... | 5 |
| 90 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 91 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 92 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 93 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 94 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 95 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 96 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 97 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 98 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 99 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 100 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 101 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_NAMESPACES` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 102 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_REFERENCES` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 103 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 104 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 105 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 106 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 107 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 108 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 109 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Performer.xaml — estimated 15 min | 15 |
| 110 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Performer.xaml — move attribute to child-... | 15 |
| 111 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Performer.xaml — move attribute to child-... | 15 |
| 112 | Low | Quality Warning | hardcoded-retry-count: Line 175: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 113 | Low | Quality Warning | hardcoded-retry-interval: Line 175: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 114 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### ActionCenterCallbackHandler.xaml (48 items, ~545 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 115 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "tolerancePct" in ActionCenterCallbackHandler.xaml with the ... | 5 |
| 116 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "rejectCommentInsufficientData" in ActionCenterCallbackHandl... | 5 |
| 117 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "rejectCommentPOMismatch" in ActionCenterCallbackHandler.xam... | 5 |
| 118 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "rejectCommentOutOfTolerance" in ActionCenterCallbackHandler... | 5 |
| 119 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "coupaBaseUrl" in ActionCenterCallbackHandler.xaml with the ... | 5 |
| 120 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "enableEvidenceSnapshots" in ActionCenterCallbackHandler.xam... | 5 |
| 121 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in ActionCenterCallbackHandler.xaml ... | 5 |
| 122 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "pendingCases" in ActionCenterCallbackHandler.xaml with the ... | 5 |
| 123 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "invoiceCaseId" in ActionCenterCallbackHandler.xaml with the... | 5 |
| 124 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in ActionCenterCallbackHandler.xaml ... | 5 |
| 125 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "ProcessingStatus" in ActionCenterCallbackHandler.xaml with ... | 5 |
| 126 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "__STRUCTURED_OBJECT__" in ActionCenterCallbackHandler.xaml ... | 5 |
| 127 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "value" in ActionCenterCallbackHandler.xaml with the appropr... | 5 |
| 128 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 129 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 130 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 131 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 132 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 133 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 134 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 135 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 136 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 137 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 138 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 139 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 140 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 141 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_NAMESPACES` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 142 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_REFERENCES` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 143 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 144 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 145 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 146 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 147 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 148 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 149 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 150 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 1... | 15 |
| 151 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in ActionCenterCallbackHandler.xaml — move a... | 15 |
| 152 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in ActionCenterCallbackHandler.xaml — move a... | 15 |
| 153 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in ActionCenterCallbackHandler.xaml — move a... | 15 |
| 154 | Low | Quality Warning | invalid-type-argument: Line 986: x:TypeArguments="__STRUCTURED_OBJECT__UiPath... | Review and address | 10 |
| 155 | Low | Quality Warning | invalid-type-argument: Line 991: x:TypeArguments="__STRUCTURED_OBJECT__UiPath... | Review and address | 10 |
| 156 | Low | Quality Warning | invalid-type-argument: Line 997: x:TypeArguments="__STRUCTURED_OBJECT__UiPath... | Review and address | 10 |
| 157 | Low | Quality Warning | hardcoded-retry-count: Line 843: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 158 | Low | Quality Warning | hardcoded-retry-count: Line 1344: retry count hardcoded as 3 — consider exter... | Review and address | 10 |
| 159 | Low | Quality Warning | hardcoded-retry-interval: Line 843: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 160 | Low | Quality Warning | hardcoded-retry-interval: Line 1344: retry interval hardcoded as "00:00:05" —... | Review and address | 10 |
| 161 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 162 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### Process.xaml (14 items, ~155 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 163 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "Provide" in Process.xaml with the appropriate type. Express... | 5 |
| 164 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "Data" in Process.xaml with the appropriate type. Expression... | 5 |
| 165 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "Approved" in Process.xaml with the appropriate type. Expres... | 5 |
| 166 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 167 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 168 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 169 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 170 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_NAMESPACES` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 171 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_REFERENCES` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 172 | Low | Implementation Required | Contains 2 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 173 | Low | Quality Warning | invalid-type-argument: Line 22: x:TypeArguments="UiPath.Persistence.Activitie... | Review and address | 10 |
| 174 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 42: Standalone "Yes" corrected to "True" in expressio... | Review and address | 10 |
| 175 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 119: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |
| 176 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 138: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |

### Unknown.xaml (50 items, ~250 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 177 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 178 | Medium | Activity Stub | Activity "unknown" stubbed | While.Condition has no valid source binding and no contract-valid fallback — ... | 5 |
| 179 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 180 | Medium | Activity Stub | Activity "unknown" stubbed | ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no con... | 5 |
| 181 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 182 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 183 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 184 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 185 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 186 | Medium | Activity Stub | Activity "unknown" stubbed | uds:QueryEntity.EntityType has no valid source binding and no contract-valid ... | 5 |
| 187 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 188 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 189 | Medium | Activity Stub | Activity "unknown" stubbed | uds:CreateEntityRecord.EntityType has no valid source binding and no contract... | 5 |
| 190 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 191 | Medium | Activity Stub | Activity "unknown" stubbed | ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no con... | 5 |
| 192 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 193 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 194 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 195 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 196 | Medium | Activity Stub | Activity "unknown" stubbed | uds:QueryEntity.EntityType has no valid source binding and no contract-valid ... | 5 |
| 197 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 198 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 199 | Medium | Activity Stub | Activity "unknown" stubbed | uds:GetEntityById.EntityType has no valid source binding and no contract-vali... | 5 |
| 200 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 201 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 202 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 203 | Medium | Activity Stub | Activity "unknown" stubbed | While.Condition has no valid source binding and no contract-valid fallback — ... | 5 |
| 204 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 205 | Medium | Activity Stub | Activity "unknown" stubbed | ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no con... | 5 |
| 206 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 207 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 208 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 209 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 210 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 211 | Medium | Activity Stub | Activity "unknown" stubbed | uds:QueryEntity.EntityType has no valid source binding and no contract-valid ... | 5 |
| 212 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 213 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 214 | Medium | Activity Stub | Activity "unknown" stubbed | uds:CreateEntityRecord.EntityType has no valid source binding and no contract... | 5 |
| 215 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 216 | Medium | Activity Stub | Activity "unknown" stubbed | ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no con... | 5 |
| 217 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 218 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 219 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 220 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 221 | Medium | Activity Stub | Activity "unknown" stubbed | uds:QueryEntity.EntityType has no valid source binding and no contract-valid ... | 5 |
| 222 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 223 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 224 | Medium | Activity Stub | Activity "unknown" stubbed | uds:GetEntityById.EntityType has no valid source binding and no contract-vali... | 5 |
| 225 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |
| 226 | Medium | Activity Stub | Activity "unknown" stubbed | ui:LogMessage.Message has no valid source binding and no contract-valid fallb... | 5 |

### GetTransactionData.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 227 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |
| 228 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |

### Init.xaml (3 items, ~45 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 229 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 230 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 231 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |

### KillAllProcesses.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 232 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "chrome" for ui:KillProcess.Process... | Review and address | 10 |
| 233 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "iexplore" for ui:KillProcess.Proce... | Review and address | 10 |
| 234 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "EXCEL" for ui:KillProcess.ProcessN... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Test recon

### PDD Summary

## 1. Executive Summary  
The “PO and invoice reconciliationV2” project will automate the first-pass validation and routing of vendor-submitted invoices in Coupa. Today, the AP Clerk/Approver manually opens each invoice, verifies that the invoice PO number matches the Coupa PO, checks that the invoice amount is within a 5% tolerance of the PO amount, and then routes matched invoices into Coupa’s Delegation of Authority (DOA) approval chain. Any invoice failing these checks is rejected in Coupa with a free-text rejection comment; Coupa then automatically notifies the supplier, and the supplier resubmits a corrected invoice as a new submission. The process occurs ~50 times per day and averages ~10 minutes per invoice.  

The future state will use UiPath Orchestrator triggers to detect newly submitted Coupa invoices, retrieve structured header data already surfaced by Coupa (PO number, amount, supplier), perform automated validations, and either route invoices for DOA approval or reject them in Coupa with standardized free-text comments. Action Center will be used only for exception handling when required data is missing or ambiguous. The automation is designed for fully unattended execution, aligned with the available robot landscape (11 unattended robots) and the requirement that approvals/rejections and supplier notifications remain managed within Coupa.

## 2. Process Scope  
This PDD covers invoice intake-to-disposition for vendor invoices submitted directly in Coupa as PDFs, where Coupa already surfaces PO number and amount as structured fields in its interface. The process begins when a vendor submits an invoice in Coupa and ends when either (a) the invoice is routed into and progressed by the Coupa DOA approval chain to the next stage, or (b) the invoice is rejected in Coupa (triggering Coupa’s built-in supplier notification). Resubmissions are explicitly treated as new invoice submissions and will re-enter the process from the start.

Out of scope are: three-w...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
[AUTOMATION_TYPE: RPA (Unattended) + HITL (Action Center exceptions)]

- **Primary path is deterministic and rules-based** (PO exists/match; invoice amount within ±5% tolerance; route to DOA), which is best served by **unattended RPA**.
- **Human-in-the-loop is only needed** when Coupa’s structured header fields are **missing/invalid/ambiguous** or when Coupa/UI/API behavior is inconsistent (rare but operationally critical). This is implemented via **Action Center**, not attended robots (none available).
- **Agents** are not used in the critical path because the decisioning is explicit and auditable. Agents may be introduced later for non-critical enrichment (see Platform Recommendations).

### 1.2 Architecture pattern
**Queue-driven dispatcher/performer with REFramework-style robustness**:
- **Trigger** detects/receives “new invoice submitted” events and creates **Queue Items** (one per invoice).
- **Performer** processes queue items with retries, idempotency controls, and standardized exception handling.
- **Action Center** is invoked only for exceptions (missing data / ambiguity), enabling full unattended execution.

This is intentionally chosen over a single monolithic workflow because it:
- Provides **natural scaling** across **11 unattended slots**.
- Gives **retry semantics** and operational visibility per invoice via Queue analytics.
- Simplifies **SLA management** and dead-letter handling.

### 1.3 UiPath services used and why
- **Orchestrator (Queues, Assets, Triggers, Logs, Processes):** Core orchestration, scaling, retries, centralized audit.
- **Triggers:** Queue Trigger to auto-start performer jobs and/or invoke dispatcher on schedule/webhook.
- **Action Center:** Exception tasks for “missing/invalid data” with due dates/escalations.
- **Data Service (Data Fabric):** Persistent, queryable record of invoice decisions, exceptions, and outcomes across runs (for audit, rep...

**Automation Type:** rpa
**Rationale:** The inputs (PO number, amounts) are already structured in Coupa and the decisions are deterministic (match + 5% tolerance + DOA-driven routing), so a rules-based unattended RPA with minimal human-in-the-loop is the best fit.
**Feasibility Complexity:** medium
**Effort Estimate:** 2-4 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | Invoice Submitted in Coupa | Vendor | Coupa | start | — |
| 2 | Ingest New Invoice Event | System | Orchestrator/Triggers | task | — |
| 3 | Get Invoice Header Data (PO, amount, supplier) | System | Coupa | task | — |
| 4 | Invoice Data Complete? | System | Coupa | decision | — |
| 5 | Validate PO Exists in Coupa | System | Coupa | task | — |
| 6 | Route to AP Exception Review (missing data) | AP Clerk/Approver | Action Center | task | — |
| 7 | AP Provides Missing Data / Confirms Rejection | AP Clerk/Approver | Action Center | decision | — |
| 8 | Update Invoice Data in Coupa | System | Coupa | task | — |
| 9 | Reject Invoice in Coupa (insufficient data) | System | Coupa | task | — |
| 10 | PO Match Successful? | System | Coupa | decision | — |
| 11 | Calculate Amount Variance vs PO | System | Coupa | task | — |
| 12 | Reject Invoice in Coupa (PO mismatch) | System | Coupa | task | — |
| 13 | Amount Within 5% Tolerance? | System | Coupa | decision | — |
| 14 | Route Invoice for Approval (per DOA) | System | Coupa | task | — |
| 15 | Approved in Coupa (DOA chain outcome) | AP Clerk/Approver | Coupa | decision | — |
| 16 | Invoice Progressed to Next Stage End | System | Coupa | end | — |
| 17 | Reject Invoice in Coupa (DOA rejected) | AP Clerk/Approver | Coupa | task | — |
| 18 | Reject Invoice in Coupa (out of tolerance) | System | Coupa | task | — |
| 19 | Coupa Sends Rejection Notification to Supplier | System | Coupa | task | — |
| 20 | Invoice Rejected End | System | Coupa | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Coupa
- Orchestrator/Triggers
- Action Center

### User Roles Involved

- Vendor
- System
- AP Clerk/Approver

### Decision Points (Process Map Topology)

**Invoice Data Complete?**
  - [Yes] → Validate PO Exists in Coupa
  - [No] → Route to AP Exception Review (missing data)

**AP Provides Missing Data / Confirms Rejection**
  - [Provide Data] → Update Invoice Data in Coupa
  - [Reject] → Reject Invoice in Coupa (insufficient data)

**PO Match Successful?**
  - [Yes] → Calculate Amount Variance vs PO
  - [No] → Reject Invoice in Coupa (PO mismatch)

**Amount Within 5% Tolerance?**
  - [Yes] → Route Invoice for Approval (per DOA)
  - [No] → Reject Invoice in Coupa (out of tolerance)

**Approved in Coupa (DOA chain outcome)**
  - [Approved] → Invoice Progressed to Next Stage End
  - [Rejected] → Reject Invoice in Coupa (DOA rejected)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Standard |
| Action Center | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.UIAutomation.Activities` |
| 3 | `UiPath.ComplexScenarios.Activities` |
| 4 | `UiPath.DataService.Activities` |
| 5 | `UiPath.Persistence.Activities` |
| 6 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Coupa
- Orchestrator/Triggers
- Action Center

## 7. Credential & Asset Inventory

**Total:** 37 activities (0 hardcoded, 37 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `[Coupa_IRV2_Credentials]` | Credential | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[Coupa_IRV2_BaseUrl]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 2 | `[Coupa_IRV2_TolerancePercent]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 3 | `[Coupa_IRV2_RejectComment_POMismatch]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 4 | `[Coupa_IRV2_RejectComment_OutOfTolerance]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 5 | `[Coupa_IRV2_RejectComment_InsufficientData]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 6 | `[Coupa_IRV2_MaxTransactionSeconds]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 7 | `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 8 | `[Coupa_IRV2_EnableEvidenceSnapshots]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `Performer.xaml` | 42 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `Performer.xaml` | 43 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `Performer.xaml` | 83 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `Performer.xaml` | 84 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `Performer.xaml` | 124 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `Performer.xaml` | 125 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 103 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 106 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 226 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 229 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 349 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 352 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 472 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 475 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 595 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 598 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 718 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `ActionCenterCallbackHandler.xaml` | 721 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 268 | GetCredential | `[Coupa_IRV2_Credentials]` | Credential | — | No |
| `InitAllSettings.xaml` | 269 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 272 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 294 | GetAsset | `[Coupa_IRV2_BaseUrl]` | Unknown | — | No |
| `InitAllSettings.xaml` | 297 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 325 | GetAsset | `[Coupa_IRV2_TolerancePercent]` | Unknown | — | No |
| `InitAllSettings.xaml` | 328 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 356 | GetAsset | `[Coupa_IRV2_RejectComment_POMismatch]` | Unknown | — | No |
| `InitAllSettings.xaml` | 359 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 387 | GetAsset | `[Coupa_IRV2_RejectComment_OutOfTolerance]` | Unknown | — | No |
| `InitAllSettings.xaml` | 390 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 418 | GetAsset | `[Coupa_IRV2_RejectComment_InsufficientData]` | Unknown | — | No |
| `InitAllSettings.xaml` | 421 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 449 | GetAsset | `[Coupa_IRV2_MaxTransactionSeconds]` | Unknown | — | No |
| `InitAllSettings.xaml` | 452 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 480 | GetAsset | `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | Unknown | — | No |
| `InitAllSettings.xaml` | 483 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 511 | GetAsset | `[Coupa_IRV2_EnableEvidenceSnapshots]` | Unknown | — | No |
| `InitAllSettings.xaml` | 514 | GetAsset | `UNKNOWN` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 0 aligned, 11 SDD-only, 9 XAML-only

> **Warning:** 11 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 9 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `Coupa_IRV2_Credentials` | credential | **SDD Only** | type: Credential, description: Credential for Coupa access used by unattended robot (service account). | — | — |
| 2 | `Coupa_IRV2_BaseUrl` | asset | **SDD Only** | type: Text, value: https://<tenant>.coupahost.com, description: Coupa tenant base URL used to navigate/API-call invoice and PO resources. | — | — |
| 3 | `Coupa_IRV2_TolerancePercent` | asset | **SDD Only** | type: Integer, value: 5, description: Invoice amount tolerance percentage vs PO amount (±). Default 5 per PDD. | — | — |
| 4 | `Coupa_IRV2_RejectComment_POMismatch` | asset | **SDD Only** | type: Text, value: PO mismatch—please resubmit with correct PO number., description: Standardized Coupa rejection comment template for PO mismatch. | — | — |
| 5 | `Coupa_IRV2_RejectComment_OutOfTolerance` | asset | **SDD Only** | type: Text, value: Amount exceeds 5% tolerance vs PO—please correct and resubmit., description: Standardized Coupa rejection comment template for out-of-tolerance invoices. | — | — |
| 6 | `Coupa_IRV2_RejectComment_InsufficientData` | asset | **SDD Only** | type: Text, value: Insufficient data (missing/invalid PO number and/or amount)—please correct and resubmit., description: Standardized Coupa rejection comment template for missing/ambiguous data. | — | — |
| 7 | `Coupa_IRV2_MaxTransactionSeconds` | asset | **SDD Only** | type: Integer, value: 600, description: Transaction-level timeout guardrail in seconds (default aligned to current ~10 minutes manual handling). | — | — |
| 8 | `Coupa_IRV2_MaxConsecutiveSystemFailures` | asset | **SDD Only** | type: Integer, value: 5, description: If exceeded, stop normal processing and route to OperationsExceptions queue to protect SLA/operability. | — | — |
| 9 | `Coupa_IRV2_EnableEvidenceSnapshots` | asset | **SDD Only** | type: Bool, value: true, description: When true, store minimal evidence (screenshots/log extracts) to Storage Bucket for audit/troubleshooting. | — | — |
| 10 | `[Coupa_IRV2_BaseUrl]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 294 |
| 11 | `[Coupa_IRV2_TolerancePercent]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 325 |
| 12 | `[Coupa_IRV2_RejectComment_POMismatch]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 356 |
| 13 | `[Coupa_IRV2_RejectComment_OutOfTolerance]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 387 |
| 14 | `[Coupa_IRV2_RejectComment_InsufficientData]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 418 |
| 15 | `[Coupa_IRV2_MaxTransactionSeconds]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 449 |
| 16 | `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 480 |
| 17 | `[Coupa_IRV2_EnableEvidenceSnapshots]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 511 |
| 18 | `[Coupa_IRV2_Credentials]` | credential | **XAML Only** | — | `InitAllSettings.xaml` | 268 |
| 19 | `Coupa_InvoiceReconciliationV2_Invoices` | queue | **SDD Only** | maxRetries: 3, uniqueReference: true, description: Work queue for newly submitted Coupa invoices to be validated (PO existence/match and 5% tolerance) and routed or rejected. | — | — |
| 20 | `Coupa_InvoiceReconciliationV2_OperationsExceptions` | queue | **SDD Only** | maxRetries: 1, uniqueReference: true, description: Operational exceptions requiring support intervention (e.g., Coupa unavailable, repeated UI/API failures). | — | — |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### SDD-Defined Queues (Not Yet in XAML)

| # | Queue Name | Unique Reference | Max Retries | SLA | Note |
|---|-----------|-----------------|-------------|-----|------|
| 1 | `Coupa_InvoiceReconciliationV2_Invoices` | Yes | 3x | — | Defined in SDD but no matching XAML activity — verify implementation |
| 2 | `Coupa_InvoiceReconciliationV2_OperationsExceptions` | Yes | 1x | — | Defined in SDD but no matching XAML activity — verify implementation |

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | Yes |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

## 10. Exception Handling Coverage

**Coverage:** 24/48 high-risk activities inside TryCatch (50%)

### Files Without TryCatch

- `Dispatcher.xaml`
- `CoupaInteractionHelper.xaml`
- `InitAllSettings.xaml`
- `GetTransactionData.xaml`
- `KillAllProcesses.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:268` | Get Coupa_IRV2_Credentials |
| 2 | `InitAllSettings.xaml:269` | ui:GetCredential |
| 3 | `InitAllSettings.xaml:272` | ui:GetCredential |
| 4 | `InitAllSettings.xaml:294` | Get Coupa_IRV2_BaseUrl |
| 5 | `InitAllSettings.xaml:297` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:325` | Get Coupa_IRV2_TolerancePercent |
| 7 | `InitAllSettings.xaml:328` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:356` | Get Coupa_IRV2_RejectComment_POMismatch |
| 9 | `InitAllSettings.xaml:359` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:387` | Get Coupa_IRV2_RejectComment_OutOfTolerance |
| 11 | `InitAllSettings.xaml:390` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:418` | Get Coupa_IRV2_RejectComment_InsufficientData |
| 13 | `InitAllSettings.xaml:421` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:449` | Get Coupa_IRV2_MaxTransactionSeconds |
| 15 | `InitAllSettings.xaml:452` | ui:GetAsset |
| 16 | `InitAllSettings.xaml:480` | Get Coupa_IRV2_MaxConsecutiveSystemFailures |
| 17 | `InitAllSettings.xaml:483` | ui:GetAsset |
| 18 | `InitAllSettings.xaml:511` | Get Coupa_IRV2_EnableEvidenceSnapshots |
| 19 | `InitAllSettings.xaml:514` | ui:GetAsset |
| 20 | `GetTransactionData.xaml:158` | Get Queue Item |
| 21 | `GetTransactionData.xaml:160` | ui:GetTransactionItem |
| 22 | `GetTransactionData.xaml:169` | ui:GetTransactionItem |
| 23 | `SetTransactionStatus.xaml:68` | Set Success |
| 24 | `SetTransactionStatus.xaml:90` | Set Failed |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Queue** | Defined in SDD orchestrator_artifacts: TRG_Coupa_IRV2_Queue_NewInvoices | SDD-specified: TRG_Coupa_IRV2_Queue_NewInvoices | Queue: Coupa_InvoiceReconciliationV2_Invoices | Queue trigger to process newly submitted Coupa invoices as they arrive (fan-out across unattended slots). |
| 2 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_Coupa_IRV2_Time_SafetyNet_Poller | SDD-specified: TRG_Coupa_IRV2_Time_SafetyNet_Poller | Cron: 0 0/30 * ? * MON-FRI * | Safety-net schedule every 30 minutes on business days to handle missed events/backlog recovery (e.g., transient trigger failures). |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| placeholder-value | warning | 3 | Contains 2 placeholder value(s) matching "\bTODO\b" [Developer Implementation Required] |
| invalid-type-argument | warning | 4 | Line 986: x:TypeArguments="__STRUCTURED_OBJECT__UiPath.DataService.DataServiceEntity" may not be a valid .NET type |
| hardcoded-retry-count | warning | 5 | Line 175: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| hardcoded-retry-interval | warning | 5 | Line 175: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| hardcoded-asset-name | warning | 9 | Line 266: asset name "Coupa_IRV2_Credentials" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| EXPRESSION_SYNTAX | warning | 3 | Line 42: Standalone "Yes" corrected to "True" in expression: Yes |
| BARE_TOKEN_QUOTED | warning | 14 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |
| RETRY_INTERVAL_DEFAULTED | warning | 5 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `[Coupa_IRV2_Credentials]` | Yes |
| 5 | Assets | Provision asset: `[Coupa_IRV2_BaseUrl]` | Yes |
| 6 | Assets | Provision asset: `[Coupa_IRV2_TolerancePercent]` | Yes |
| 7 | Assets | Provision asset: `[Coupa_IRV2_RejectComment_POMismatch]` | Yes |
| 8 | Assets | Provision asset: `[Coupa_IRV2_RejectComment_OutOfTolerance]` | Yes |
| 9 | Assets | Provision asset: `[Coupa_IRV2_RejectComment_InsufficientData]` | Yes |
| 10 | Assets | Provision asset: `[Coupa_IRV2_MaxTransactionSeconds]` | Yes |
| 11 | Assets | Provision asset: `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | Yes |
| 12 | Assets | Provision asset: `[Coupa_IRV2_EnableEvidenceSnapshots]` | Yes |
| 13 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 14 | Testing | Run smoke test in target environment | Yes |
| 15 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 16 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 17 | Governance | Peer code review completed | Yes |
| 18 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 19 | Governance | Business process owner validation obtained | Yes |
| 20 | Governance | CoE approval obtained | Yes |
| 21 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Mostly Ready — 35/50 (70%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 4/10 | 50% coverage — consider wrapping remaining activities; 5 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | Queue configuration looks good |
| Build Quality | 1/10 | 48 quality warnings — significant remediation needed; 186 remediations — stub replacements need developer attention |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Almost There:** A few items need attention before production deployment.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 234 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 670 | 670 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 8728 | 4568 | 0 | 0 | 0 | 4160 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 12995 | 8795 | 0 | 2640 | 0 | 1560 |
| executable-path-validator | Yes | 470 | 408 | 0 | 0 | 0 | 62 |
| post-emission-dependency-analyzer | Yes | 12 | 12 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "SetTransactionStatus.xaml",
    "CloseAllApplications.xaml",
    "KillAllProcesses.xaml"
  ],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "Process.xaml",
      "description": "Stripped 4 placeholder token(s) from Process.xaml",
      "developerAction": "Review Process.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "ActionCenterCallbackHandler.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in ActionCenterCallbackHandler.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetCredential.Username in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetCredential.Password in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetTransactionData.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "unknown",
      "description": "Proactively added Newtonsoft.Json@13.0.4 — required by UiPath.WebAPI.Activities"
    }
  ],
  "remediations": [
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 806, col 136: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement Main — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "Dispatcher.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 212, col 162: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement Dispatcher — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "CoupaInteractionHelper.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 113, col 161: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement CoupaInteractionHelper — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 29: Undeclared variable \"maxConsecutiveFailures\" in expression: maxConsecutiveFailures — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 70: Undeclared variable \"maxTransactionSeconds\" in expression: maxTransactionSeconds — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 111: Undeclared variable \"enableEvidenceSnapshots\" in expression: enableEvidenceSnapshots — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 149: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 182: Undeclared variable \"transactionItem\" in expression: transactionItem — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 219: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 291: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 333: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 346: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 402: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 497: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 96: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 112: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 133: Undeclared variable \"InvoiceId\" in expression: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 133: Undeclared variable \"SupplierName\" in expression: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 133: Undeclared variable \"PONumber\" in expression: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 133: Undeclared variable \"InvoiceAmount\" in expression: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 133: Undeclared variable \"CorrelationId\" in expression: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 177: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 177: Undeclared variable \"GetInvoiceDetails\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 178: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 217: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 249: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 262: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 93: Undeclared variable \"tolerancePct\" in expression: tolerancePct — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 216: Undeclared variable \"rejectCommentInsufficientData\" in expression: rejectCommentInsufficientData — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 339: Undeclared variable \"rejectCommentPOMismatch\" in expression: rejectCommentPOMismatch — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 462: Undeclared variable \"rejectCommentOutOfTolerance\" in expression: rejectCommentOutOfTolerance — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 585: Undeclared variable \"coupaBaseUrl\" in expression: coupaBaseUrl — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 708: Undeclared variable \"enableEvidenceSnapshots\" in expression: enableEvidenceSnapshots — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1019: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__[pendingCases] — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1019: Undeclared variable \"pendingCases\" in expression: __STRUCTURED_OBJECT__[pendingCases] — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1363: Undeclared variable \"invoiceCaseId\" in expression: invoiceCaseId — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1480: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1480: Undeclared variable \"ProcessingStatus\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1570: Undeclared variable \"__STRUCTURED_OBJECT__\" in expression: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1631: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 99: Undeclared variable \"Provide\" in expression: Provide Data — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 99: Undeclared variable \"Data\" in expression: Provide Data — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 154: Standalone word \"Approved\" may be an undeclared variable — should it be a string literal \"Approved\"? in expression: Approved",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 154: Undeclared variable \"Approved\" in expression: Approved — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.NamespacesForImplementation block — Studio cannot resolve expression types without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_NAMESPACES",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.ReferencesForImplementation block — Studio cannot resolve assembly references without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_REFERENCES",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.NamespacesForImplementation block — Studio cannot resolve expression types without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_NAMESPACES",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.ReferencesForImplementation block — Studio cannot resolve assembly references without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_REFERENCES",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.NamespacesForImplementation block — Studio cannot resolve expression types without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_NAMESPACES",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.ReferencesForImplementation block — Studio cannot resolve assembly references without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_REFERENCES",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.NamespacesForImplementation block — Studio cannot resolve expression types without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_NAMESPACES",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.ReferencesForImplementation block — Studio cannot resolve assembly references without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_REFERENCES",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 148: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 281: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 289: ui:InvokeWorkflowFile is missing required property \"WorkflowFileName\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 345: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 358: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 414: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 509: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Performer.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 25: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 57: uds:QueryEntity is missing required property \"EntityType\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 95: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 124: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 132: uds:CreateEntityRecord is missing required property \"EntityType\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 171: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 175: ui:InvokeWorkflowFile is missing required property \"WorkflowFileName\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 216: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 261: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InvoiceProcessor.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 29: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 834: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 858: uds:QueryEntity is missing required property \"EntityType\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 974: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1335: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1359: uds:GetEntityById is missing required property \"EntityType\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1516: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1567: ui:LogMessage is missing required property \"Message\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ActionCenterCallbackHandler.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Performer.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Performer.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Performer.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InvoiceProcessor.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InvoiceProcessor.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"EntityObject\" on uds:CreateEntityRecord must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InvoiceProcessor.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in ActionCenterCallbackHandler.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in ActionCenterCallbackHandler.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"EntityId\" on uds:GetEntityById must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in ActionCenterCallbackHandler.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Exception\" on Throw must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"maxConsecutiveFailures\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"maxConsecutiveFailures\" in Performer.xaml with the appropriate type. Expression context: maxConsecutiveFailures",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"maxTransactionSeconds\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"maxTransactionSeconds\" in Performer.xaml with the appropriate type. Expression context: maxTransactionSeconds",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"enableEvidenceSnapshots\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"enableEvidenceSnapshots\" in Performer.xaml with the appropriate type. Expression context: enableEvidenceSnapshots",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"transactionItem\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"transactionItem\" in Performer.xaml with the appropriate type. Expression context: transactionItem",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Performer.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in Performer.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"InvoiceId\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"InvoiceId\" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"SupplierName\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"SupplierName\" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"PONumber\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"PONumber\" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"InvoiceAmount\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"InvoiceAmount\" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"CorrelationId\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"CorrelationId\" in InvoiceProcessor.xaml with the appropriate type. Expression context: New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", I...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"GetInvoiceDetails\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"GetInvoiceDetails\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;vb_expression&q...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in InvoiceProcessor.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"tolerancePct\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"tolerancePct\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: tolerancePct",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"rejectCommentInsufficientData\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"rejectCommentInsufficientData\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: rejectCommentInsufficientData",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"rejectCommentPOMismatch\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"rejectCommentPOMismatch\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: rejectCommentPOMismatch",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"rejectCommentOutOfTolerance\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"rejectCommentOutOfTolerance\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: rejectCommentOutOfTolerance",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"coupaBaseUrl\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"coupaBaseUrl\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: coupaBaseUrl",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"enableEvidenceSnapshots\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"enableEvidenceSnapshots\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: enableEvidenceSnapshots",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__[pendingCases]",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"pendingCases\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"pendingCases\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__[pendingCases]",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"invoiceCaseId\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"invoiceCaseId\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: invoiceCaseId",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"ProcessingStatus\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"ProcessingStatus\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"__STRUCTURED_OBJECT__\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"__STRUCTURED_OBJECT__\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: __STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"value\" in ActionCenterCallbackHandler.xaml with the appropriate type. Expression context: value",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Process.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"Provide\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"Provide\" in Process.xaml with the appropriate type. Expression context: Provide Data",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Process.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"Data\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"Data\" in Process.xaml with the appropriate type. Expression context: Provide Data",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Process.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"Approved\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"Approved\" in Process.xaml with the appropriate type. Expression context: Approved",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] While.Condition has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "While.Condition has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:CreateEntityRecord.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:CreateEntityRecord.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:GetEntityById.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:GetEntityById.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] While.Condition has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "While.Condition has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:CreateEntityRecord.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:CreateEntityRecord.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:InvokeWorkflowFile.WorkflowFileName has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:QueryEntity.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:GetEntityById.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:GetEntityById.EntityType has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:LogMessage.Message has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "Performer.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopPro",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in Performer.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InvoiceProcessor.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"toleranceAsse",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in InvoiceProcessor.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;Coupa_IRV2_Credentials&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in InitAllSettings.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "Process.xaml",
      "detail": "Contains 2 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "Dispatcher.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "CoupaInteractionHelper.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "invalid-type-argument",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Line 986: x:TypeArguments=\"__STRUCTURED_OBJECT__UiPath.DataService.DataServiceEntity\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Line 991: x:TypeArguments=\"__STRUCTURED_OBJECT__UiPath.DataService.DataServiceEntity\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Line 997: x:TypeArguments=\"__STRUCTURED_OBJECT__UiPath.DataService.DataServiceEntity\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "Process.xaml",
      "detail": "Line 22: x:TypeArguments=\"UiPath.Persistence.Activities.FormTask\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Performer.xaml",
      "detail": "Line 175: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Performer.xaml",
      "detail": "Line 175: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "InvoiceProcessor.xaml",
      "detail": "Line 52: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "InvoiceProcessor.xaml",
      "detail": "Line 127: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "InvoiceProcessor.xaml",
      "detail": "Line 52: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "InvoiceProcessor.xaml",
      "detail": "Line 127: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Line 843: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Line 1344: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Line 843: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Line 1344: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 266: asset name \"Coupa_IRV2_Credentials\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 292: asset name \"Coupa_IRV2_BaseUrl\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 323: asset name \"Coupa_IRV2_TolerancePercent\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 354: asset name \"Coupa_IRV2_RejectComment_POMismatch\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 385: asset name \"Coupa_IRV2_RejectComment_OutOfTolerance\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 416: asset name \"Coupa_IRV2_RejectComment_InsufficientData\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 447: asset name \"Coupa_IRV2_MaxTransactionSeconds\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 478: asset name \"Coupa_IRV2_MaxConsecutiveSystemFailures\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 509: asset name \"Coupa_IRV2_EnableEvidenceSnapshots\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 42: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 119: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 138: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_Credentials\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_BaseUrl\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_TolerancePercent\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_RejectComment_POMismatch\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_RejectComment_OutOfTolerance\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_RejectComment_InsufficientData\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_MaxTransactionSeconds\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_MaxConsecutiveSystemFailures\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_EnableEvidenceSnapshots\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"chrome\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"iexplore\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"EXCEL\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Performer.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "InvoiceProcessor.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "InvoiceProcessor.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 1875,
  "studioCompatibility": [
    {
      "file": "Performer.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"EntityId\" on uds:GetEntityById must be a child element, not an attribute"
      ]
    },
    {
      "file": "Process.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[EXPRESSION_SYNTAX_UNFIXABLE] Line 154: Standalone word \"Approved\" may be an undeclared variable — should it be a string literal \"Approved\"? in expression: Approved"
      ]
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "GetTransactionData.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "SetTransactionStatus.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CloseAllApplications.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "KillAllProcesses.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "Init.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Exception\" on Throw must be a child element, not an attribute"
      ]
    },
    {
      "file": "Dispatcher.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "CoupaInteractionHelper.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Dispatcher",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Performer",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "InvoiceProcessor",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CoupaInteractionHelper",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ActionCenterCallbackHandler",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications.xaml",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "4e3de5417557b8facfe246350329deca0c1b5408d3555e3a313b75aa2c39f61a",
      "postRepair": "4e3de5417557b8facfe246350329deca0c1b5408d3555e3a313b75aa2c39f61a",
      "postNormalization": "e076f40ed728feed70ffd78385b3190c7bb1e512e1510b11cdd7a0d38c39ba60",
      "preCanonicalization": "e076f40ed728feed70ffd78385b3190c7bb1e512e1510b11cdd7a0d38c39ba60",
      "archivedFile": "50d9ebd20ff32ba68645220fd755dd5ed161733a340cde5c1c677446d924597d",
      "postFinalValidationInput": "50d9ebd20ff32ba68645220fd755dd5ed161733a340cde5c1c677446d924597d",
      "preArchive": "50d9ebd20ff32ba68645220fd755dd5ed161733a340cde5c1c677446d924597d"
    },
    {
      "workflowFile": "Dispatcher.xaml",
      "postGeneration": "58477132259d53fc97fffb46b39570c4869721ed680cd8a3037ab146132e41f4",
      "postRepair": "58477132259d53fc97fffb46b39570c4869721ed680cd8a3037ab146132e41f4",
      "postNormalization": "4b65cab9ba31553d3de89a04a1542e7715246cd7a478d4d9a81198421720220c",
      "preCanonicalization": "4b65cab9ba31553d3de89a04a1542e7715246cd7a478d4d9a81198421720220c",
      "archivedFile": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "postFinalValidationInput": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "preArchive": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60"
    },
    {
      "workflowFile": "Performer.xaml",
      "postGeneration": "6147168be8f3c084b661d0aa8b234a247c0aef0ce37e86449d74540658a91b43",
      "postRepair": "6147168be8f3c084b661d0aa8b234a247c0aef0ce37e86449d74540658a91b43",
      "postNormalization": "4e401cb027644b8b3f266b8c2967c69dc96d28885e3a027a567ab845a0e610cc",
      "preCanonicalization": "00fe0cfd65d94e97f99399c86089b10b2b0e84be17388031cda54a710b5a11c0",
      "archivedFile": "d1312fb07e9295619279042d5904452770d533bc134b258910e98ad9e759ebaa",
      "postFinalValidationInput": "d1312fb07e9295619279042d5904452770d533bc134b258910e98ad9e759ebaa",
      "preArchive": "d1312fb07e9295619279042d5904452770d533bc134b258910e98ad9e759ebaa"
    },
    {
      "workflowFile": "InvoiceProcessor.xaml",
      "postGeneration": "b8f8f9059b010d445359fcf88815bc10e4c190467484ef519f4c0d332432e3b3",
      "postRepair": "b8f8f9059b010d445359fcf88815bc10e4c190467484ef519f4c0d332432e3b3",
      "postNormalization": "12532c707a315ab00dadb014c236a9618b4d74ddffae382f3383030da4be3990",
      "preCanonicalization": "aa98fbd1fac804239ae1198661de189654426db93d2cf32f77c47deb6c1433b1",
      "archivedFile": "79564a2924ae12e6b1b8006c9f662f8b64ea760479c4637b4bbb1aad226d4fd3",
      "postFinalValidationInput": "79564a2924ae12e6b1b8006c9f662f8b64ea760479c4637b4bbb1aad226d4fd3",
      "preArchive": "79564a2924ae12e6b1b8006c9f662f8b64ea760479c4637b4bbb1aad226d4fd3"
    },
    {
      "workflowFile": "CoupaInteractionHelper.xaml",
      "postGeneration": "3bc036dc89f2f8f453b4cfc5f3532ada5b4317f9ee4db40d875f2063c0ff50f8",
      "postRepair": "3bc036dc89f2f8f453b4cfc5f3532ada5b4317f9ee4db40d875f2063c0ff50f8",
      "postNormalization": "50534e61fdd4256a1a22cdc533008ed6f3e5a8e4900b2f93f88a67ef49977877",
      "preCanonicalization": "50534e61fdd4256a1a22cdc533008ed6f3e5a8e4900b2f93f88a67ef49977877",
      "archivedFile": "8a71d438e668a455f93028872253264d165bcdf4df72ba640787809905a4187c",
      "postFinalValidationInput": "8a71d438e668a455f93028872253264d165bcdf4df72ba640787809905a4187c",
      "preArchive": "8a71d438e668a455f93028872253264d165bcdf4df72ba640787809905a4187c"
    },
    {
      "workflowFile": "ActionCenterCallbackHandler.xaml",
      "postGeneration": "acd9d84f89755220b54eb06866783b7bd559d130f9e37ef7b5a293db3cf6182a",
      "postRepair": "acd9d84f89755220b54eb06866783b7bd559d130f9e37ef7b5a293db3cf6182a",
      "postNormalization": "cb9e7814e2fb5eae8a71703eb547c909a5533ce00aab83c60c7621bc197bdf85",
      "preCanonicalization": "0894b2db4d38fc10a345feed415409bb470704704d93ca99580e59d6ed8665ad",
      "archivedFile": "93f7920cf7671af8a8332bfe2cdfc64d556397fc4b4a89ce25e8fa6a4884b16c",
      "postFinalValidationInput": "93f7920cf7671af8a8332bfe2cdfc64d556397fc4b4a89ce25e8fa6a4884b16c",
      "preArchive": "93f7920cf7671af8a8332bfe2cdfc64d556397fc4b4a89ce25e8fa6a4884b16c"
    },
    {
      "workflowFile": "Process.xaml",
      "postGeneration": "413bdd86a61ae214e228841163ba2594d15218529cc9678b2d89e4fb5eae6592",
      "postRepair": "413bdd86a61ae214e228841163ba2594d15218529cc9678b2d89e4fb5eae6592",
      "postNormalization": "413bdd86a61ae214e228841163ba2594d15218529cc9678b2d89e4fb5eae6592",
      "preCanonicalization": "6d2dc9f76314cf8efc35c6dc4daa19383e8e8d6fc5b7ed4cfe8ee37ce31f199f",
      "archivedFile": "3963ec684036c3e5cb9a8ddac14c1b2a0b90eb3ffe89f02a0871f483bcf32bbd",
      "postFinalValidationInput": "3963ec684036c3e5cb9a8ddac14c1b2a0b90eb3ffe89f02a0871f483bcf32bbd",
      "preArchive": "3963ec684036c3e5cb9a8ddac14c1b2a0b90eb3ffe89f02a0871f483bcf32bbd"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "fb9e5a14dd4888a974e0cbfaadd74be0290b449d24820e98fa6d401e5534ecbf",
      "postRepair": "fb9e5a14dd4888a974e0cbfaadd74be0290b449d24820e98fa6d401e5534ecbf",
      "postNormalization": "67975e4695e29bb59dee74f0bef9bd5eb9b189926ceabb7bd1f26b333c9ea6c6",
      "preCanonicalization": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
      "archivedFile": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
      "postFinalValidationInput": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
      "preArchive": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e"
    },
    {
      "workflowFile": "GetTransactionData.xaml",
      "postGeneration": "36e01376637da856cd901a32fe16d33294da06bcced0df8a1b36d98ff186b4fc",
      "postRepair": "36e01376637da856cd901a32fe16d33294da06bcced0df8a1b36d98ff186b4fc",
      "postNormalization": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "preCanonicalization": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "archivedFile": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "postFinalValidationInput": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "preArchive": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686"
    },
    {
      "workflowFile": "Init.xaml",
      "postGeneration": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postRepair": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postNormalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "preCanonicalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "archivedFile": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "postFinalValidationInput": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "preArchive": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  },
  "invokeSerializationFixes": [
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;CoupaInvoiceId\\&quot;, InvoiceId}, {\\&quot;SupplierName\\&quot;, SupplierName}, {\\&q",
      "canonicalizedForm": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", InvoiceId}, {\"SupplierName\", SupplierName}, {\"PONumber\", PONumber}, {\"InvoiceAmount\", InvoiceAmount}, {\"ProcessingStatus\", \"InProgress\"}, {\"CorrelationId\", CorrelationId}, {\"LastUpdatedAt\", DateTime.UtcNow.ToString(\"o\")}}]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    }
  ],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_Config",
      "offendingExpression": "io_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_Config\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_QueueName",
      "offendingExpression": "in_QueueName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_QueueName\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionItem",
      "offendingExpression": "out_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_TransactionNumber",
      "offendingExpression": "io_TransactionNumber",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_TransactionNumber\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;ConsecutiveSystemFailures&quot;,&quot;operator&quot;:&quot;&gt;=&quot;,&quot;right&quot;:&quot;maxConsecutiveFailu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"Performer\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionItem&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"Performer\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionElapsedSeconds&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;maxTransactionSecond",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"Performer\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"Performer\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isSystemException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"Performer\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;ConsecutiveSystemFailures&quot;,&quot;operator&quot;:&quot;&gt;=&quot;,&quot;right&quot;:&quot;maxConsecutiveFailu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"Performer\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;existingCaseResults&quot;,&quot;operator&quot;:&quot;IsNot&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"InvoiceProcessor\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isDuplicateCase&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"InvoiceProcessor\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;coupaInteractionOutcome&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Success&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"InvoiceProcessor\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;parsedInvoiceAmount&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"InvoiceProcessor\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isDataComplete&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"InvoiceProcessor\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;CStr(currentCase(\\&quot;ProcessingStatus\\&quot;))&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"ActionCenterCallbackHandler\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "ProcessingStatus",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;CStr(currentCase(\\&quot;ProcessingStatus\\&quot;))&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"ProcessingStatus\" referenced in Condition but not declared in workflow \"ActionCenterCallbackHandler\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "__STRUCTURED_OBJECT__",
      "offendingExpression": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;caseResolution&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;ProvideData&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"__STRUCTURED_OBJECT__\" referenced in Condition but not declared in workflow \"ActionCenterCallbackHandler\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "value",
      "offendingExpression": "[value]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"value\" referenced in child element <Assign.Value> but not declared in workflow \"ActionCenterCallbackHandler\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Provide",
      "offendingExpression": "[Provide Data]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Provide\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Data",
      "offendingExpression": "[Provide Data]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Data\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Approved",
      "offendingExpression": "[Approved]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Approved\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Init.xaml",
      "workflow": "Init",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_Config",
      "offendingExpression": "out_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_Config\" referenced in Key but not declared in workflow \"Init\" — expression replaced with \"Nothing\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 31 symbol scope defect(s), 2 sentinel replacement(s), 0 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: Dispatcher — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic here",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;ConsecutiveSystemFailures&quot;,&quot;operator&quot;:&quot;&gt;=&quot;,&quot;right&quot;:&quot;maxConsecutiveFailu",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionItem&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionElapsedSeconds&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;maxTransactionSecond",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isSystemException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;ConsecutiveSystemFailures&quot;,&quot;operator&quot;:&quot;&gt;=&quot;,&quot;right&quot;:&quot;maxConsecutiveFailu",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;existingCaseResults&quot;,&quot;operator&quot;:&quot;IsNot&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isDuplicateCase&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;coupaInteractionOutcome&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Success&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;parsedInvoiceAmount&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isDataComplete&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/CoupaInteractionHelper.xaml",
      "workflow": "CoupaInteractionHelper",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: CoupaInteractionHelper — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actua",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;CStr(currentCase(\\&quot;ProcessingStatus\\&quot;))&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[__STRUCTURED_OBJECT__{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;caseResolution&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;ProvideData&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    }
  ],
  "sentinelReplacements": [
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: Dispatcher — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic here",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: Dispatcher — this workflow was auto-generated as a placeholder beca\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/CoupaInteractionHelper.xaml",
      "workflow": "CoupaInteractionHelper",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: CoupaInteractionHelper — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actua",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: CoupaInteractionHelper — this workflow was auto-generated as a plac\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    }
  ],
  "unresolvableJsonDefects": [],
  "requiredPropertyBindings": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initializing CoupaInvoiceReconV2 ===&quot;]",
      "resolvedValue": "[&quot;=== Initializing CoupaInvoiceReconV2 ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initializing CoupaInvoiceReconV2 ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Init.xaml",
      "resolvedValue": "Init.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Init.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_SystemReady]",
      "resolvedValue": "[bool_SystemReady]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_SystemReady",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization complete&quot;]",
      "resolvedValue": "[&quot;Initialization complete&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization complete&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetTransactionData.xaml",
      "resolvedValue": "GetTransactionData.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetTransactionData.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Process.xaml",
      "resolvedValue": "Process.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Process.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryNumber]",
      "resolvedValue": "[int_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryNumber",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "0",
      "resolvedValue": "0",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "0",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Dispatcher.xaml",
      "resolvedValue": "Dispatcher.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Dispatcher.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Performer.xaml",
      "resolvedValue": "Performer.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Performer.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceProcessor.xaml",
      "resolvedValue": "InvoiceProcessor.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceProcessor.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CoupaInteractionHelper.xaml",
      "resolvedValue": "CoupaInteractionHelper.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CoupaInteractionHelper.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ActionCenterCallbackHandler.xaml",
      "resolvedValue": "ActionCenterCallbackHandler.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ActionCenterCallbackHandler.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "resolvedValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; Da",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "resolvedValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== CoupaInvoiceReconV2 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "resolvedValue": "[&quot;=== CoupaInvoiceReconV2 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== CoupaInvoiceReconV2 Complete. Transactions processed: &quot; &amp; in",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Dispatcher ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Dispatcher ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Dispatcher ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Performer ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Performer ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Performer ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read MaxConsecutiveSystemFailures asset into local variable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read MaxConsecutiveSystemFailures asset into local variable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read MaxConsecutiveSystemFailures asset into local variable faile",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read MaxTransactionSeconds asset into local variable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read MaxTransactionSeconds asset into local variable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read MaxTransactionSeconds asset into local variable failed (&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read EnableEvidenceSnapshots asset into local variable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read EnableEvidenceSnapshots asset into local variable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read EnableEvidenceSnapshots asset into local variable failed (&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if consecutive system failures already exceed threshold before fetching next item&quot;]",
      "resolvedValue": "[&quot;Then path: Check if consecutive system failures already exceed threshold before fetching next item&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if consecutive system failures already exceed threshold ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if consecutive system failures already exceed threshold before fetching next item&quot;]",
      "resolvedValue": "[&quot;Else path: Check if consecutive system failures already exceed threshold before fetching next item&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if consecutive system failures already exceed threshold ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Get next transaction item from Coupa invoices queue, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Get next transaction item from Coupa invoices queue, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Get next transaction item from Coupa invoices queue, ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Get next transaction item from Coupa invoices queue failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Get next transaction item from Coupa invoices queue failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Get next transaction item from Coupa invoices queue fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if queue returned a transaction item (null = queue empty)&quot;]",
      "resolvedValue": "[&quot;Then path: Check if queue returned a transaction item (null = queue empty)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if queue returned a transaction item (null = queue empty",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if queue returned a transaction item (null = queue empty)&quot;]",
      "resolvedValue": "[&quot;Else path: Check if queue returned a transaction item (null = queue empty)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if queue returned a transaction item (null = queue empty",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract queue item fields: InvoiceId, Supplier, PONumber, InvoiceAmount, Reference failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract queue item fields: InvoiceId, Supplier, PONumber, InvoiceAmount, Reference failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract queue item fields: InvoiceId, Supplier, PONumber, Invoice",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"correlationId\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"correlationId\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"correlationId\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"System.Guid.NewGuid().ToString()\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"System.Guid.NewGuid().ToString()\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"System.Guid.NewGui",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"transactionStartTime\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"transactionStartTime\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"transactionStartTime\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"DateTime.UtcNow\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"DateTime.UtcNow\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"DateTime.UtcNow\"\"}",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke InvoiceProcessor with queue item context and Config failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke InvoiceProcessor with queue item context and Config failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke InvoiceProcessor with queue item context and Config failed",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"transactionElapsedSeconds\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"transactionElapsedSeconds\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"transactionElapsedSecond",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"CInt(DateTime.UtcNow.Subtract(transactionStartTime).TotalSeconds)\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"CInt(DateTime.UtcNow.Subtract(transactionStartTime).TotalSeconds)\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"CInt(DateTime.UtcN",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Log warning if transaction exceeded the time guardrail&quot;]",
      "resolvedValue": "[&quot;Then path: Log warning if transaction exceeded the time guardrail&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Log warning if transaction exceeded the time guardrail&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Log warning if transaction exceeded the time guardrail&quot;]",
      "resolvedValue": "[&quot;Else path: Log warning if transaction exceeded the time guardrail&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Log warning if transaction exceeded the time guardrail&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Decide transaction outcome: BusinessException, SystemException, or Success&quot;]",
      "resolvedValue": "[&quot;Then path: Decide transaction outcome: BusinessException, SystemException, or Success&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Decide transaction outcome: BusinessException, SystemException",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Decide transaction outcome: BusinessException, SystemException, or Success&quot;]",
      "resolvedValue": "[&quot;Else path: Decide transaction outcome: BusinessException, SystemException, or Success&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Decide transaction outcome: BusinessException, SystemException",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Set queue item status Successful for business exception (handled exception) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Set queue item status Successful for business exception (handled exception) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Set queue item status Successful for business exception (handled ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"ConsecutiveSystemFailures\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"ConsecutiveSystemFailures\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"ConsecutiveSystemFailure",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"0\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"0\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"0\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if outcome is system exception (else-branch of business exception check)&quot;]",
      "resolvedValue": "[&quot;Then path: Check if outcome is system exception (else-branch of business exception check)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if outcome is system exception (else-branch of business ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if outcome is system exception (else-branch of business exception check)&quot;]",
      "resolvedValue": "[&quot;Else path: Check if outcome is system exception (else-branch of business exception check)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if outcome is system exception (else-branch of business ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Take screenshot on system exception if evidence snapshots enabled failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Take screenshot on system exception if evidence snapshots enabled failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Take screenshot on system exception if evidence snapshots enabled",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"ConsecutiveSystemFailures\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"ConsecutiveSystemFailures\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"ConsecutiveSystemFailure",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"ConsecutiveSystemFailures + 1\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"ConsecutiveSystemFailures + 1\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"ConsecutiveSystemF",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Set queue item status Failed to trigger Orchestrator retry failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Set queue item status Failed to trigger Orchestrator retry failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Set queue item status Failed to trigger Orchestrator retry failed",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if circuit breaker threshold is now exceeded after incrementing&quot;]",
      "resolvedValue": "[&quot;Then path: Check if circuit breaker threshold is now exceeded after incrementing&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if circuit breaker threshold is now exceeded after incre",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if circuit breaker threshold is now exceeded after incrementing&quot;]",
      "resolvedValue": "[&quot;Else path: Check if circuit breaker threshold is now exceeded after incrementing&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 44,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if circuit breaker threshold is now exceeded after incre",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 46,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 47,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Enqueue operational exception record to OperationsExceptions queue failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Enqueue operational exception record to OperationsExceptions queue failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 48,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Enqueue operational exception record to OperationsExceptions queu",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopProcessing\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"literal\"\",\"\"value\"\":\"\"True\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Performer ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Performer ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 49,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Performer ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: InvoiceProcessor ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: InvoiceProcessor ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: InvoiceProcessor ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"toleranceAsset\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"toleranceAsset\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"toleranceAsset\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_TolerancePercent\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_TolerancePercent\\\"\")), \\\"\"5\\\"\")\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_TolerancePercent\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_TolerancePercent\\\"\")), \\\"\"5\\\"\")\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.Contains",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"tolerancePercent\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"tolerancePercent\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"tolerancePercent\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Integer.TryParse(toleranceAsset, New Integer()), CInt(toleranceAsset), 5)\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Integer.TryParse(toleranceAsset, New Integer()), CInt(toleranceAsset), 5)\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Integer.TryPars",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentPOMismatch\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentPOMismatch\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentPOMismatch\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_RejectComment_POMismatch\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_RejectComment_POMismatch\\\"\")), \\\"\"PO mismatch—please resubmit with correct PO number.\\\"\")\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_RejectComment_POMismatch\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_RejectComment_POMismatch\\\"\")), \\\"\"PO mismatch—please resubmit with correct PO number.\\\"\")\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.Contains",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentOutOfTolerance\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentOutOfTolerance\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentOutOfTolera",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_RejectComment_OutOfTolerance\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_RejectComment_OutOfTolerance\\\"\")), \\\"\"Amount exceeds 5% tolerance vs PO—please correct and resubmit.\\\"\")\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_RejectComment_OutOfTolerance\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_RejectComment_OutOfTolerance\\\"\")), \\\"\"Amount exceeds 5% tolerance vs PO—please correct and resubmit.\\\"\")\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.Contains",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentInsufficientData\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentInsufficientData\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"rejectCommentInsufficien",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_RejectComment_InsufficientData\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_RejectComment_InsufficientData\\\"\")), \\\"\"Insufficient data (missing/invalid PO number and/or amount)—please correct and resubmit.\\\"\")\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_RejectComment_InsufficientData\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_RejectComment_InsufficientData\\\"\")), \\\"\"Insufficient data (missing/invalid PO number and/or amount)—please correct and resubmit.\\\"\")\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.Contains",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"enableEvidenceSnapshots\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"enableEvidenceSnapshots\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"enableEvidenceSnapshots\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_EnableEvidenceSnapshots\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_EnableEvidenceSnapshots\\\"\")), \\\"\"true\\\"\")\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.ContainsKey(\\\"\"Coupa_IRV2_EnableEvidenceSnapshots\\\"\"), CStr(Config(\\\"\"Coupa_IRV2_EnableEvidenceSnapshots\\\"\")), \\\"\"true\\\"\")\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(Config.Contains",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for IDEMPOTENCY CHECK — Query Data Service for existing InvoiceCase with this InvoiceId, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for IDEMPOTENCY CHECK — Query Data Service for existing InvoiceCase with this InvoiceId, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for IDEMPOTENCY CHECK — Query Data Service for existing I",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] IDEMPOTENCY CHECK — Query Data Service for existing InvoiceCase with this InvoiceId failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] IDEMPOTENCY CHECK — Query Data Service for existing InvoiceCase with this InvoiceId failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] IDEMPOTENCY CHECK — Query Data Service for existing Inv",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Evaluate idempotency result and extract existing case status if present&quot;]",
      "resolvedValue": "[&quot;Then path: Evaluate idempotency result and extract existing case status if present&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Evaluate idempotency result and extract existing case status i",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Evaluate idempotency result and extract existing case status if present&quot;]",
      "resolvedValue": "[&quot;Else path: Evaluate idempotency result and extract existing case status if present&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Evaluate idempotency result and extract existing case status i",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"isDuplicateCase\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"isDuplicateCase\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"isDuplicateCase\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"existingCaseStatus = \\\"\"Rejected\\\"\" OrElse existingCaseStatus = \\\"\"RoutedForApproval\\\"\" OrElse existingCaseStatus = \\\"\"DuplicateSkipped\\\"\"\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"existingCaseStatus = \\\"\"Rejected\\\"\" OrElse existingCaseStatus = \\\"\"RoutedForApproval\\\"\" OrElse existingCaseStatus = \\\"\"DuplicateSkipped\\\"\"\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"existingCaseStatus",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: BRANCH: If duplicate terminal case, set outcome and exit early&quot;]",
      "resolvedValue": "[&quot;Then path: BRANCH: If duplicate terminal case, set outcome and exit early&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: BRANCH: If duplicate terminal case, set outcome and exit early",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: BRANCH: If duplicate terminal case, set outcome and exit early&quot;]",
      "resolvedValue": "[&quot;Else path: BRANCH: If duplicate terminal case, set outcome and exit early&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: BRANCH: If duplicate terminal case, set outcome and exit early",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", InvoiceId}, {\"SupplierName\", SupplierName}, {\"PONumber\", PONumber}, {\"InvoiceAmount\", InvoiceAmount}, {\"ProcessingStatus\", \"InProgress\"}, {\"CorrelationId\", CorrelationId}, {\"LastUpdatedAt\", DateTime.UtcNow.ToString(\"o\")}}]",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", InvoiceId}, {\"SupplierName\", SupplierName}, {\"PONumber\", PONumber}, {\"InvoiceAmount\", InvoiceAmount}, {\"ProcessingStatus\", \"InProgress\"}, {\"CorrelationId\", CorrelationId}, {\"LastUpdatedAt\", DateTime.UtcNow.ToString(\"o\")}}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", InvoiceId}, {\"Suppli",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for UPSERT InvoiceCase status to InProgress in Data Service, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for UPSERT InvoiceCase status to InProgress in Data Service, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for UPSERT InvoiceCase status to InProgress in Data Servi",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] UPSERT InvoiceCase status to InProgress in Data Service failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] UPSERT InvoiceCase status to InProgress in Data Service failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] UPSERT InvoiceCase status to InProgress in Data Service",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] REFRESH INVOICE DATA — Invoke CoupaInteractionHelper to GetInvoiceDetails failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] REFRESH INVOICE DATA — Invoke CoupaInteractionHelper to GetInvoiceDetails failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] REFRESH INVOICE DATA — Invoke CoupaInteractionHelper to GetInvoic",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if Coupa GetInvoiceDetails call succeeded&quot;]",
      "resolvedValue": "[&quot;Then path: Check if Coupa GetInvoiceDetails call succeeded&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if Coupa GetInvoiceDetails call succeeded&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if Coupa GetInvoiceDetails call succeeded&quot;]",
      "resolvedValue": "[&quot;Else path: Check if Coupa GetInvoiceDetails call succeeded&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if Coupa GetInvoiceDetails call succeeded&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"refreshedPONumber\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"refreshedPONumber\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"refreshedPONumber\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOrWhiteSpace(refreshedPONumber), PONumber, refreshedPONumber)\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOrWhiteSpace(refreshedPONumber), PONumber, refreshedPONumber)\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"refreshedInvoiceAmount\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"refreshedInvoiceAmount\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"refreshedInvoiceAmount\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOrWhiteSpace(refreshedInvoiceAmount), InvoiceAmount, refreshedInvoiceAmount)\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOrWhiteSpace(refreshedInvoiceAmount), InvoiceAmount, refreshedInvoiceAmount)\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"isDataComplete\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"isDataComplete\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"isDataComplete\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"Not String.IsNullOrWhiteSpace(refreshedPONumber) AndAlso Not String.IsNullOrWhiteSpace(refreshedInvoiceAmount) AndAlso Not String.IsNullOrWhiteSpace(refreshedSupplierName)\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"Not String.IsNullOrWhiteSpace(refreshedPONumber) AndAlso Not String.IsNullOrWhiteSpace(refreshedInvoiceAmount) AndAlso Not String.IsNullOrWhiteSpace(refreshedSupplierName)\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"Not String.IsNullO",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"validationErrorReason\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"validationErrorReason\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"validationErrorReason\"\"}",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOrWhiteSpace(refreshedPONumber), \\\"\"MissingPONumber\\\"\", If(String.IsNullOrWhiteSpace(refreshedInvoiceAmount), \\\"\"MissingInvoiceAmount\\\"\", If(String.IsNullOrWhiteSpace(refreshedSupplierName), \\\"\"MissingSupplierName\\\"\", \\\"\"\\\"\")))\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOrWhiteSpace(refreshedPONumber), \\\"\"MissingPONumber\\\"\", If(String.IsNullOrWhiteSpace(refreshedInvoiceAmount), \\\"\"MissingInvoiceAmount\\\"\", If(String.IsNullOrWhiteSpace(refreshedSupplierName), \\\"\"MissingSupplierName\\\"\", \\\"\"\\\"\")))\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"If(String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"parsedInvoiceAmount\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"parsedInvoiceAmount\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"parsedInvoiceAmount\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"Decimal.TryParse(refreshedInvoiceAmount, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, New Decimal())\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"Decimal.TryParse(refreshedInvoiceAmount, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, New Decimal())\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"Decimal.TryParse(r",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Refine completeness flag — mark incomplete if amount is non-numeric&quot;]",
      "resolvedValue": "[&quot;Then path: Refine completeness flag — mark incomplete if amount is non-numeric&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Refine completeness flag — mark incomplete if amount is non-nu",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Refine completeness flag — mark incomplete if amount is non-numeric&quot;]",
      "resolvedValue": "[&quot;Else path: Refine completeness flag — mark incomplete if amount is non-numeric&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Refine completeness flag — mark incomplete if amount is non-nu",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: BRANCH: Incomplete data path — Create Action Center task for AP exception review&quot;]",
      "resolvedValue": "[&quot;Then path: BRANCH: Incomplete data path — Create Action Center task for AP exception review&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: BRANCH: Incomplete data path — Create Action Center task for A",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: BRANCH: Incomplete data path — Create Action Center task for AP exception review&quot;]",
      "resolvedValue": "[&quot;Else path: BRANCH: Incomplete data path — Create Action Center task for AP exception review&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: BRANCH: Incomplete data path — Create Action Center task for A",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"taskDueAt\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"taskDueAt\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"taskDueAt\"\"}\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"DateTime.UtcNow.AddHours(4)\"\"}\"",
      "resolvedValue": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"DateTime.UtcNow.AddHours(4)\"\"}\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"vb_expression\"\",\"\"value\"\":\"\"DateTime.UtcNow.Ad",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InvoiceProcessor ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InvoiceProcessor ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InvoiceProcessor ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CoupaInteractionHelper.xaml",
      "workflow": "CoupaInteractionHelper",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CoupaInteractionHelper ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CoupaInteractionHelper ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CoupaInteractionHelper ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: ActionCenterCallbackHandler ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: ActionCenterCallbackHandler ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: ActionCenterCallbackHandler ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;correlationId&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;correlationId&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(Config IsNot Nothing AndAlso Config.ContainsKey(\\&quot;&quot;CorrelationId\\&quot;&quot;), CStr(Config(\\&quot;&quot;CorrelationId\\&quot;&quot;)), System.Guid.NewGuid().ToString())&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(Config IsNot Nothing AndAlso Config.ContainsKey(\\&quot;&quot;CorrelationId\\&quot;&quot;), CStr(Config(\\&quot;&quot;CorrelationId\\&quot;&quot;)), System.Guid.NewGuid().ToString())&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;tasksProcessedCount&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;tasksProcessedCount&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;literal&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;0&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;literal&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;0&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;literal&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;escalationsSentCount&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;escalationsSentCount&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;literal&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;0&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;literal&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;0&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;literal&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa_IRV2_TolerancePercent asset into tolerancePct failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa_IRV2_TolerancePercent asset into tolerancePct failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa_IRV2_TolerancePercent asset into tolerancePct failed (",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa_IRV2_RejectComment_InsufficientData asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa_IRV2_RejectComment_InsufficientData asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa_IRV2_RejectComment_InsufficientData asset failed (&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa_IRV2_RejectComment_POMismatch asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa_IRV2_RejectComment_POMismatch asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa_IRV2_RejectComment_POMismatch asset failed (&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa_IRV2_RejectComment_OutOfTolerance asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa_IRV2_RejectComment_OutOfTolerance asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa_IRV2_RejectComment_OutOfTolerance asset failed (&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa_IRV2_BaseUrl asset into coupaBaseUrl failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa_IRV2_BaseUrl asset into coupaBaseUrl failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa_IRV2_BaseUrl asset into coupaBaseUrl failed (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa_IRV2_EnableEvidenceSnapshots asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa_IRV2_EnableEvidenceSnapshots asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa_IRV2_EnableEvidenceSnapshots asset failed (&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;apEscalationEmail&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;apEscalationEmail&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(Config IsNot Nothing AndAlso Config.ContainsKey(\\&quot;&quot;APEscalationEmail\\&quot;&quot;), CStr(Config(\\&quot;&quot;APEscalationEmail\\&quot;&quot;)), \\&quot;&quot;ap-team@company.com\\&quot;&quot;)&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(Config IsNot Nothing AndAlso Config.ContainsKey(\\&quot;&quot;APEscalationEmail\\&quot;&quot;), CStr(Config(\\&quot;&quot;APEscalationEmail\\&quot;&quot;)), \\&quot;&quot;ap-team@company.com\\&quot;&quot;)&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Query Data Service for InvoiceExceptionTask records with Status=Completed, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Query Data Service for InvoiceExceptionTask records with Status=Completed, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Query Data Service for InvoiceExceptionTask records w",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Query Data Service for InvoiceExceptionTask records with Status=Completed failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Query Data Service for InvoiceExceptionTask records with Status=Completed failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Query Data Service for InvoiceExceptionTask records wit",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[__STRUCTURED_OBJECT__[pendingCases]]",
      "resolvedValue": "[__STRUCTURED_OBJECT__[pendingCases]]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[__STRUCTURED_OBJECT__[pendingCases]]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing item in: ForEach completed exception task record&quot;]",
      "resolvedValue": "[&quot;Processing item in: ForEach completed exception task record&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing item in: ForEach completed exception task record&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] ForEach completed exception task record failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] ForEach completed exception task record failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] ForEach completed exception task record failed (&quot; &amp; exce",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;currentTask&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;currentTask&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;currentTask&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;currentTask&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;invoiceCaseId&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;invoiceCaseId&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;CStr(currentTask(\\&quot;&quot;InvoiceCaseId\\&quot;&quot;))&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;CStr(currentTask(\\&quot;&quot;InvoiceCaseId\\&quot;&quot;))&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract key fields from currentTask: InvoiceCaseId, ActionCenterTaskId, Resolution, ProvidedPONumber, ProvidedInvoiceAmount, DueAt, EscalationCount failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract key fields from currentTask: InvoiceCaseId, ActionCenterTaskId, Resolution, ProvidedPONumber, ProvidedInvoiceAmount, DueAt, EscalationCount failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract key fields from currentTask: InvoiceCaseId, ActionCenterT",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;actionCenterTaskId&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;actionCenterTaskId&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;CStr(currentTask(\\&quot;&quot;ActionCenterTaskId\\&quot;&quot;))&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;CStr(currentTask(\\&quot;&quot;ActionCenterTaskId\\&quot;&quot;))&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;caseResolution&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;caseResolution&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;Resolution\\&quot;&quot;) IsNot Nothing, CStr(currentTask(\\&quot;&quot;Resolution\\&quot;&quot;)), \\&quot;&quot;\\&quot;&quot;)&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;Resolution\\&quot;&quot;) IsNot Nothing, CStr(currentTask(\\&quot;&quot;Resolution\\&quot;&quot;)), \\&quot;&quot;\\&quot;&quot;)&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;taskDueAt&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;taskDueAt&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;DueAt\\&quot;&quot;) IsNot Nothing, CDate(currentTask(\\&quot;&quot;DueAt\\&quot;&quot;)), DateTime.Now.AddHours(4))&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;DueAt\\&quot;&quot;) IsNot Nothing, CDate(currentTask(\\&quot;&quot;DueAt\\&quot;&quot;)), DateTime.Now.AddHours(4))&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;taskEscalationCount&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;taskEscalationCount&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;EscalationCount\\&quot;&quot;) IsNot Nothing, CInt(currentTask(\\&quot;&quot;EscalationCount\\&quot;&quot;)), 0)&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;EscalationCount\\&quot;&quot;) IsNot Nothing, CInt(currentTask(\\&quot;&quot;EscalationCount\\&quot;&quot;)), 0)&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "GetEntityById",
      "propertyName": "EntityId",
      "sourceBinding": "attribute-value",
      "originalValue": "[invoiceCaseId]",
      "resolvedValue": "[invoiceCaseId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[invoiceCaseId]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Retrieve parent InvoiceCase record from Data Service by InvoiceCaseId, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Retrieve parent InvoiceCase record from Data Service by InvoiceCaseId, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Retrieve parent InvoiceCase record from Data Service ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Retrieve parent InvoiceCase record from Data Service by InvoiceCaseId failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Retrieve parent InvoiceCase record from Data Service by InvoiceCaseId failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Retrieve parent InvoiceCase record from Data Service by",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Guard: verify InvoiceCase ProcessingStatus is still PendingHuman&quot;]",
      "resolvedValue": "[&quot;Then path: Guard: verify InvoiceCase ProcessingStatus is still PendingHuman&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Guard: verify InvoiceCase ProcessingStatus is still PendingHum",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Guard: verify InvoiceCase ProcessingStatus is still PendingHuman&quot;]",
      "resolvedValue": "[&quot;Else path: Guard: verify InvoiceCase ProcessingStatus is still PendingHuman&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Guard: verify InvoiceCase ProcessingStatus is still PendingHum",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;coupaInvoiceId&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;coupaInvoiceId&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;CStr(currentCase(\\&quot;&quot;CoupaInvoiceId\\&quot;&quot;))&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;CStr(currentCase(\\&quot;&quot;CoupaInvoiceId\\&quot;&quot;))&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;supplierName&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;supplierName&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentCase(\\&quot;&quot;SupplierName\\&quot;&quot;) IsNot Nothing, CStr(currentCase(\\&quot;&quot;SupplierName\\&quot;&quot;)), \\&quot;&quot;Unknown Supplier\\&quot;&quot;)&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentCase(\\&quot;&quot;SupplierName\\&quot;&quot;) IsNot Nothing, CStr(currentCase(\\&quot;&quot;SupplierName\\&quot;&quot;)), \\&quot;&quot;Unknown Supplier\\&quot;&quot;)&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;isOverdue&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;isOverdue&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;DateTime.Now &gt; taskDueAt&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;DateTime.Now &gt; taskDueAt&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on Resolution: ProvideData or Reject&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on Resolution: ProvideData or Reject&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on Resolution: ProvideData or Reject&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on Resolution: ProvideData or Reject&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on Resolution: ProvideData or Reject&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on Resolution: ProvideData or Reject&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;providedPONumber&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;providedPONumber&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;ProvidedPONumber\\&quot;&quot;) IsNot Nothing, CStr(currentTask(\\&quot;&quot;ProvidedPONumber\\&quot;&quot;)), \\&quot;&quot;\\&quot;&quot;)&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expression&quot;&quot;,&quot;&quot;value&quot;&quot;:&quot;&quot;If(currentTask(\\&quot;&quot;ProvidedPONumber\\&quot;&quot;) IsNot Nothing, CStr(currentTask(\\&quot;&quot;ProvidedPONumber\\&quot;&quot;)), \\&quot;&quot;\\&quot;&quot;)&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;vb_expressi",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;providedInvoiceAmount&quot;&quot;}&quot;",
      "resolvedValue": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&quot;&quot;,&quot;&quot;name&quot;&quot;:&quot;&quot;providedInvoiceAmount&quot;&quot;}&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;__STRUCTURED_OBJECT__{&quot;&quot;type&quot;&quot;:&quot;&quot;variable&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ActionCenterCallbackHandler ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ActionCenterCallbackHandler ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ActionCenterCallbackHandler ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization: Invoice Submitted in Coupa&quot;]",
      "resolvedValue": "[&quot;Initialization: Invoice Submitted in Coupa&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization: Invoice Submitted in Coupa&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Ingest New Invoice Event&quot;",
      "resolvedValue": "&quot;Executing: Ingest New Invoice Event&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Ingest New Invoice Event&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Get Invoice Header Data (PO, amount, supplier)&quot;",
      "resolvedValue": "&quot;Executing: Get Invoice Header Data (PO, amount, supplier)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Get Invoice Header Data (PO, amount, supplier)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Validate PO Exists in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;TODO: Set form schema path&quot;",
      "resolvedValue": "&quot;TODO: Set form schema path&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;TODO: Set form schema path&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Validate PO Exists in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;TODO: Set form schema path&quot;",
      "resolvedValue": "&quot;TODO: Set form schema path&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;TODO: Set form schema path&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Route to AP Exception Review (missing data) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Route to AP Exception Review (missing data) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Route to AP Exception Review (missing data) failed (&quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then branch: AP Provides Missing Data / Confirms Rejection&quot;]",
      "resolvedValue": "[&quot;Then branch: AP Provides Missing Data / Confirms Rejection&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then branch: AP Provides Missing Data / Confirms Rejection&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Update Invoice Data in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Update Invoice Data in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "resolvedValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "resolvedValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "resolvedValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "resolvedValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Invoice Progressed to Next Stage End&quot;",
      "resolvedValue": "&quot;Executing: Invoice Progressed to Next Stage End&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Invoice Progressed to Next Stage End&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Coupa Sends Rejection Notification to Supplier&quot;",
      "resolvedValue": "&quot;Executing: Coupa Sends Rejection Notification to Supplier&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Coupa Sends Rejection Notification to Supplier&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
      "resolvedValue": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Invoice Rejected End&quot;]",
      "resolvedValue": "[&quot;Completed: Invoice Rejected End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Invoice Rejected End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Coupa_IRV2_Credentials&quot;]",
      "resolvedValue": "[&quot;Coupa_IRV2_Credentials&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Coupa_IRV2_Credentials&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_Credentials&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_Credentials&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_Credentials&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_TempUser]",
      "resolvedValue": "[str_TempUser]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempUser",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_BaseUrl&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_BaseUrl&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_BaseUrl&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_TolerancePercent&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_TolerancePercent&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_TolerancePercent&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_POMismatch&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_POMismatch&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_RejectComment_POMismatch&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_OutOfTolerance&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_OutOfTolerance&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_RejectComment_OutOfTolerance&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_InsufficientData&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_InsufficientData&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_RejectComment_InsufficientData&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_MaxTransactionSeconds&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_MaxTransactionSeconds&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_MaxTransactionSeconds&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_MaxConsecutiveSystemFailures&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_MaxConsecutiveSystemFailures&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_MaxConsecutiveSystemFailures&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_EnableEvidenceSnapshots&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_EnableEvidenceSnapshots&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_EnableEvidenceSnapshots&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[out_TransactionItem IsNot Nothing]",
      "resolvedValue": "[out_TransactionItem IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[out_TransactionItem IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_TransactionNumber",
        "sourceWorkflow": "GetTransactionData",
        "precedenceTier": 1
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber + 1]",
      "resolvedValue": "[io_TransactionNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "resolvedValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;No more transactions in queue&quot;]",
      "resolvedValue": "[&quot;No more transactions in queue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;No more transactions in queue&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetTransactionData ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_Status = &quot;Successful&quot;]",
      "resolvedValue": "[in_Status = &quot;Successful&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_Status = &quot;Successful&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "resolvedValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "resolvedValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Closing all applications...&quot;]",
      "resolvedValue": "[&quot;Closing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Closing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications closed&quot;]",
      "resolvedValue": "[&quot;All applications closed&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications closed&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "resolvedValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "KillAllProcesses.xaml",
      "resolvedValue": "KillAllProcesses.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "KillAllProcesses.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "resolvedValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Force killing all application processes...&quot;]",
      "resolvedValue": "[&quot;Force killing all application processes...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Force killing all application processes...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;chrome&quot;]",
      "resolvedValue": "[&quot;chrome&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;chrome&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;iexplore&quot;]",
      "resolvedValue": "[&quot;iexplore&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;iexplore&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;EXCEL&quot;]",
      "resolvedValue": "[&quot;EXCEL&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;EXCEL&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All processes terminated&quot;]",
      "resolvedValue": "[&quot;All processes terminated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All processes terminated&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Started ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Started ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Started ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_Config]",
      "resolvedValue": "[io_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 1
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Complete ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Complete ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Complete ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "While",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on While has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "failureReason": "Required property \"WorkflowFileName\" on InvokeWorkflowFile has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Performer.xaml",
      "workflow": "Performer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "failureReason": "Required property \"EntityType\" on QueryEntity has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityType",
      "failureReason": "Required property \"EntityType\" on CreateEntityRecord has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "failureReason": "Required property \"WorkflowFileName\" on InvokeWorkflowFile has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "workflow": "InvoiceProcessor",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CoupaInteractionHelper.xaml",
      "workflow": "CoupaInteractionHelper",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "failureReason": "Required property \"EntityType\" on QueryEntity has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "GetEntityById",
      "propertyName": "EntityType",
      "failureReason": "Required property \"EntityType\" on GetEntityById has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "304 required property binding(s) resolved; 45 unresolved required property defect(s); 20 invalid generic substitution(s) blocked",
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "e076f40ed728feed70ffd78385b3190c7bb1e512e1510b11cdd7a0d38c39ba60",
      "canonicalizedHash": "50d9ebd20ff32ba68645220fd755dd5ed161733a340cde5c1c677446d924597d",
      "archivedHash": "50d9ebd20ff32ba68645220fd755dd5ed161733a340cde5c1c677446d924597d",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Dispatcher.xaml",
      "preCanonicalizationHash": "4b65cab9ba31553d3de89a04a1542e7715246cd7a478d4d9a81198421720220c",
      "canonicalizedHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "archivedHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Performer.xaml",
      "preCanonicalizationHash": "00fe0cfd65d94e97f99399c86089b10b2b0e84be17388031cda54a710b5a11c0",
      "canonicalizedHash": "d1312fb07e9295619279042d5904452770d533bc134b258910e98ad9e759ebaa",
      "archivedHash": "d1312fb07e9295619279042d5904452770d533bc134b258910e98ad9e759ebaa",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InvoiceProcessor.xaml",
      "preCanonicalizationHash": "aa98fbd1fac804239ae1198661de189654426db93d2cf32f77c47deb6c1433b1",
      "canonicalizedHash": "79564a2924ae12e6b1b8006c9f662f8b64ea760479c4637b4bbb1aad226d4fd3",
      "archivedHash": "79564a2924ae12e6b1b8006c9f662f8b64ea760479c4637b4bbb1aad226d4fd3",
      "identical": true,
      "mutated": true
    },
    {
      "file": "CoupaInteractionHelper.xaml",
      "preCanonicalizationHash": "50534e61fdd4256a1a22cdc533008ed6f3e5a8e4900b2f93f88a67ef49977877",
      "canonicalizedHash": "8a71d438e668a455f93028872253264d165bcdf4df72ba640787809905a4187c",
      "archivedHash": "8a71d438e668a455f93028872253264d165bcdf4df72ba640787809905a4187c",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "preCanonicalizationHash": "0894b2db4d38fc10a345feed415409bb470704704d93ca99580e59d6ed8665ad",
      "canonicalizedHash": "93f7920cf7671af8a8332bfe2cdfc64d556397fc4b4a89ce25e8fa6a4884b16c",
      "archivedHash": "93f7920cf7671af8a8332bfe2cdfc64d556397fc4b4a89ce25e8fa6a4884b16c",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Process.xaml",
      "preCanonicalizationHash": "6d2dc9f76314cf8efc35c6dc4daa19383e8e8d6fc5b7ed4cfe8ee37ce31f199f",
      "canonicalizedHash": "3963ec684036c3e5cb9a8ddac14c1b2a0b90eb3ffe89f02a0871f483bcf32bbd",
      "archivedHash": "3963ec684036c3e5cb9a8ddac14c1b2a0b90eb3ffe89f02a0871f483bcf32bbd",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
      "canonicalizedHash": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
      "archivedHash": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
      "identical": true,
      "mutated": false
    },
    {
      "file": "GetTransactionData.xaml",
      "preCanonicalizationHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "canonicalizedHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "archivedHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "identical": true,
      "mutated": false
    },
    {
      "file": "SetTransactionStatus.xaml",
      "preCanonicalizationHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "canonicalizedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "archivedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "identical": true,
      "mutated": false
    },
    {
      "file": "CloseAllApplications.xaml",
      "preCanonicalizationHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "canonicalizedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "archivedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "identical": true,
      "mutated": false
    },
    {
      "file": "KillAllProcesses.xaml",
      "preCanonicalizationHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "canonicalizedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "archivedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Init.xaml",
      "preCanonicalizationHash": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "canonicalizedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "archivedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "identical": true,
      "mutated": true
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "Performer.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"shouldStopPro"
    },
    {
      "file": "InvoiceProcessor.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">\"__STRUCTURED_OBJECT__{\"\"type\"\":\"\"variable\"\",\"\"name\"\":\"\"toleranceAsse"
    },
    {
      "file": "InitAllSettings.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: AssetName=\"[&quot;Coupa_IRV2_Credentials&quot;]"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ActionCenterCallbackHandler.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "93f7920cf7671af8a8332bfe2cdfc64d556397fc4b4a89ce25e8fa6a4884b16c",
        "allowed": true,
        "reason": "Workflow \"ActionCenterCallbackHandler.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CoupaInteractionHelper.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8a71d438e668a455f93028872253264d165bcdf4df72ba640787809905a4187c",
        "allowed": true,
        "reason": "Workflow \"CoupaInteractionHelper.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Dispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
        "allowed": true,
        "reason": "Workflow \"Dispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InvoiceProcessor.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "79564a2924ae12e6b1b8006c9f662f8b64ea760479c4637b4bbb1aad226d4fd3",
        "allowed": true,
        "reason": "Workflow \"InvoiceProcessor.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "50d9ebd20ff32ba68645220fd755dd5ed161733a340cde5c1c677446d924597d",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Performer.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d1312fb07e9295619279042d5904452770d533bc134b258910e98ad9e759ebaa",
        "allowed": true,
        "reason": "Workflow \"Performer.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3963ec684036c3e5cb9a8ddac14c1b2a0b90eb3ffe89f02a0871f483bcf32bbd",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "ActionCenterCallbackHandler.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "CoupaInteractionHelper.xaml": 1,
      "Dispatcher.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InvoiceProcessor.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Performer.xaml": 1,
      "Process.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 13,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 13,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ActionCenterCallbackHandler.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "93f7920cf7671af8a8332bfe2cdfc64d556397fc4b4a89ce25e8fa6a4884b16c",
        "allowed": true,
        "reason": "Workflow \"ActionCenterCallbackHandler.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CoupaInteractionHelper.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8a71d438e668a455f93028872253264d165bcdf4df72ba640787809905a4187c",
        "allowed": true,
        "reason": "Workflow \"CoupaInteractionHelper.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Dispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
        "allowed": true,
        "reason": "Workflow \"Dispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a7d5f50a5bc7ba476127365094347732c244c1b520fe0b4dd1a0be408479a84e",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InvoiceProcessor.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "79564a2924ae12e6b1b8006c9f662f8b64ea760479c4637b4bbb1aad226d4fd3",
        "allowed": true,
        "reason": "Workflow \"InvoiceProcessor.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "50d9ebd20ff32ba68645220fd755dd5ed161733a340cde5c1c677446d924597d",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Performer.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d1312fb07e9295619279042d5904452770d533bc134b258910e98ad9e759ebaa",
        "allowed": true,
        "reason": "Workflow \"Performer.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3963ec684036c3e5cb9a8ddac14c1b2a0b90eb3ffe89f02a0871f483bcf32bbd",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "ActionCenterCallbackHandler.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "CoupaInteractionHelper.xaml": 1,
      "Dispatcher.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InvoiceProcessor.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Performer.xaml": 1,
      "Process.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 13,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 13,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "workflowAutoWiringDiagnostics": {
    "entries": [
      {
        "file": "Main.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Main",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": null,
        "callerCandidates": [],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Dispatcher.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Dispatcher",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Performer.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Performer",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InvoiceProcessor.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:InvoiceProcessor",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CoupaInteractionHelper.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:CoupaInteractionHelper",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ActionCenterCallbackHandler.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:ActionCenterCallbackHandler",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Process.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Process",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllSettings.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:initallsettings",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Init.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "GetTransactionData.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:GetTransactionData",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "SetTransactionStatus.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:SetTransactionStatus",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CloseAllApplications.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:closeallapplications",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "KillAllProcesses.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:killallprocesses",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "CloseAllApplications.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Init.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Init",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      }
    ],
    "summary": {
      "totalGeneratedWorkflows": 6,
      "totalRequiredWorkflows": 9,
      "totalRequiredWorkflowsWired": 9,
      "totalGeneratedButUnwired": 0,
      "totalUnreachableFromMain": 0,
      "totalMissingInvokeEdges": 0,
      "totalCallerMismatchDefects": 1,
      "totalInvokeEmissionFailures": 0
    },
    "activePathProof": {
      "reachabilityComputedOnFinalizedSet": true,
      "reachabilityPruningSkipped": true,
      "wiringComputedOnFinalizedSet": true,
      "workflowSetHashAtWiringTime": "2ca457132755eb50",
      "workflowSetHashAtReachabilityTime": "2ca457132755eb50",
      "consistent": true
    }
  },
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 670,
        "approved": 670,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 8728,
        "approved": 4568,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 4160
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 12995,
        "approved": 8795,
        "deprecated": 0,
        "nonEmissionApproved": 2640,
        "targetIncompatible": 0,
        "unknown": 1560
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 470,
        "approved": 408,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 62
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 12,
        "approved": 12,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
