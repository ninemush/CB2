# Developer Handoff Guide

**Project:** CoupaInvoiceReconciliation
**Generated:** 2026-04-07
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Not Ready (39%)

**15 workflows: 12 fully generated, 0 with handoff blocks, 2 workflow-level stubs, 1 Studio-blocked**
**Total Estimated Effort: ~100 minutes (1.7 hours)**
**Remediations:** 8 total (0 property, 1 activity, 0 sequence, 0 structural-leaf, 2 workflow)
**Auto-Repairs:** 11
**Quality Warnings:** 79

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `InvoiceDispatcher.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 2 | `PerformerMain.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 3 | `ProcessTransaction.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 4 | `InvoiceExtractionAndValidation.xaml` | Blocked | 1 | 0 | 1 | 1 | 0 |
| 5 | `CreateHumanValidationTask.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 6 | `PurchaseOrderValidation.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 7 | `RouteOrRejectInCoupa.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 8 | `Process.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 9 | `InitAllSettings.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 10 | `Main.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 11 | `GetTransactionData.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 12 | `SetTransactionStatus.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 13 | `CloseAllApplications.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 14 | `KillAllProcesses.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 15 | `Init.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 12 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `InvoiceDispatcher.xaml` | Fully Generated | Studio-openable |
| 2 | `PerformerMain.xaml` | Fully Generated | Studio-openable |
| 3 | `ProcessTransaction.xaml` | Generated with Placeholders | Studio-openable |
| 4 | `PurchaseOrderValidation.xaml` | Generated with Placeholders | Studio-openable |
| 5 | `RouteOrRejectInCoupa.xaml` | Fully Generated | Studio-openable |
| 6 | `Process.xaml` | Generated with Placeholders | Openable with warnings |
| 7 | `Main.xaml` | Fully Generated | Studio-openable |
| 8 | `GetTransactionData.xaml` | Fully Generated | Studio-openable |
| 9 | `SetTransactionStatus.xaml` | Fully Generated | Studio-openable |
| 10 | `CloseAllApplications.xaml` | Fully Generated | Studio-openable |
| 11 | `KillAllProcesses.xaml` | Fully Generated | Studio-openable |
| 12 | `Init.xaml` | Fully Generated | Studio-openable |

### AI-Resolved with Smart Defaults (11)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_PLACEHOLDER_CLEANUP` | `Process.xaml` | Stripped 5 placeholder token(s) from Process.xaml | 5 |
| 2 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.... | undefined |
| 3 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.... | undefined |
| 4 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.... | undefined |
| 5 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.... | undefined |
| 6 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.... | undefined |
| 7 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved uweb:HttpClientRequest.EndPoint from attribute to child-element in Invo... | undefined |
| 8 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved uweb:DeserializeJson.JsonString from attribute to child-element in Invo... | undefined |
| 9 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved uweb:DeserializeJson.JsonObject from attribute to child-element in Invo... | undefined |
| 10 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved ForEach.Values from attribute to child-element in InvoiceDispatcher.xaml | undefined |
| 11 | `REPAIR_GENERIC` | `InvoiceDispatcher.xaml` | Catalog (fallback): Moved uds:QueryEntity.Result from attribute to child-element in InvoiceDispat... | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `InvoiceDispatcher.xaml` | Studio-openable | — | — |
| 2 | `PerformerMain.xaml` | Studio-openable | — | — |
| 3 | `ProcessTransaction.xaml` | Studio-openable | — | — |
| 4 | `InvoiceExtractionAndValidation.xaml` | Structurally invalid — not Studio-loadable | Unclassified | [EXPRESSION_SYNTAX_UNFIXABLE] Line 90: Expression contains CDbl(InConfidenceT... |
| 5 | `CreateHumanValidationTask.xaml` | Studio-openable | — | — |
| 6 | `PurchaseOrderValidation.xaml` | Studio-openable | — | — |
| 7 | `RouteOrRejectInCoupa.xaml` | Studio-openable | — | — |
| 8 | `Process.xaml` | Openable with warnings | Unclassified | — |
| 9 | `InitAllSettings.xaml` | Studio-openable | — | — |
| 10 | `Main.xaml` | Studio-openable | — | — |
| 11 | `GetTransactionData.xaml` | Studio-openable | — | — |
| 12 | `SetTransactionStatus.xaml` | Studio-openable | — | — |
| 13 | `CloseAllApplications.xaml` | Studio-openable | — | — |
| 14 | `KillAllProcesses.xaml` | Studio-openable | — | — |
| 15 | `Init.xaml` | Studio-openable | — | — |

**Summary:** 13 Studio-loadable, 1 with warnings, 1 not Studio-loadable

> **⚠ 1 workflow(s) are not Studio-loadable** — they will fail to open in UiPath Studio. Address the blockers listed above before importing.

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**1 handoff block(s) requiring manual implementation**

#### 1. `InvoiceExtractionAndValidation.xaml` — — (activity)

- **Workflow File:** `InvoiceExtractionAndValidation.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "value" in InvoiceExtractionAndValidation.xaml with the appropriate type. Expression context: value
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**87 items remaining — ~890 minutes (14.8 hours) total estimated effort**

### CreateHumanValidationTask.xaml (4 items, ~40 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `CreateHumanValidationTask.xaml` replaced with Studio-openabl... | Resolve object_payload_in_target_value_slot in CreateHumanValidationTask.xaml | 10 |
| 2 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 3 | Low | Quality Warning | hardcoded-asset-name: Line 73: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 4 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 111: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### InitAllSettings.xaml (14 items, ~140 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 5 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in InitAllSettings.xaml | 10 |
| 6 | Low | Quality Warning | hardcoded-asset-name: Line 100: asset name "Cred_Coupa_API" is hardcoded — co... | Review and address | 10 |
| 7 | Low | Quality Warning | hardcoded-asset-name: Line 105: asset name "Coupa.BaseUrl" is hardcoded — con... | Review and address | 10 |
| 8 | Low | Quality Warning | hardcoded-asset-name: Line 114: asset name "Coupa.Polling.Enabled" is hardcod... | Review and address | 10 |
| 9 | Low | Quality Warning | hardcoded-asset-name: Line 123: asset name "Coupa.Polling.LookbackMinutes" is... | Review and address | 10 |
| 10 | Low | Quality Warning | hardcoded-asset-name: Line 132: asset name "Business.TolerancePercent" is har... | Review and address | 10 |
| 11 | Low | Quality Warning | hardcoded-asset-name: Line 141: asset name "Business.ToleranceBasis" is hardc... | Review and address | 10 |
| 12 | Low | Quality Warning | hardcoded-asset-name: Line 150: asset name "DU.ConfidenceThreshold" is hardco... | Review and address | 10 |
| 13 | Low | Quality Warning | hardcoded-asset-name: Line 159: asset name "ActionCenter.SLAHours" is hardcod... | Review and address | 10 |
| 14 | Low | Quality Warning | hardcoded-asset-name: Line 168: asset name "Storage.RetentionDays" is hardcod... | Review and address | 10 |
| 15 | Low | Quality Warning | hardcoded-asset-name: Line 177: asset name "Orchestrator.FolderName" is hardc... | Review and address | 10 |
| 16 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 17 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 18 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Cred_Coupa_API" for ui:GetCredenti... | Review and address | 10 |

### InvoiceExtractionAndValidation.xaml (18 items, ~195 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 19 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "value" in InvoiceExtractionAndValidation.xaml with the appr... | 5 |
| 20 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in InvoiceExtractionAndValidation.xaml — estimate... | 15 |
| 21 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in InvoiceExtractionAndValidation.xaml — estimate... | 15 |
| 22 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in InvoiceExtractionAndValidation.xaml — estimate... | 15 |
| 23 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InvoiceExtractionAndValidation.xaml — estimate... | 15 |
| 24 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 25 | Low | Quality Warning | hardcoded-retry-count: Line 141: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 26 | Low | Quality Warning | hardcoded-retry-count: Line 185: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 27 | Low | Quality Warning | hardcoded-retry-interval: Line 141: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 28 | Low | Quality Warning | hardcoded-retry-interval: Line 185: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 29 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 484: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 30 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 526: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 31 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 568: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 32 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 610: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 33 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 652: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 34 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 709: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 35 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 36 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### Process.xaml (5 items, ~50 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 37 | Low | Implementation Required | Contains 3 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 38 | Low | Quality Warning | invalid-type-argument: Line 61: x:TypeArguments="UiPath.Persistence.Activitie... | Review and address | 10 |
| 39 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 81: Standalone "No" corrected to "False" in expressio... | Review and address | 10 |
| 40 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 182: Standalone "No" corrected to "False" in expressi... | Review and address | 10 |
| 41 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 198: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |

### ProcessTransaction.xaml (4 items, ~40 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 42 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 43 | Low | Quality Warning | hardcoded-retry-count: Line 176: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 44 | Low | Quality Warning | hardcoded-retry-interval: Line 176: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 45 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### PurchaseOrderValidation.xaml (5 items, ~55 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 46 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in PurchaseOrderValidation.xaml — estimated 15 min | 15 |
| 47 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 48 | Low | Quality Warning | unassigned-decision-variable: Line 232: variable "poStatusCode" is used in If... | Review and address | 10 |
| 49 | Low | Quality Warning | hardcoded-asset-name: Line 95: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 50 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 133: Unbalanced parentheses: 1 open vs 2 close — remo... | Review and address | 10 |

### InvoiceDispatcher.xaml (9 items, ~90 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 51 | Low | Quality Warning | hardcoded-retry-count: Line 302: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 52 | Low | Quality Warning | hardcoded-retry-interval: Line 302: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 53 | Low | Quality Warning | hardcoded-asset-name: Line 78: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 54 | Low | Quality Warning | hardcoded-asset-name: Line 117: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 55 | Low | Quality Warning | hardcoded-asset-name: Line 156: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 56 | Low | Quality Warning | hardcoded-asset-name: Line 199: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 57 | Low | Quality Warning | hardcoded-asset-name: Line 251: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 58 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 235: C# 'true' should be VB.NET 'True' in expression:... | Review and address | 10 |
| 59 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### KillAllProcesses.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 60 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "chrome" for ui:KillProcess.Process... | Review and address | 10 |
| 61 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "iexplore" for ui:KillProcess.Proce... | Review and address | 10 |
| 62 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "EXCEL" for ui:KillProcess.ProcessN... | Review and address | 10 |

### orchestrator.xaml (11 items, ~110 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 63 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Coupa.BaseUrl}" is referenced in... | Review and address | 10 |
| 64 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Coupa.Polling.Enabled}" is refer... | Review and address | 10 |
| 65 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Coupa.Polling.LookbackMinutes}" ... | Review and address | 10 |
| 66 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Orchestrator.FolderName}" is ref... | Review and address | 10 |
| 67 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:CoupaInvoiceRecon_LastRunUtc}" i... | Review and address | 10 |
| 68 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Business.ToleranceBasis}" is ref... | Review and address | 10 |
| 69 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Business.TolerancePercent}" is r... | Review and address | 10 |
| 70 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:DU.ConfidenceThreshold}" is refe... | Review and address | 10 |
| 71 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:ActionCenter.SLAHours}" is refer... | Review and address | 10 |
| 72 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Storage.RetentionDays}" is refer... | Review and address | 10 |
| 73 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Cred_Coupa_API}" is referenced i... | Review and address | 10 |

### PerformerMain.xaml (7 items, ~70 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 74 | Low | Quality Warning | hardcoded-asset-name: Line 73: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 75 | Low | Quality Warning | hardcoded-asset-name: Line 113: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 76 | Low | Quality Warning | hardcoded-asset-name: Line 152: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 77 | Low | Quality Warning | hardcoded-asset-name: Line 191: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 78 | Low | Quality Warning | hardcoded-asset-name: Line 230: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 79 | Low | Quality Warning | hardcoded-asset-name: Line 269: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 80 | Low | Quality Warning | hardcoded-asset-name: Line 308: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |

### RouteOrRejectInCoupa.xaml (7 items, ~70 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 81 | Low | Quality Warning | hardcoded-credential: Potential hardcoded credential detected (pattern: passw... | Review and address | 10 |
| 82 | Low | Quality Warning | unassigned-decision-variable: Line 303: variable "httpStatusCode" is used in ... | Review and address | 10 |
| 83 | Low | Quality Warning | hardcoded-retry-interval: Line 183: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 84 | Low | Quality Warning | hardcoded-asset-name: Line 75: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 85 | Low | Quality Warning | hardcoded-asset-name: Line 114: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 86 | Low | Quality Warning | hardcoded-asset-name: Line 319: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 87 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 441: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Test recon

### PDD Summary

## 1. Executive Summary
This Process Design Document (PDD) defines the current (“As‑Is”) and future (“To‑Be”) process for Purchase Order (PO) and invoice reconciliation in Coupa. Today, vendors submit invoices as PDFs directly in Coupa. An AP Clerk manually opens each invoice, checks that the PO number matches the Coupa PO, verifies the invoice amount is within a 5% tolerance, and then routes compliant invoices into Coupa’s Delegation of Authority (DOA) approval chain. Invoices that fail validation are rejected in Coupa; the vendor corrects and resubmits, which is treated as a new invoice submission. The process runs at approximately 50 invoices per day and currently takes around 10 minutes per invoice, creating a high daily manual workload.

The proposed To‑Be design implements an unattended, fully autonomous workflow using UiPath Orchestrator triggers, Integration Service connectivity to Coupa, and Document Understanding to extract invoice fields from PDFs. The automation validates PO existence/match and applies the 5% tolerance rule. When extraction confidence is insufficient, the invoice is routed to Action Center for human validation and then resumes automated processing. Successful invoices are routed into the Coupa DOA approval chain; failed invoices are rejected in Coupa with standardized rejection reasons. The automation ends when the invoice is either rejected or progressed to the next stage, consistent with the defined scope.

## 2. Process Scope
The scope of this PDD begins when a vendor submits an invoice (PDF) into Coupa and ends when the invoice is either (a) rejected in Coupa due to PO mismatch/not found, out‑of‑tolerance amount, or DOA rejection, or (b) routed for and approved through Coupa’s DOA chain and thereby progressed to the next stage.

In scope are: retrieval of invoice PDF and invoice metadata from Coupa; extraction of key fields (PO number, invoice number, vendor, invoice amount) from the submitted PDF; validation that the PO exists and m...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Automation pattern:** **Queue-driven dispatcher–performer (unattended) + human-in-the-loop validation**  
- **RPA (unattended)** is the primary execution model because the process is deterministic (PO match + 5% tolerance + route/reject) and volume is stable (~50/day).  
- **Hybrid** is required due to PDF variability: when Document Understanding confidence is low, a person must confirm fields. This is implemented with **Action Center** (not attended robots) because **only unattended robots (11 slots)** exist and interactive desktop automation is not permitted.  
- **Agents** are **not** used on the critical path (capability detected with limited certainty). They may be used later for analytics/explanations, but the core reconciliation must remain deterministic, auditable, and operable without agent runtime dependencies.

**Why Orchestrator Queues vs Data Service for work dispatch?**  
- Use **Orchestrator Queues** to represent “invoice to be processed” items because they provide built-in **retry, transaction states, SLA visibility, and queue triggers**—the right fit for reliable background throughput and idempotent processing.  
- Use **Data Service** for **case persistence** (invoice run history, extracted/validated fields, decisions, timestamps) and to bind to **Action Center** tasks and reporting.

**Why Integration Service vs custom HTTP to Coupa?**  
- Policy requirement: must use Integration Service connectors. This also reduces maintenance (auth refresh, pagination helpers), improves observability, and centralizes credentials.

**Why Triggers vs Maestro?**  
- For this scope (single intake → validation → route/reject with one optional human validation), **Orchestrator Triggers + Queue triggers** are simpler and more operable than standing up a full BPMN case model in Maestro.  
- Maestro is retained as a future recommendation if the process expands into multi-stage excepti...

**Automation Type:** rpa
**Rationale:** The inputs are structured (Coupa invoice + PO fields) and the decisions are deterministic (PO match, 5% tolerance, DOA workflow), making this a high-volume, rules-based unattended RPA use case with optional human-in-loop only for low-confidence extraction.
**Feasibility Complexity:** medium
**Effort Estimate:** 2-4 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | Invoice Submitted in Coupa Triggers Automation | System | Orchestrator Trigger | start | — |
| 2 | Retrieve Invoice PDF + Metadata from Coupa | System | Coupa (via Integration Service connector) | task | — |
| 3 | Extract Invoice Fields from PDF (PO#, Invoice#, Amount, Vendor) | System | Document Understanding (Invoice taxonomy) | task | — |
| 4 | Extraction Confidence OK? | System | Document Understanding | decision | — |
| 5 | Send to Human Validation | AP Clerk | Action Center | task | — |
| 6 | Apply Validated Fields | System | Action Center | task | — |
| 7 | Get PO Details from Coupa for Extracted PO# | System | Coupa (via Integration Service connector) | task | — |
| 8 | Get PO Details from Coupa for Validated PO# | System | Coupa (via Integration Service connector) | task | — |
| 9 | PO Found and Matches Invoice PO? | System | Coupa | decision | — |
| 10 | Reject Invoice in Coupa (PO Mismatch/Not Found) | System | Coupa (via Integration Service connector) | task | — |
| 11 | Amount Within 5% Tolerance? | System | Business Rules | decision | — |
| 12 | Route Invoice for DOA Approval in Coupa | System | Coupa (via Integration Service connector) | task | — |
| 13 | Reject Invoice in Coupa (Out of Tolerance) | System | Coupa (via Integration Service connector) | task | — |
| 14 | Invoice Progressed to Next Stage End | System | Coupa | end | — |
| 15 | Invoice Rejected End | System | Coupa | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Trigger
- Coupa (via Integration Service connector)
- Document Understanding (Invoice taxonomy)
- Document Understanding
- Action Center
- Coupa
- Business Rules

### User Roles Involved

- System
- AP Clerk

### Decision Points (Process Map Topology)

**Extraction Confidence OK?**
  - [No] → Send to Human Validation
  - [Yes] → Get PO Details from Coupa for Extracted PO#

**PO Found and Matches Invoice PO?**
  - [No] → Reject Invoice in Coupa (PO Mismatch/Not Found)
  - [Yes] → Amount Within 5% Tolerance?

**Amount Within 5% Tolerance?**
  - [Yes] → Route Invoice for DOA Approval in Coupa
  - [No] → Reject Invoice in Coupa (Out of Tolerance)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Server |
| Action Center | Required |
| Document Understanding | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Server
Server machine recommended for AI/DU workloads — allocate GPU resources if using local ML models

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.WebAPI.Activities` |
| 3 | `UiPath.DataService.Activities` |
| 4 | `Newtonsoft.Json` |
| 5 | `UiPath.UIAutomation.Activities` |
| 6 | `UiPath.Persistence.Activities` |
| 7 | `UiPath.ComplexScenarios.Activities` |
| 8 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Trigger
- Coupa (via Integration Service connector)
- Document Understanding (Invoice taxonomy)
- Document Understanding
- Action Center
- Coupa
- Business Rules

## 7. Credential & Asset Inventory

**Total:** 36 activities (23 hardcoded, 13 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `[` | Credential | — | `RouteOrRejectInCoupa.xaml` | Verify exists in target environment |
| 2 | `[Cred_Coupa_API]` | Credential | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `Coupa.BaseUrl` | Unknown | — | `InvoiceDispatcher.xaml` | Create in Orchestrator before deployment |
| 2 | `Coupa.Polling.Enabled` | Unknown | — | `InvoiceDispatcher.xaml` | Create in Orchestrator before deployment |
| 3 | `Coupa.Polling.LookbackMinutes` | Unknown | — | `InvoiceDispatcher.xaml` | Create in Orchestrator before deployment |
| 4 | `Orchestrator.FolderName` | Unknown | — | `InvoiceDispatcher.xaml` | Create in Orchestrator before deployment |
| 5 | `[` | Unknown | — | `InvoiceDispatcher.xaml` | Verify exists in target environment |
| 6 | `Business.ToleranceBasis` | Unknown | — | `PerformerMain.xaml` | Create in Orchestrator before deployment |
| 7 | `Business.TolerancePercent` | Unknown | — | `PerformerMain.xaml` | Create in Orchestrator before deployment |
| 8 | `DU.ConfidenceThreshold` | Unknown | — | `PerformerMain.xaml` | Create in Orchestrator before deployment |
| 9 | `ActionCenter.SLAHours` | Unknown | — | `PerformerMain.xaml` | Create in Orchestrator before deployment |
| 10 | `Storage.RetentionDays` | Unknown | — | `PerformerMain.xaml` | Create in Orchestrator before deployment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `InvoiceDispatcher.xaml` | 78 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `InvoiceDispatcher.xaml` | 117 | GetAsset | `Coupa.Polling.Enabled` | Unknown | — | Yes |
| `InvoiceDispatcher.xaml` | 156 | GetAsset | `Coupa.Polling.LookbackMinutes` | Unknown | — | Yes |
| `InvoiceDispatcher.xaml` | 199 | GetAsset | `Orchestrator.FolderName` | Unknown | — | Yes |
| `InvoiceDispatcher.xaml` | 251 | GetAsset | `[` | Unknown | — | No |
| `PerformerMain.xaml` | 73 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `PerformerMain.xaml` | 113 | GetAsset | `Business.ToleranceBasis` | Unknown | — | Yes |
| `PerformerMain.xaml` | 152 | GetAsset | `Business.TolerancePercent` | Unknown | — | Yes |
| `PerformerMain.xaml` | 191 | GetAsset | `DU.ConfidenceThreshold` | Unknown | — | Yes |
| `PerformerMain.xaml` | 230 | GetAsset | `ActionCenter.SLAHours` | Unknown | — | Yes |
| `PerformerMain.xaml` | 269 | GetAsset | `Orchestrator.FolderName` | Unknown | — | Yes |
| `PerformerMain.xaml` | 308 | GetAsset | `Storage.RetentionDays` | Unknown | — | Yes |
| `CreateHumanValidationTask.xaml` | 73 | GetAsset | `ActionCenter.SLAHours` | Unknown | — | Yes |
| `PurchaseOrderValidation.xaml` | 95 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `RouteOrRejectInCoupa.xaml` | 75 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `RouteOrRejectInCoupa.xaml` | 114 | GetCredential | `[` | Credential | — | No |
| `RouteOrRejectInCoupa.xaml` | 319 | GetCredential | `[` | Credential | — | No |
| `InitAllSettings.xaml` | 100 | GetCredential | `[Cred_Coupa_API]` | Credential | — | No |
| `InitAllSettings.xaml` | 105 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 106 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 114 | GetAsset | `Coupa.Polling.Enabled` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 115 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 123 | GetAsset | `Coupa.Polling.LookbackMinutes` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 124 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 132 | GetAsset | `Business.TolerancePercent` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 133 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 141 | GetAsset | `Business.ToleranceBasis` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 142 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 150 | GetAsset | `DU.ConfidenceThreshold` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 151 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 159 | GetAsset | `ActionCenter.SLAHours` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 160 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 168 | GetAsset | `Storage.RetentionDays` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 169 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 177 | GetAsset | `Orchestrator.FolderName` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 178 | GetAsset | `UNKNOWN` | Unknown | — | No |

> **Warning:** 23 asset/credential name(s) are hardcoded. Consider externalizing to Orchestrator Config assets for environment portability.

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 10 aligned, 2 SDD-only, 5 XAML-only

> **Warning:** 2 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 5 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `Coupa.BaseUrl` | asset | **Aligned** | type: Text, value: https://<your-tenant>.coupahost.com, description: Coupa tenant base URL used by Integration Service/HTTP calls where needed. | `InvoiceDispatcher.xaml` | 78 |
| 2 | `Coupa.Polling.Enabled` | asset | **Aligned** | type: Bool, value: true, description: If event-based triggers are not feasible, enables scheduled polling for new invoices. | `InvoiceDispatcher.xaml` | 117 |
| 3 | `Coupa.Polling.LookbackMinutes` | asset | **Aligned** | type: Integer, value: 60, description: Polling lookback window (minutes) to capture any missed invoices. | `InvoiceDispatcher.xaml` | 156 |
| 4 | `Business.TolerancePercent` | asset | **Aligned** | type: Integer, value: 5, description: Tolerance percentage for invoice total vs PO basis amount. | `PerformerMain.xaml` | 152 |
| 5 | `Business.ToleranceBasis` | asset | **Aligned** | type: Text, value: PO_TOTAL, description: Defines tolerance comparison basis. Expected values: PO_TOTAL | PO_REMAINING | LINE_LEVEL (confirm and update per finalized policy). | `PerformerMain.xaml` | 113 |
| 6 | `DU.ConfidenceThreshold` | asset | **Aligned** | type: Integer, value: 85, description: Minimum confidence (0-100) required to proceed without human validation. | `PerformerMain.xaml` | 191 |
| 7 | `ActionCenter.SLAHours` | asset | **Aligned** | type: Integer, value: 24, description: SLA for human validation turnaround in Action Center. | `PerformerMain.xaml` | 230 |
| 8 | `Storage.RetentionDays` | asset | **Aligned** | type: Integer, value: 30, description: Retention for stored invoice PDFs and processing artifacts in Storage Buckets (align with AP compliance policy). | `PerformerMain.xaml` | 308 |
| 9 | `Orchestrator.FolderName` | asset | **Aligned** | type: Text, value: FIN_AP_InvoiceReconciliation_PRD, description: Target Orchestrator modern folder for production deployment and runtime isolation. | `InvoiceDispatcher.xaml` | 199 |
| 10 | `Cred_Coupa_API` | credential | **SDD Only** | type: Credential, description: Credential for Coupa API access if required by connector design (client id/secret, token, or service account). | — | — |
| 11 | `[` | asset | **XAML Only** | — | `InvoiceDispatcher.xaml` | 251 |
| 12 | `[` | credential | **XAML Only** | — | `InvoiceDispatcher.xaml` | 251 |
| 13 | `[Cred_Coupa_API]` | credential | **XAML Only** | — | `InitAllSettings.xaml` | 100 |
| 14 | `Q_Coupa_InvoiceReconciliation` | queue | **Aligned** | maxRetries: 2, uniqueReference: true, description: Primary work queue for Coupa invoice submissions to be processed end-to-end (DU extraction, PO validation, tolerance check, route or reject). Reference = Coupa Invoice ID. | `CreateHumanValidationTask.xaml` | 368 |
| 15 | `Q_Coupa_InvoiceReconciliation_Exceptions` | queue | **SDD Only** | maxRetries: 3, uniqueReference: true, description: Secondary queue for technical exceptions requiring automatic retry or support intervention (API errors, transient DU service failures). Reference = Coupa Invoice ID + Exception Category. | — | — |
| 16 | `[` | queue | **XAML Only** | — | `PerformerMain.xaml` | 357 |
| 17 | `[in_QueueName]` | queue | **XAML Only** | — | `GetTransactionData.xaml` | 62 |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### Queues to Provision

| # | Queue Name | Activities | Unique Reference | Auto Retry | SLA | Action |
|---|-----------|------------|-----------------|------------|-----|--------|
| 1 | `[` | GetTransactionItem | Recommended | Yes (3x) | — | Verify exists |
| 2 | `Q_Coupa_InvoiceReconciliation` | AddQueueItem | Yes (SDD) | Yes (2x, SDD) | — | Create in Orchestrator |
| 3 | `[in_QueueName]` | GetTransactionItem | Recommended | Yes (3x) | — | Verify exists |

### SDD-Defined Queues (Not Yet in XAML)

| # | Queue Name | Unique Reference | Max Retries | SLA | Note |
|---|-----------|-----------------|-------------|-----|------|
| 1 | `Q_Coupa_InvoiceReconciliation_Exceptions` | Yes | 3x | — | Defined in SDD but no matching XAML activity — verify implementation |

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | Yes |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

## 10. Exception Handling Coverage

**Coverage:** 28/51 high-risk activities inside TryCatch (55%)

### Files Without TryCatch

- `InitAllSettings.xaml`
- `GetTransactionData.xaml`
- `KillAllProcesses.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:100` | Get Cred_Coupa_API |
| 2 | `InitAllSettings.xaml:105` | Get Coupa.BaseUrl |
| 3 | `InitAllSettings.xaml:106` | ui:GetAsset |
| 4 | `InitAllSettings.xaml:114` | Get Coupa.Polling.Enabled |
| 5 | `InitAllSettings.xaml:115` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:123` | Get Coupa.Polling.LookbackMinutes |
| 7 | `InitAllSettings.xaml:124` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:132` | Get Business.TolerancePercent |
| 9 | `InitAllSettings.xaml:133` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:141` | Get Business.ToleranceBasis |
| 11 | `InitAllSettings.xaml:142` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:150` | Get DU.ConfidenceThreshold |
| 13 | `InitAllSettings.xaml:151` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:159` | Get ActionCenter.SLAHours |
| 15 | `InitAllSettings.xaml:160` | ui:GetAsset |
| 16 | `InitAllSettings.xaml:168` | Get Storage.RetentionDays |
| 17 | `InitAllSettings.xaml:169` | ui:GetAsset |
| 18 | `InitAllSettings.xaml:177` | Get Orchestrator.FolderName |
| 19 | `InitAllSettings.xaml:178` | ui:GetAsset |
| 20 | `GetTransactionData.xaml:62` | Get Queue Item |
| 21 | `GetTransactionData.xaml:63` | ui:GetTransactionItem |
| 22 | `SetTransactionStatus.xaml:67` | Set Success |
| 23 | `SetTransactionStatus.xaml:89` | Set Failed |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_CoupaInvoiceRecon_Dispatcher_Polling_5min | SDD-specified: TRG_CoupaInvoiceRecon_Dispatcher_Polling_5min | Cron: 0 */5 * ? * * * | Scheduled dispatcher trigger (polling mode) to detect new Coupa invoice submissions and enqueue items. Used when Coupa event/webhook trigger is not available. |
| 2 | **Queue** | Defined in SDD orchestrator_artifacts: TRG_CoupaInvoiceRecon_Performer_Queue | SDD-specified: TRG_CoupaInvoiceRecon_Performer_Queue | Queue: Q_Coupa_InvoiceReconciliation | Queue trigger to start performer processing when new invoice items arrive. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| hardcoded-credential | warning | 1 | Potential hardcoded credential detected (pattern: password\s*[:=]\s*["'](?!\[)[^...) |
| placeholder-value | warning | 5 | Contains 3 placeholder value(s) matching "\bTODO\b" [Developer Implementation Required] |
| unassigned-decision-variable | warning | 2 | Line 232: variable "poStatusCode" is used in If condition but is never assigned earlier in this workflow — decision gate... |
| undeclared-asset | warning | 11 | Asset "{type:literal,value:Coupa.BaseUrl}" is referenced in XAML but not declared in orchestrator artifacts |
| invalid-type-argument | warning | 1 | Line 61: x:TypeArguments="UiPath.Persistence.Activities.FormTask" may not be a valid .NET type |
| hardcoded-retry-count | warning | 4 | Line 302: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| hardcoded-retry-interval | warning | 5 | Line 302: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| hardcoded-asset-name | warning | 27 | Line 78: asset name "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}" is hardcoded — ... |
| EXPRESSION_SYNTAX | warning | 5 | Line 235: C# 'true' should be VB.NET 'True' in expression: {&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&qu... |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 8 | Line 484: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption i... |
| BARE_TOKEN_QUOTED | warning | 6 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |
| RETRY_INTERVAL_DEFAULTED | warning | 4 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `[` | Yes |
| 5 | Credentials | Provision credential: `[Cred_Coupa_API]` | Yes |
| 6 | Assets | Provision asset: `Coupa.BaseUrl` | Yes |
| 7 | Assets | Provision asset: `Coupa.Polling.Enabled` | Yes |
| 8 | Assets | Provision asset: `Coupa.Polling.LookbackMinutes` | Yes |
| 9 | Assets | Provision asset: `Orchestrator.FolderName` | Yes |
| 10 | Assets | Provision asset: `[` | Yes |
| 11 | Assets | Provision asset: `Business.ToleranceBasis` | Yes |
| 12 | Assets | Provision asset: `Business.TolerancePercent` | Yes |
| 13 | Assets | Provision asset: `DU.ConfidenceThreshold` | Yes |
| 14 | Assets | Provision asset: `ActionCenter.SLAHours` | Yes |
| 15 | Assets | Provision asset: `Storage.RetentionDays` | Yes |
| 16 | Queues | Create queue: `[` | Yes |
| 17 | Queues | Create queue: `Q_Coupa_InvoiceReconciliation` | Yes |
| 18 | Queues | Create queue: `[in_QueueName]` | Yes |
| 19 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 20 | Testing | Run smoke test in target environment | Yes |
| 21 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 22 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 23 | Governance | Peer code review completed | Yes |
| 24 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 25 | Governance | Business process owner validation obtained | Yes |
| 26 | Governance | CoE approval obtained | Yes |
| 27 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Not Ready — 28/50 (39%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 5/10 | 23 hardcoded asset name(s) — use Orchestrator assets/config |
| Exception Handling | 4/10 | 55% coverage — consider wrapping remaining activities; 3 file(s) with no TryCatch blocks |
| Queue Management | 9/10 | 1 hardcoded queue name(s) — externalize to config |
| Build Quality | 0/10 | 79 quality warnings — significant remediation needed; 8 remediations — stub replacements need developer attention; 14/15 workflow(s) are Studio-loadable (1 blocked — 7% not loadable) |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Action Required:** Address the items above before deploying to production. Focus on sections with the lowest scores first.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 87 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 1895 | 1895 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 15946 | 8594 | 0 | 0 | 0 | 7352 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 15102 | 9557 | 0 | 2970 | 0 | 2575 |
| executable-path-validator | Yes | 1019 | 872 | 0 | 0 | 0 | 147 |
| post-emission-dependency-analyzer | Yes | 11 | 11 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "Process.xaml",
    "GetTransactionData.xaml",
    "SetTransactionStatus.xaml",
    "CloseAllApplications.xaml",
    "KillAllProcesses.xaml"
  ],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "Process.xaml",
      "description": "Stripped 5 placeholder token(s) from Process.xaml",
      "developerAction": "Review Process.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved uweb:HttpClientRequest.EndPoint from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved uweb:DeserializeJson.JsonString from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved uweb:DeserializeJson.JsonObject from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved ForEach.Values from attribute to child-element in InvoiceDispatcher.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InvoiceDispatcher.xaml",
      "description": "Catalog (fallback): Moved uds:QueryEntity.Result from attribute to child-element in InvoiceDispatcher.xaml"
    }
  ],
  "remediations": [
    {
      "level": "validation-finding",
      "file": "InvoiceExtractionAndValidation.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 146: Activity \"DigitizeDocument\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:DigitizeDocument\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceExtractionAndValidation.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 190: Activity \"ExtractDocumentData\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:ExtractDocumentData\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceExtractionAndValidation.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 668: Activity \"ValidateDocumentData\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:ValidateDocumentData\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InvoiceExtractionAndValidation.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 748: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "PurchaseOrderValidation.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 133: .Trim() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in PurchaseOrderValidation.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "InvoiceExtractionAndValidation.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"value\" in InvoiceExtractionAndValidation.xaml with the appropriate type. Expression context: value",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "CreateHumanValidationTask.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in CreateHumanValidationTask.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;Cred_Coupa_API&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in InitAllSettings.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "hardcoded-credential",
      "file": "RouteOrRejectInCoupa.xaml",
      "detail": "Potential hardcoded credential detected (pattern: password\\s*[:=]\\s*[\"'](?!\\[)[^...)",
      "severity": "warning"
    },
    {
      "check": "placeholder-value",
      "file": "Process.xaml",
      "detail": "Contains 3 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ProcessTransaction",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "InvoiceExtractionAndValidation",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "CreateHumanValidationTask",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "PurchaseOrderValidation",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "unassigned-decision-variable",
      "file": "PurchaseOrderValidation.xaml",
      "detail": "Line 232: variable \"poStatusCode\" is used in If condition but is never assigned earlier in this workflow — decision gate may always take the same branch",
      "severity": "warning"
    },
    {
      "check": "unassigned-decision-variable",
      "file": "RouteOrRejectInCoupa.xaml",
      "detail": "Line 303: variable \"httpStatusCode\" is used in If condition but is never assigned earlier in this workflow — decision gate may always take the same branch",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Coupa.BaseUrl}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Coupa.Polling.Enabled}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Coupa.Polling.LookbackMinutes}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Orchestrator.FolderName}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:CoupaInvoiceRecon_LastRunUtc}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Business.ToleranceBasis}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Business.TolerancePercent}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:DU.ConfidenceThreshold}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:ActionCenter.SLAHours}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Storage.RetentionDays}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Cred_Coupa_API}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "Process.xaml",
      "detail": "Line 61: x:TypeArguments=\"UiPath.Persistence.Activities.FormTask\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 302: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 302: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 78: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 117: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.Polling.Enabled&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 156: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.Polling.LookbackMinutes&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 199: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Orchestrator.FolderName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 251: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;CoupaInvoiceRecon_LastRunUtc&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 73: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 113: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Business.ToleranceBasis&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 152: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Business.TolerancePercent&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 191: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;DU.ConfidenceThreshold&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 230: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;ActionCenter.SLAHours&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 269: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Orchestrator.FolderName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 308: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Storage.RetentionDays&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "ProcessTransaction.xaml",
      "detail": "Line 176: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ProcessTransaction.xaml",
      "detail": "Line 176: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 141: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 185: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 141: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 185: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "CreateHumanValidationTask.xaml",
      "detail": "Line 73: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;ActionCenter.SLAHours&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PurchaseOrderValidation.xaml",
      "detail": "Line 95: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "RouteOrRejectInCoupa.xaml",
      "detail": "Line 183: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:20&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "RouteOrRejectInCoupa.xaml",
      "detail": "Line 75: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "RouteOrRejectInCoupa.xaml",
      "detail": "Line 114: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Cred_Coupa_API&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "RouteOrRejectInCoupa.xaml",
      "detail": "Line 319: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Cred_Coupa_API&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 100: asset name \"Cred_Coupa_API\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 105: asset name \"Coupa.BaseUrl\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 114: asset name \"Coupa.Polling.Enabled\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 123: asset name \"Coupa.Polling.LookbackMinutes\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 132: asset name \"Business.TolerancePercent\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 141: asset name \"Business.ToleranceBasis\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 150: asset name \"DU.ConfidenceThreshold\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 159: asset name \"ActionCenter.SLAHours\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 168: asset name \"Storage.RetentionDays\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 177: asset name \"Orchestrator.FolderName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Line 235: C# 'true' should be VB.NET 'True' in expression: {&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;pollingEnabled.T...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 484: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractio...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 526: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractio...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 568: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractio...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 610: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractio...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 652: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CDbl(confide...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Line 709: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(genExtrac...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "CreateHumanValidationTask.xaml",
      "detail": "Line 111: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Integer.T...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "PurchaseOrderValidation.xaml",
      "detail": "Line 133: Unbalanced parentheses: 1 open vs 2 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imbalance near position 105, fragment: \"/\\&quot;c) &amp; \\\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "RouteOrRejectInCoupa.xaml",
      "detail": "Line 441: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;STATU...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 81: Standalone \"No\" corrected to \"False\" in expression: No",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 182: Standalone \"No\" corrected to \"False\" in expression: No",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 198: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Cred_Coupa_API\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"chrome\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"iexplore\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"EXCEL\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "InvoiceDispatcher.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "ProcessTransaction.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "InvoiceExtractionAndValidation.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 100,
  "studioCompatibility": [
    {
      "file": "InvoiceDispatcher.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "PerformerMain.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "ProcessTransaction.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[EXPRESSION_SYNTAX_UNFIXABLE] Line 133: .Trim() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl..."
      ]
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[EXPRESSION_IN_LITERAL_SLOT] Line 183: RetryInterval=\"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:20&quot;}\" contains a VB expression or variable that is not bracket-wrapped — must be hh:mm:ss literal or [expression]"
      ]
    },
    {
      "file": "Process.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Main.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "GetTransactionData.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "SetTransactionStatus.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CloseAllApplications.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "KillAllProcesses.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "Init.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "ProcessTransaction",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "InvoiceExtractionAndValidation",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "CreateHumanValidationTask",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "PurchaseOrderValidation",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "PerformerMain.xaml",
      "targetWorkflow": "ProcessTransaction",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Nothing": "[strErrorMessage]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "strErrorMessage"
      ]
    },
    {
      "callerWorkflow": "ProcessTransaction.xaml",
      "targetWorkflow": "InvoiceExtractionAndValidation",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[New Dictionary(Of String, Object) From {{\"InLocalPdfPath\", localPdfPath}, {\"InCoupaInvoiceId\", InCoupaInvoiceId}, {\"InConfig\", InConfig}, {\"OutExtractedPONumber\", extractedPONumber}, {\"OutExtractedInvoiceNumber\", extractedInvoiceNumber}, {\"OutExtractedVendorName\", extractedVendorName}, {\"OutExtractedInvoiceDate\", extractedInvoiceDate}, {\"OutExtractedCurrency\", extractedCurrency}, {\"OutExtractedTotalAmount\", extractedTotalAmount}, {\"OutNeedsHumanValidation\", needsHumanValidation}}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "localPdfPath",
        "extractedPONumber",
        "extractedInvoiceNumber",
        "extractedVendorName",
        "extractedInvoiceDate",
        "extractedCurrency",
        "extractedTotalAmount",
        "needsHumanValidation"
      ]
    },
    {
      "callerWorkflow": "ProcessTransaction.xaml",
      "targetWorkflow": "CreateHumanValidationTask",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[New Dictionary(Of String, Object) From {{\"InCoupaInvoiceId\", InCoupaInvoiceId}, {\"InExtractedPONumber\", extractedPONumber}, {\"InExtractedInvoiceNumber\", extractedInvoiceNumber}, {\"InExtractedVendorName\", extractedVendorName}, {\"InExtractedTotalAmount\", extractedTotalAmount}, {\"InExtractedCurrency\", extractedCurrency}, {\"InConfig\", InConfig}, {\"InResumeFromValidation\", False}, {\"OutValidatedPONumber\", resolvedPONumber}, {\"OutValidatedInvoiceNumber\", resolvedInvoiceNumber}, {\"OutValidatedInvoiceTotal\", resolvedInvoiceTotal}, {\"OutValidatedCurrency\", resolvedCurrency}, {\"OutTaskCompleted\", validationTaskCompleted}}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "extractedPONumber",
        "extractedInvoiceNumber",
        "extractedVendorName",
        "extractedCurrency",
        "extractedTotalAmount",
        "resolvedPONumber",
        "resolvedInvoiceNumber",
        "resolvedInvoiceTotal",
        "resolvedCurrency",
        "validationTaskCompleted"
      ]
    },
    {
      "callerWorkflow": "ProcessTransaction.xaml",
      "targetWorkflow": "PurchaseOrderValidation",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[New Dictionary(Of String, Object) From {{\"InCoupaInvoiceId\", InCoupaInvoiceId}, {\"InPONumber\", resolvedPONumber}, {\"InInvoiceTotal\", resolvedInvoiceTotal}, {\"InToleranceBasis\", toleranceBasis}, {\"InTolerancePercent\", tolerancePercent}, {\"InConfig\", InConfig}, {\"OutPOFound\", poFound}, {\"OutPOMatches\", poMatches}, {\"OutReferenceAmount\", referenceAmount}, {\"OutWithinTolerance\", withinTolerance}, {\"OutRejectionReasonCode\", poValidationRejectionCode}}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "resolvedPONumber",
        "resolvedInvoiceTotal",
        "toleranceBasis",
        "tolerancePercent",
        "poFound",
        "poMatches",
        "referenceAmount",
        "withinTolerance",
        "poValidationRejectionCode"
      ]
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications.xaml",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "InvoiceDispatcher.xaml",
      "postGeneration": "b59dbbecc34508cccac7834535dfb8783f99894dfddf8da61becc8085731569a",
      "postRepair": "b59dbbecc34508cccac7834535dfb8783f99894dfddf8da61becc8085731569a",
      "postNormalization": "b59dbbecc34508cccac7834535dfb8783f99894dfddf8da61becc8085731569a",
      "preCanonicalization": "3874bf3c898a369aa0781ab40459d5c2ad71a4f901ee7751afcd0eb26dc4740e",
      "archivedFile": "32d4f60fdb5275b0685db48538cfc8a42704fc66dc8a54e5a440f8588c4f11b7",
      "postFinalValidationInput": "32d4f60fdb5275b0685db48538cfc8a42704fc66dc8a54e5a440f8588c4f11b7",
      "preArchive": "32d4f60fdb5275b0685db48538cfc8a42704fc66dc8a54e5a440f8588c4f11b7"
    },
    {
      "workflowFile": "CreateHumanValidationTask.xaml",
      "postGeneration": "f07f1768a2260ebf61984e7a9548bf5edae18798c66f7b7682b4902c89ce12bc",
      "postRepair": "f07f1768a2260ebf61984e7a9548bf5edae18798c66f7b7682b4902c89ce12bc",
      "postNormalization": "f07f1768a2260ebf61984e7a9548bf5edae18798c66f7b7682b4902c89ce12bc",
      "preCanonicalization": "26bb23c4e28623458c7ffbdba793c9a9b886b2e156620aa826a79a0b4875616d",
      "archivedFile": "884a647a6060b355da0bfe88c9da13f1a9e5c93e2534c23bed6ade344cf8ed9f",
      "postFinalValidationInput": "884a647a6060b355da0bfe88c9da13f1a9e5c93e2534c23bed6ade344cf8ed9f",
      "preArchive": "884a647a6060b355da0bfe88c9da13f1a9e5c93e2534c23bed6ade344cf8ed9f"
    },
    {
      "workflowFile": "PurchaseOrderValidation.xaml",
      "postGeneration": "5472a687b2327a0c57bfbc329e69a74a35bf3df2b2fbd324126bf4ec6913f111",
      "postRepair": "5472a687b2327a0c57bfbc329e69a74a35bf3df2b2fbd324126bf4ec6913f111",
      "postNormalization": "5472a687b2327a0c57bfbc329e69a74a35bf3df2b2fbd324126bf4ec6913f111",
      "preCanonicalization": "00cee57f333f30831bacc39f9f8927ce8cfb441f8e81c40daee15a48e5afea95",
      "archivedFile": "812f8410190037bde95093a54cd25a315fec9eaf1a303db6e13ab4e52a80f15e",
      "postFinalValidationInput": "812f8410190037bde95093a54cd25a315fec9eaf1a303db6e13ab4e52a80f15e",
      "preArchive": "812f8410190037bde95093a54cd25a315fec9eaf1a303db6e13ab4e52a80f15e"
    },
    {
      "workflowFile": "RouteOrRejectInCoupa.xaml",
      "postGeneration": "7f28fd16a61bae8b9e3d5ff0fc3645e80b5e22cddfa26adf434d4b239a850ee5",
      "postRepair": "7f28fd16a61bae8b9e3d5ff0fc3645e80b5e22cddfa26adf434d4b239a850ee5",
      "postNormalization": "7f28fd16a61bae8b9e3d5ff0fc3645e80b5e22cddfa26adf434d4b239a850ee5",
      "preCanonicalization": "bd03d7cd85ceb090ebe6f733cbc3541039cb5a142294eed52aba23c8a1935f52",
      "archivedFile": "672d666a6ec9e7e61fddc2c3ca91762d29c20370b6b82c0becb34fd6905d0f69",
      "postFinalValidationInput": "672d666a6ec9e7e61fddc2c3ca91762d29c20370b6b82c0becb34fd6905d0f69",
      "preArchive": "672d666a6ec9e7e61fddc2c3ca91762d29c20370b6b82c0becb34fd6905d0f69"
    },
    {
      "workflowFile": "Process.xaml",
      "postGeneration": "31d98328337c8b0309aaafdf6e6df684c59e7ffbc22d8ed11cdc2c856d496779",
      "postRepair": "31d98328337c8b0309aaafdf6e6df684c59e7ffbc22d8ed11cdc2c856d496779",
      "postNormalization": "31d98328337c8b0309aaafdf6e6df684c59e7ffbc22d8ed11cdc2c856d496779",
      "preCanonicalization": "b937791ec6c5f7b2a5e649b31de6e02dd0f22f3e67edc2981a9e523d5c81b167",
      "archivedFile": "b1a0f975df5d84d622ba65595c6541171b63c510540fec1c326eb38e37bf6201",
      "postFinalValidationInput": "b1a0f975df5d84d622ba65595c6541171b63c510540fec1c326eb38e37bf6201",
      "preArchive": "b1a0f975df5d84d622ba65595c6541171b63c510540fec1c326eb38e37bf6201"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "3e17289cad7f6c78db30cadfe9e528a9280b3b8e80e0402f739d8869bec183f4",
      "postRepair": "3e17289cad7f6c78db30cadfe9e528a9280b3b8e80e0402f739d8869bec183f4",
      "postNormalization": "3e17289cad7f6c78db30cadfe9e528a9280b3b8e80e0402f739d8869bec183f4",
      "preCanonicalization": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "archivedFile": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "postFinalValidationInput": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "preArchive": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff"
    },
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "6b2d04d173a944b5c355b1b537bb85d1b936b44fe91be2f40518cca19f3828bc",
      "postRepair": "6b2d04d173a944b5c355b1b537bb85d1b936b44fe91be2f40518cca19f3828bc",
      "postNormalization": "6b2d04d173a944b5c355b1b537bb85d1b936b44fe91be2f40518cca19f3828bc",
      "preCanonicalization": "6b2d04d173a944b5c355b1b537bb85d1b936b44fe91be2f40518cca19f3828bc",
      "archivedFile": "3134bcf289e3f1713a123e1b238f9e7b95b08611c1cdec7d743fee6e3c108002",
      "postFinalValidationInput": "3134bcf289e3f1713a123e1b238f9e7b95b08611c1cdec7d743fee6e3c108002",
      "preArchive": "3134bcf289e3f1713a123e1b238f9e7b95b08611c1cdec7d743fee6e3c108002"
    },
    {
      "workflowFile": "Init.xaml",
      "postGeneration": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "postRepair": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "postNormalization": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "preCanonicalization": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "archivedFile": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "postFinalValidationInput": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "preArchive": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741"
    },
    {
      "workflowFile": "ProcessTransaction",
      "postNormalization": "558fb3f50387944e628e2b308fd2539c9b9af244d6df02b8783f37e265a7bedf"
    },
    {
      "workflowFile": "InvoiceExtractionAndValidation",
      "postNormalization": "0530c289b999430f69c3ebdbac2e10a7640b1264306dd9fd1e1346725fafdfb8"
    },
    {
      "workflowFile": "CreateHumanValidationTask",
      "postNormalization": "4568869de3d04d3c3fb3eb9e6797f402ef55427f01247fc395368bc7876f5578"
    },
    {
      "workflowFile": "PurchaseOrderValidation",
      "postNormalization": "9d59797d061debad88436346642e2201d1d572e8d23c84b1936c0a2131dbb63c"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  },
  "invokeSerializationFixes": [
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][Init] Dispatcher started. RunId=\\&quot; &amp; dispatchRunId &amp; \\&quot; | UtcNow=\\&quot; &amp; DateTime\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][Init] Dispatcher started. RunId=\" & dispatchRunId & \" | UtcNow=\" & DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][Init] Run correlation ID assigned. RunId=\\&quot; &amp; dispatchRunId&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][Init] Run correlation ID assigned. RunId=\" & dispatchRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][Init] Polling is disabled via Coupa.Polling.Enabled asset. RunId=\\&quot; &amp; dispatchRunId &amp; \\&quot\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][Init] Polling is disabled via Coupa.Polling.Enabled asset. RunId=\" & dispatchRunId & \". Dispatcher exiting without processing.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][WatermarkRead] RunId=\\&quot; &amp; dispatchRunId &amp; \\&quot; | EffectiveFrom=\\&quot; &amp; queryFilterU\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][WatermarkRead] RunId=\" & dispatchRunId & \" | EffectiveFrom=\" & queryFilterUtcStr & \" | NewWatermark=\" & newWatermarkUtc.ToString(\"yyyy-MM-ddTHH:mm:ssZ\") & \" | LookbackMinutes=\" & lookbackMinutes.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][CoupaQuery] RunId=\\&quot; &amp; dispatchRunId &amp; \\&quot; | Coupa API returned response. RawLength=\\&qu\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][CoupaQuery] RunId=\" & dispatchRunId & \" | Coupa API returned response. RawLength=\" & coupaApiResponseJson.Length.ToString() & \" chars.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][Skip] RunId=\\&quot; &amp; dispatchRunId &amp; \\&quot; | Invoice skipped: missing CoupaInvoiceId in API re\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][Skip] RunId=\" & dispatchRunId & \" | Invoice skipped: missing CoupaInvoiceId in API response. InvoiceNumber=\" & coupaInvoiceNumber]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][IdempotencyCheck] RunId=\\&quot; &amp; dispatchRunId &amp; \\&quot; | Checking Data Service for existing op\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][IdempotencyCheck] RunId=\" & dispatchRunId & \" | Checking Data Service for existing open case. CoupaInvoiceId=\" & coupaInvoiceId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InvoiceDispatcher][IdempotencySkip] RunId=\\&quot; &amp; dispatchRunId &amp; \\&quot; | Open InvoiceCase already exists for Co\"",
      "canonicalizedForm": "Message=\"[\"[InvoiceDispatcher][IdempotencySkip] RunId=\" & dispatchRunId & \" | Open InvoiceCase already exists for CoupaInvoiceId=\" & coupaInvoiceId & \". Skipping enqueue to prevent duplicate. ExistingCaseCount=\" & existingCaseCount.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;pollingEnabled.Trim().ToLowerInvariant()&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;\\&quot;true\\&quot;&quo\"",
      "canonicalizedForm": "Condition=\"[pollingEnabled.Trim().ToLowerInvariant() <> \"true\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(coupaInvoiceId)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[String.IsNullOrWhiteSpace(coupaInvoiceId) = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isDuplicateItem&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[isDuplicateItem = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaBaseUrl&quot;}\"",
      "canonicalizedForm": "Value=\"[coupaBaseUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;pollingEnabled&quot;}\"",
      "canonicalizedForm": "Value=\"[pollingEnabled]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;lookbackMinutesStr&quot;}\"",
      "canonicalizedForm": "Value=\"[lookbackMinutesStr]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;orchestratorFolder&quot;}\"",
      "canonicalizedForm": "Value=\"[orchestratorFolder]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;lastRunUtcStr&quot;}\"",
      "canonicalizedForm": "Value=\"[lastRunUtcStr]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;existingCaseList&quot;}\"",
      "canonicalizedForm": "Result=\"[existingCaseList]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;Guid.NewGuid().ToString(\\&quot;N\\&quot;).Substring(0, 16)&quot;}]",
      "canonicalizedForm": "[Guid.NewGuid().ToString(\"N\").Substring(0, 16)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;lastRunUtc.ToString(\\&quot;yyyy-MM-ddTHH:mm:ssZ\\&quot;)&quot;}]",
      "canonicalizedForm": "[lastRunUtc.ToString(\"yyyy-MM-ddTHH:mm:ssZ\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentInvoice&quot;}]",
      "canonicalizedForm": "[currentInvoice]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentInvoice(\\&quot;id\\&quot;) IsNot Nothing, currentInvoice(\\&quot;id\\&quot;).ToString().Trim(), String.Empty)&quot;}]",
      "canonicalizedForm": "[If(currentInvoice(\"id\") IsNot Nothing, currentInvoice(\"id\").ToString().Trim(), String.Empty)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentInvoice(\\&quot;invoice_number\\&quot;) IsNot Nothing, currentInvoice(\\&quot;invoice_number\\&quot;).ToString().Trim(), Stri",
      "canonicalizedForm": "[If(currentInvoice(\"invoice_number\") IsNot Nothing, currentInvoice(\"invoice_number\").ToString().Trim(), String.Empty)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentInvoice(\\&quot;vendor_id\\&quot;) IsNot Nothing, currentInvoice(\\&quot;vendor_id\\&quot;).ToString().Trim(), String.Empty)&",
      "canonicalizedForm": "[If(currentInvoice(\"vendor_id\") IsNot Nothing, currentInvoice(\"vendor_id\").ToString().Trim(), String.Empty)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentInvoice(\\&quot;vendor_name\\&quot;) IsNot Nothing, currentInvoice(\\&quot;vendor_name\\&quot;).ToString().Trim(), String.Emp",
      "canonicalizedForm": "[If(currentInvoice(\"vendor_name\") IsNot Nothing, currentInvoice(\"vendor_name\").ToString().Trim(), String.Empty)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentInvoice(\\&quot;pdf_attachment_url\\&quot;) IsNot Nothing, currentInvoice(\\&quot;pdf_attachment_url\\&quot;).ToString().Trim",
      "canonicalizedForm": "[If(currentInvoice(\"pdf_attachment_url\") IsNot Nothing, currentInvoice(\"pdf_attachment_url\").ToString().Trim(), String.Empty)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(currentInvoice(\\&quot;submitted_at\\&quot;) IsNot Nothing, currentInvoice(\\&quot;submitted_at\\&quot;).ToString().Trim(), DateTime",
      "canonicalizedForm": "[If(currentInvoice(\"submitted_at\") IsNot Nothing, currentInvoice(\"submitted_at\").ToString().Trim(), DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\"))]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;existingCaseCount &gt; 0&quot;}]",
      "canonicalizedForm": "[existingCaseCount > 0]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Init] PerformerMain starting. RunId=\\&quot; &amp; strRunId &amp; \\&quot; UTC=\\&quot; &amp; DateTime.UtcNow.ToString(\\&quot;o\"",
      "canonicalizedForm": "Message=\"[\"[Init] PerformerMain starting. RunId=\" & strRunId & \" UTC=\" & DateTime.UtcNow.ToString(\"o\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Init] Coupa.BaseUrl loaded: \\&quot; &amp; strCoupaBaseUrl&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[Init] Coupa.BaseUrl loaded: \" & strCoupaBaseUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Init] Configuration loaded successfully. ToleranceBasis=\\&quot; &amp; strToleranceBasis &amp; \\&quot; TolerancePct=\\&quot; &\"",
      "canonicalizedForm": "Message=\"[\"[Init] Configuration loaded successfully. ToleranceBasis=\" & strToleranceBasis & \" TolerancePct=\" & intTolerancePercent.ToString() & \" DU_Threshold=\" & intDuConfidenceThreshold.ToString() & \" SLAHours=\" & intActionCenterSlaHours.ToString() & \". Entering transaction loop.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetTransaction] TransactionCount=\\&quot; &amp; transactionCount.ToString() &amp; \\&quot; ItemRetrieved=\\&quot; &amp; (transa\"",
      "canonicalizedForm": "Message=\"[\"[GetTransaction] TransactionCount=\" & transactionCount.ToString() & \" ItemRetrieved=\" & (transactionItem IsNot Nothing).ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetTransaction] Queue Q_Coupa_InvoiceReconciliation is empty or no eligible items. Exiting transaction loop. TotalProcessed=\"",
      "canonicalizedForm": "Message=\"[\"[GetTransaction] Queue Q_Coupa_InvoiceReconciliation is empty or no eligible items. Exiting transaction loop. TotalProcessed=\" & transactionCount.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Process] Starting transaction #\\&quot; &amp; transactionCount.ToString() &amp; \\&quot; CoupaInvoiceId=\\&quot; &amp; currentC\"",
      "canonicalizedForm": "Message=\"[\"[Process] Starting transaction #\" & transactionCount.ToString() & \" CoupaInvoiceId=\" & currentCoupaInvoiceId & \" QueueItemRef=\" & CStr(transactionItem.Reference)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Process] ProcessTransaction completed. CoupaInvoiceId=\\&quot; &amp; currentCoupaInvoiceId &amp; \\&quot; Status=\\&quot; &amp;\"",
      "canonicalizedForm": "Message=\"[\"[Process] ProcessTransaction completed. CoupaInvoiceId=\" & currentCoupaInvoiceId & \" Status=\" & strTransactionStatus & \" IsBusinessEx=\" & boolIsBusinessException.ToString() & \" RejectionCode=\" & strRejectionReasonCode]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Process] Transaction successful. CoupaInvoiceId=\\&quot; &amp; currentCoupaInvoiceId &amp; \\&quot; SuccessCount=\\&quot; &amp;\"",
      "canonicalizedForm": "Message=\"[\"[Process] Transaction successful. CoupaInvoiceId=\" & currentCoupaInvoiceId & \" SuccessCount=\" & successCount.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Process] Business exception (no retry). CoupaInvoiceId=\\&quot; &amp; currentCoupaInvoiceId &amp; \\&quot; RejectionCode=\\&quo\"",
      "canonicalizedForm": "Message=\"[\"[Process] Business exception (no retry). CoupaInvoiceId=\" & currentCoupaInvoiceId & \" RejectionCode=\" & strRejectionReasonCode & \" Reason=\" & strErrorMessage & \". Invoice rejected in Coupa. BusinessExceptionCount=\" & businessExceptionCount.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;shouldContinueLoop&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}\"",
      "canonicalizedForm": "Condition=\"[shouldContinueLoop = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "While",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionItem&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]\"",
      "canonicalizedForm": "Condition=\"[transactionItem Is Nothing]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;strTransactionStatus&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;Successful&quot;}]\"",
      "canonicalizedForm": "Condition=\"[strTransactionStatus = Successful]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;boolIsBusinessException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[boolIsBusinessException = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;strCoupaBaseUrl&quot;}\"",
      "canonicalizedForm": "Value=\"[strCoupaBaseUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;strToleranceBasis&quot;}\"",
      "canonicalizedForm": "Value=\"[strToleranceBasis]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;intTolerancePercent&quot;}\"",
      "canonicalizedForm": "Value=\"[intTolerancePercent]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;intDuConfidenceThreshold&quot;}\"",
      "canonicalizedForm": "Value=\"[intDuConfidenceThreshold]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;intActionCenterSlaHours&quot;}\"",
      "canonicalizedForm": "Value=\"[intActionCenterSlaHours]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;strOrchestratorFolderName&quot;}\"",
      "canonicalizedForm": "Value=\"[strOrchestratorFolderName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;intStorageRetentionDays&quot;}\"",
      "canonicalizedForm": "Value=\"[intStorageRetentionDays]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;Guid.NewGuid().ToString(\\&quot;N\\&quot;).Substring(0, 12)&quot;}]",
      "canonicalizedForm": "[Guid.NewGuid().ToString(\"N\").Substring(0, 12)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;Coupa.BaseUrl\\&quot;, strCoupaBaseUrl}, {\\&quot;Business.ToleranceBasis\\&quot;, str",
      "canonicalizedForm": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshold\", intDuConfidenceThreshold}, {\"ActionCenter.SLAHours\", intActionCenterSlaHours}, {\"Orchestrator.FolderName\", strOrchestratorFolderName}, {\"Storage.RetentionDays\", intStorageRetentionDays}, {\"PerformerRunId\", strRunId}}]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CStr(transactionItem.SpecificContent(\\&quot;CoupaInvoiceId\\&quot;))&quot;}]",
      "canonicalizedForm": "[CStr(transactionItem.SpecificContent(\"CoupaInvoiceId\"))]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;transactionItem&quot;}]",
      "canonicalizedForm": "[transactionItem]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentCoupaInvoiceId&quot;}]",
      "canonicalizedForm": "[currentCoupaInvoiceId]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;boolIsBusinessException&quot;}]",
      "canonicalizedForm": "[boolIsBusinessException]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;strErrorMessage&quot;}]",
      "canonicalizedForm": "[strErrorMessage]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] START CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; VendorName=\\&quot; &amp; InVendorName \"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] START CoupaInvoiceId=\" & InCoupaInvoiceId & \" VendorName=\" & InVendorName & \" PdfUrl=\" & InInvoicePdfUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] InvoiceCase query complete CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; EntityFound=\\&quo\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] InvoiceCase query complete CoupaInvoiceId=\" & InCoupaInvoiceId & \" EntityFound=\" & (invoiceCaseEntity IsNot Nothing).ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] InvoiceCase marked InProgress CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; CorrelationId=\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] InvoiceCase marked InProgress CoupaInvoiceId=\" & InCoupaInvoiceId & \" CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] PDF downloaded CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; LocalPath=\\&quot; &amp; local\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] PDF downloaded CoupaInvoiceId=\" & InCoupaInvoiceId & \" LocalPath=\" & localPdfPath]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] Extraction complete CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; NeedsHumanValidation=\\&q\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] Extraction complete CoupaInvoiceId=\" & InCoupaInvoiceId & \" NeedsHumanValidation=\" & needsHumanValidation.ToString() & \" PONumber=\" & extractedPONumber & \" InvoiceTotal=\" & CStr(extractedTotalAmount)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] Low-confidence extraction — creating Action Center validation task CoupaInvoiceId=\\&quot; &amp; InCoupaI\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] Low-confidence extraction — creating Action Center validation task CoupaInvoiceId=\" & InCoupaInvoiceId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] Action Center task created and deferred — releasing robot slot CoupaInvoiceId=\\&quot; &amp; InCoupaInvoi\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] Action Center task created and deferred — releasing robot slot CoupaInvoiceId=\" & InCoupaInvoiceId & \" CaseStatus=PendingValidation\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] Human validation complete — resolved fields CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; \"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] Human validation complete — resolved fields CoupaInvoiceId=\" & InCoupaInvoiceId & \" ResolvedPO=\" & resolvedPONumber & \" ResolvedTotal=\" & CStr(resolvedInvoiceTotal)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] PO validation result CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; POFound=\\&quot; &amp; p\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] PO validation result CoupaInvoiceId=\" & InCoupaInvoiceId & \" POFound=\" & poFound.ToString() & \" POMatches=\" & poMatches.ToString() & \" WithinTolerance=\" & withinTolerance.ToString() & \" RejectionCode=\" & poValidationRejectionCode]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;needsHumanValidation&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[needsHumanValidation = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;validationTaskCompleted&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]\"",
      "canonicalizedForm": "Condition=\"[validationTaskCompleted = False]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoiceCaseEntity&quot;}\"",
      "canonicalizedForm": "Result=\"[invoiceCaseEntity]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;InCoupaInvoiceId &amp; \\&quot;_\\&quot; &amp; DateTime.UtcNow.ToString(\\&quot;yyyyMMddHHmmss\\&quot;)&quot;}]",
      "canonicalizedForm": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmss\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;InConfig(\\&quot;DU.ConfidenceThreshold\\&quot;)&quot;}]",
      "canonicalizedForm": "[InConfig(\"DU.ConfidenceThreshold\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;InConfig(\\&quot;Business.TolerancePercent\\&quot;)&quot;}]",
      "canonicalizedForm": "[InConfig(\"Business.TolerancePercent\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CStr(InConfig(\\&quot;Business.ToleranceBasis\\&quot;))&quot;}]",
      "canonicalizedForm": "[CStr(InConfig(\"Business.ToleranceBasis\"))]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;System.IO.Path.Combine(tempFolderPath, InCoupaInvoiceId &amp; \\&quot;.pdf\\&quot;)&quot;}]",
      "canonicalizedForm": "[System.IO.Path.Combine(tempFolderPath, InCoupaInvoiceId & \".pdf\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;invoices/raw/\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot;.pdf\\&quot;&quot;}]",
      "canonicalizedForm": "[\"invoices/raw/\" & InCoupaInvoiceId & \".pdf\"]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;InLocalPdfPath\\&quot;, localPdfPath}, {\\&quot;InCoupaInvoiceId\\&quot;, InCoupaInvoi",
      "canonicalizedForm": "[New Dictionary(Of String, Object) From {{\"InLocalPdfPath\", localPdfPath}, {\"InCoupaInvoiceId\", InCoupaInvoiceId}, {\"InConfig\", InConfig}, {\"OutExtractedPONumber\", extractedPONumber}, {\"OutExtractedInvoiceNumber\", extractedInvoiceNumber}, {\"OutExtractedVendorName\", extractedVendorName}, {\"OutExtractedInvoiceDate\", extractedInvoiceDate}, {\"OutExtractedCurrency\", extractedCurrency}, {\"OutExtractedTotalAmount\", extractedTotalAmount}, {\"OutNeedsHumanValidation\", needsHumanValidation}}]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedPONumber&quot;}]",
      "canonicalizedForm": "[extractedPONumber]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedInvoiceNumber&quot;}]",
      "canonicalizedForm": "[extractedInvoiceNumber]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedTotalAmount&quot;}]",
      "canonicalizedForm": "[extractedTotalAmount]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedCurrency&quot;}]",
      "canonicalizedForm": "[extractedCurrency]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;InCoupaInvoiceId\\&quot;, InCoupaInvoiceId}, {\\&quot;InExtractedPONumber\\&quot;, ext",
      "canonicalizedForm": "[New Dictionary(Of String, Object) From {{\"InCoupaInvoiceId\", InCoupaInvoiceId}, {\"InExtractedPONumber\", extractedPONumber}, {\"InExtractedInvoiceNumber\", extractedInvoiceNumber}, {\"InExtractedVendorName\", extractedVendorName}, {\"InExtractedTotalAmount\", extractedTotalAmount}, {\"InExtractedCurrency\", extractedCurrency}, {\"InConfig\", InConfig}, {\"InResumeFromValidation\", False}, {\"OutValidatedPONumber\", resolvedPONumber}, {\"OutValidatedInvoiceNumber\", resolvedInvoiceNumber}, {\"OutValidatedInvoiceTotal\", resolvedInvoiceTotal}, {\"OutValidatedCurrency\", resolvedCurrency}, {\"OutTaskCompleted\", validationTaskCompleted}}]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;InCoupaInvoiceId\\&quot;, InCoupaInvoiceId}, {\\&quot;InPONumber\\&quot;, resolvedPONu",
      "canonicalizedForm": "[New Dictionary(Of String, Object) From {{\"InCoupaInvoiceId\", InCoupaInvoiceId}, {\"InPONumber\", resolvedPONumber}, {\"InInvoiceTotal\", resolvedInvoiceTotal}, {\"InToleranceBasis\", toleranceBasis}, {\"InTolerancePercent\", tolerancePercent}, {\"InConfig\", InConfig}, {\"OutPOFound\", poFound}, {\"OutPOMatches\", poMatches}, {\"OutReferenceAmount\", referenceAmount}, {\"OutWithinTolerance\", withinTolerance}, {\"OutRejectionReasonCode\", poValidationRejectionCode}}]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[\\&quot; &amp; logContext &amp; \\&quot;] ENTER InvoiceExtractionAndValidation | PdfPath='\\&quot; &amp; InLocalPdfPath &amp; \\\"",
      "canonicalizedForm": "Message=\"[\"[\" & logContext & \"] ENTER InvoiceExtractionAndValidation | PdfPath='\" & InLocalPdfPath & \"' | ConfidenceThreshold=\" & InConfidenceThreshold.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[\\&quot; &amp; logContext &amp; \\&quot;] Starting DigitizeDocument with RetryScope | PdfPath='\\&quot; &amp; InLocalPdfPath &a\"",
      "canonicalizedForm": "Message=\"[\"[\" & logContext & \"] Starting DigitizeDocument with RetryScope | PdfPath='\" & InLocalPdfPath & \"' | ConfidenceThresholdDecimal=\" & confidenceThresholdDecimal]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[\\&quot; &amp; logContext &amp; \\&quot;] DigitizeDocument attempt inside RetryScope | PdfPath='\\&quot; &amp; InLocalPdfPath &\"",
      "canonicalizedForm": "Message=\"[\"[\" & logContext & \"] DigitizeDocument attempt inside RetryScope | PdfPath='\" & InLocalPdfPath & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[\\&quot; &amp; logContext &amp; \\&quot;] DigitizeDocument succeeded | PdfPath='\\&quot; &amp; InLocalPdfPath &amp; \\&quot;' | \"",
      "canonicalizedForm": "Message=\"[\"[\" & logContext & \"] DigitizeDocument succeeded | PdfPath='\" & InLocalPdfPath & \"' | Proceeding to ExtractDocumentData\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[\\&quot; &amp; logContext &amp; \\&quot;] ExtractDocumentData succeeded | ResultsIsNothing=\\&quot; &amp; (extractionResults Is\"",
      "canonicalizedForm": "Message=\"[\"[\" & logContext & \"] ExtractDocumentData succeeded | ResultsIsNothing=\" & (extractionResults Is Nothing).ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[\\&quot; &amp; logContext &amp; \\&quot;] Classic extraction results | PONumber='\\&quot; &amp; extractedPoNumber &amp; \\&quot;\"",
      "canonicalizedForm": "Message=\"[\"[\" & logContext & \"] Classic extraction results | PONumber='\" & extractedPoNumber & \"' conf=\" & confidencePoNumber & \" | InvoiceNumber='\" & extractedInvoiceNumber & \"' conf=\" & confidenceInvoiceNumber & \" | VendorName='\" & extractedVendorName & \"' conf=\" & confidenceVendorName & \" | TotalAmount='\" & extractedTotalAmount & \"' conf=\" & confidenceTotalAmount & \" | MinConf=\" & minConfidenceScore & \" | Threshold=\" & confidenceThresholdDecimal]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[\\&quot; &amp; logContext &amp; \\&quot;] Classic extraction confidence below threshold | MinConf=\\&quot; &amp; minConfidenceS\"",
      "canonicalizedForm": "Message=\"[\"[\" & logContext & \"] Classic extraction confidence below threshold | MinConf=\" & minConfidenceScore & \" | Threshold=\" & confidenceThresholdDecimal & \" | Initiating Generative Extraction fallback\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InLocalPdfPath&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;\\&quot;&quot;}]\"",
      "canonicalizedForm": "Condition=\"[InLocalPdfPath = \"\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;pdfPathValidated&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]\"",
      "canonicalizedForm": "Condition=\"[pdfPathValidated = False]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDe\"",
      "canonicalizedForm": "Condition=\"[CDbl(confidencePoNumber) < CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) < CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) < 0.80 OrElse CDbl(confidenceTotalAmount) < CDbl(confidenceThresholdDecimal) OrElse String.IsNullOrWhiteSpace(extractedPoNumber) OrElse String.IsNullOrWhiteSpace(extractedInvoiceNumber) OrElse String.IsNullOrWhiteSpace(extractedTotalAmount)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Exception=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New ApplicationException(\\&quot;[InvoiceExtractionAndValidation] InLocalPdfPath argument is empty. Cannot digitize invoice PDF. Call\"",
      "canonicalizedForm": "Exception=\"[New ApplicationException(\"[InvoiceExtractionAndValidation] InLocalPdfPath argument is empty. Cannot digitize invoice PDF. Caller must supply a valid local file path.\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Throw",
      "propertyName": "Exception",
      "rationale": "JSON expression leak in Exception normalized to VB expression"
    },
    {
      "originalForm": "Exception=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New ApplicationException(\\&quot;[InvoiceExtractionAndValidation] PDF file not found at path '\\&quot; &amp; InLocalPdfPath &amp; \\&qu\"",
      "canonicalizedForm": "Exception=\"[New ApplicationException(\"[InvoiceExtractionAndValidation] PDF file not found at path '\" & InLocalPdfPath & \"'. Verify Storage Bucket download completed before invoking this workflow.\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Throw",
      "propertyName": "Exception",
      "rationale": "JSON expression leak in Exception normalized to VB expression"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;PONumber\\&quot;), e",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"PONumber\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONumber\").Values(0).Value.ToString(), \"\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;InvoiceNumber\\&quot",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"InvoiceNumber\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"InvoiceNumber\").Values(0).Value.ToString(), \"\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;VendorName\\&quot;),",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"VendorName\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"VendorName\").Values(0).Value.ToString(), \"\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;InvoiceDate\\&quot;)",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"InvoiceDate\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"InvoiceDate\").Values(0).Value.ToString(), \"\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;Currency\\&quot;), e",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"Currency\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"Currency\").Values(0).Value.ToString(), \"\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;TotalAmount\\&quot;)",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"TotalAmount\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"TotalAmount\").Values(0).Value.ToString(), \"0\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;PONumber\\&quot;) An",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"PONumber\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONumber\").Values.Count > 0, extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONumber\").Values(0).Confidence.ToString(\"F4\"), \"0\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;InvoiceNumber\\&quot",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"InvoiceNumber\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"InvoiceNumber\").Values.Count > 0, extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"InvoiceNumber\").Values(0).Confidence.ToString(\"F4\"), \"0\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;VendorName\\&quot;) ",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"VendorName\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"VendorName\").Values.Count > 0, extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"VendorName\").Values(0).Confidence.ToString(\"F4\"), \"0\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;TotalAmount\\&quot;)",
      "canonicalizedForm": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"TotalAmount\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"TotalAmount\").Values.Count > 0, extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"TotalAmount\").Values(0).Confidence.ToString(\"F4\"), \"0\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;Math.Min(Math.Min(CDbl(confidencePoNumber), CDbl(confidenceInvoiceNumber)), Math.Min(CDbl(confidenceVendorName), CDbl(confidenceTot",
      "canonicalizedForm": "[Math.Min(Math.Min(CDbl(confidencePoNumber), CDbl(confidenceInvoiceNumber)), Math.Min(CDbl(confidenceVendorName), CDbl(confidenceTotalAmount))).ToString(\"F4\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(genExtractionResults IsNot Nothing AndAlso genExtractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;PONumber\\&quo",
      "canonicalizedForm": "[If(genExtractionResults IsNot Nothing AndAlso genExtractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"PONumber\") AndAlso genExtractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONumber\").Values.Count > 0, genExtractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONumber\").Values(0).Confidence.ToString(\"F4\"), \"0\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateHumanValidationTask][INFO] Invoked for CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; | InvoiceCaseId=\\&q\"",
      "canonicalizedForm": "Message=\"[\"[CreateHumanValidationTask][INFO] Invoked for CoupaInvoiceId=\" & InCoupaInvoiceId & \" | InvoiceCaseId=\" & InInvoiceCaseId & \" | ResumeFromValidation=\" & InResumeFromValidation.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateHumanValidationTask][INFO] RESUME path: reading completed task for CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId&quot;\"",
      "canonicalizedForm": "Message=\"[\"[CreateHumanValidationTask][INFO] RESUME path: reading completed task for CoupaInvoiceId=\" & InCoupaInvoiceId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateHumanValidationTask][INFO] RESUME complete: CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; | ValidationOu\"",
      "canonicalizedForm": "Message=\"[\"[CreateHumanValidationTask][INFO] RESUME complete: CoupaInvoiceId=\" & InCoupaInvoiceId & \" | ValidationOutcome=\" & validationOutcomeRaw & \" | ValidatedPO=\" & resolvedPoNumber]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateHumanValidationTask][INFO] CREATE path: building AC task for CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quo\"",
      "canonicalizedForm": "Message=\"[\"[CreateHumanValidationTask][INFO] CREATE path: building AC task for CoupaInvoiceId=\" & InCoupaInvoiceId & \" | SLAHours=\" & slaHoursValue.ToString() & \" | DueUtc=\" & validationDueUtc.ToString(\"o\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateHumanValidationTask][INFO] AC task created for CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; | TaskObjec\"",
      "canonicalizedForm": "Message=\"[\"[CreateHumanValidationTask][INFO] AC task created for CoupaInvoiceId=\" & InCoupaInvoiceId & \" | TaskObject=\" & If(formTaskObject IsNot Nothing, formTaskObject.ToString(), \"null\") & \" | DueUtc=\" & validationDueUtc.ToString(\"o\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateHumanValidationTask][INFO] CREATE complete: CoupaInvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; | DeferredRef=\"",
      "canonicalizedForm": "Message=\"[\"[CreateHumanValidationTask][INFO] CREATE complete: CoupaInvoiceId=\" & InCoupaInvoiceId & \" | DeferredRef=\" & queueItemSpecificReference & \" | DueUtc=\" & validationDueUtc.ToString(\"o\") & \" | OutTaskCreated=True\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InResumeFromValidation&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[InResumeFromValidation = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;slaHoursAsset&quot;}\"",
      "canonicalizedForm": "Value=\"[slaHoursAsset]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoiceCaseQueryResult&quot;}\"",
      "canonicalizedForm": "Result=\"[invoiceCaseQueryResult]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;completedTaskData&quot;}\"",
      "canonicalizedForm": "Result=\"[completedTaskData]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "upers:WaitForFormTask",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Integer.TryParse(slaHoursAsset, Nothing) AndAlso CInt(slaHoursAsset) &gt; 0, CInt(slaHoursAsset), InSlaHours)&quot;}]",
      "canonicalizedForm": "[If(Integer.TryParse(slaHoursAsset, Nothing) AndAlso CInt(slaHoursAsset) > 0, CInt(slaHoursAsset), InSlaHours)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;ValidationOutcome\\&quot;), CStr(completedTaskData(\\",
      "canonicalizedForm": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"ValidationOutcome\"), CStr(completedTaskData(\"ValidationOutcome\")), \"CannotDetermine\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;PONumber\\&quot;), CStr(completedTaskData(\\&quot;PON",
      "canonicalizedForm": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"PONumber\"), CStr(completedTaskData(\"PONumber\")), InExtractedPoNumber)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;InvoiceNumber\\&quot;), CStr(completedTaskData(\\&quo",
      "canonicalizedForm": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"InvoiceNumber\"), CStr(completedTaskData(\"InvoiceNumber\")), InExtractedInvoiceNumber)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;VendorName\\&quot;), CStr(completedTaskData(\\&quot;V",
      "canonicalizedForm": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"VendorName\"), CStr(completedTaskData(\"VendorName\")), InExtractedVendorName)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;InvoiceTotal\\&quot;), CStr(completedTaskData(\\&quot",
      "canonicalizedForm": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"InvoiceTotal\"), CStr(completedTaskData(\"InvoiceTotal\")), InExtractedTotalAmount)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;Currency\\&quot;), CStr(completedTaskData(\\&quot;Cur",
      "canonicalizedForm": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"Currency\"), CStr(completedTaskData(\"Currency\")), InExtractedCurrency)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Invoice Validation Required: \\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; | Vendor: \\&quot; &amp; If(String.IsNullOrWhiteSpa",
      "canonicalizedForm": "[\"Invoice Validation Required: \" & InCoupaInvoiceId & \" | Vendor: \" & If(String.IsNullOrWhiteSpace(InExtractedVendorName), \"Unknown\", InExtractedVendorName)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;CoupaInvoiceId\\&quot;, InCoupaInvoiceId}, {\\&quot;InvoiceCaseId\\&quot;, InInvoiceCa",
      "canonicalizedForm": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", InCoupaInvoiceId}, {\"InvoiceCaseId\", InInvoiceCaseId}, {\"PONumber\", If(String.IsNullOrWhiteSpace(InExtractedPoNumber), String.Empty, InExtractedPoNumber)}, {\"InvoiceNumber\", If(String.IsNullOrWhiteSpace(InExtractedInvoiceNumber), String.Empty, InExtractedInvoiceNumber)}, {\"VendorName\", If(String.IsNullOrWhiteSpace(InExtractedVendorName), String.Empty, InExtractedVendorName)}, {\"InvoiceTotal\", If(String.IsNullOrWhiteSpace(InExtractedTotalAmount), String.Empty, InExtractedTotalAmount)}, {\"Currency\", If(String.IsNullOrWhiteSpace(InExtractedCurrency), String.Empty, InExtractedCurrency)}, {\"ValidationDueUtc\", validationDueUtc.ToString(\"o\")}, {\"CatalogName\", taskCatalogName}}]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;RESUME_VALIDATION_\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot;_\\&quot; &amp; DateTime.UtcNow.Ticks.ToString()&quot;}]",
      "canonicalizedForm": "[\"RESUME_VALIDATION_\" & InCoupaInvoiceId & \"_\" & DateTime.UtcNow.Ticks.ToString()]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[PurchaseOrderValidation] START — PoNumber='\\&quot; &amp; InPoNumber &amp; \\&quot;' | InvoiceTotal='\\&quot; &amp; InInvoiceTo\"",
      "canonicalizedForm": "Message=\"[\"[PurchaseOrderValidation] START — PoNumber='\" & InPoNumber & \"' | InvoiceTotal='\" & InInvoiceTotal & \"' | TolerancePct=\" & InTolerancePercent & \"% | ToleranceBasis='\" & InToleranceBasis & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[PurchaseOrderValidation] Calling Coupa PO lookup — Endpoint='\\&quot; &amp; coupaApiEndpoint &amp; \\&quot;' | RetryAttempt=\\&\"",
      "canonicalizedForm": "Message=\"[\"[PurchaseOrderValidation] Calling Coupa PO lookup — Endpoint='\" & coupaApiEndpoint & \"' | RetryAttempt=\" & retryAttemptCount]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[PurchaseOrderValidation] Coupa PO API attempt \\&quot; &amp; retryAttemptCount &amp; \\&quot; of 3 — PoNumber='\\&quot; &amp; I\"",
      "canonicalizedForm": "Message=\"[\"[PurchaseOrderValidation] Coupa PO API attempt \" & retryAttemptCount & \" of 3 — PoNumber='\" & InPoNumber & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[PurchaseOrderValidation] WARN — Coupa PO API transient failure on attempt \\&quot; &amp; retryAttemptCount &amp; \\&quot; | St\"",
      "canonicalizedForm": "Message=\"[\"[PurchaseOrderValidation] WARN — Coupa PO API transient failure on attempt \" & retryAttemptCount & \" | StatusCode=\" & poStatusCode & \" | PoNumber='\" & InPoNumber & \"' | WillRetry=\" & shouldRetryFlag]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[PurchaseOrderValidation] ERROR — Coupa PO API failed after all retry attempts | PoNumber='\\&quot; &amp; InPoNumber &amp; \\&q\"",
      "canonicalizedForm": "Message=\"[\"[PurchaseOrderValidation] ERROR — Coupa PO API failed after all retry attempts | PoNumber='\" & InPoNumber & \"' | FinalStatusCode=\" & poStatusCode & \" | Endpoint='\" & coupaApiEndpoint & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[PurchaseOrderValidation] ERROR — Non-200 response from Coupa PO API | StatusCode=\\&quot; &amp; poStatusCode &amp; \\&quot; | \"",
      "canonicalizedForm": "Message=\"[\"[PurchaseOrderValidation] ERROR — Non-200 response from Coupa PO API | StatusCode=\" & poStatusCode & \" | PoNumber='\" & InPoNumber & \"' | ResponseBody='\" & If(poApiResponseBody.Length > 500, poApiResponseBody.Substring(0, 500) & \"...[truncated]\", poApiResponseBody) & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[PurchaseOrderValidation] WARN — PO not found in Coupa | PoNumber='\\&quot; &amp; InPoNumber &amp; \\&quot;' | Setting POFound=\"",
      "canonicalizedForm": "Message=\"[\"[PurchaseOrderValidation] WARN — PO not found in Coupa | PoNumber='\" & InPoNumber & \"' | Setting POFound=False, Reason=PO_MISMATCH_OR_NOT_FOUND\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(InPoNumber)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[String.IsNullOrWhiteSpace(InPoNumber) = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;poStatusCode&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;200&quot;}]\"",
      "canonicalizedForm": "Condition=\"[poStatusCode = 200]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;poApiResponse&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]\"",
      "canonicalizedForm": "Condition=\"[poApiResponse Is Nothing]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.Equals(InPoNumber.Trim(), poNumberFromCoupa.Trim(), StringComparison.OrdinalIgnoreCase)&quot;,&quot;operator&quot;:&quot;=&quot;\"",
      "canonicalizedForm": "Condition=\"[String.Equals(InPoNumber.Trim(), poNumberFromCoupa.Trim(), StringComparison.OrdinalIgnoreCase) = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectionReasonCodeLocal&quot;}]",
      "canonicalizedForm": "[rejectionReasonCodeLocal]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl.TrimEnd(\\&quot;/\\&quot;c) &amp; \\&quot;/api/purchase_orders?order_number=\\&quot; &amp; InPoNumber.Trim() &amp; \\&quot;",
      "canonicalizedForm": "[coupaBaseUrl.TrimEnd(\"/\"c) & \"/api/purchase_orders?order_number=\" & InPoNumber.Trim() & \"&status=issued&fields=order_number,total,status,line_items\"]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;poStatusCode &gt;= 500 OrElse poStatusCode = 0&quot;}]",
      "canonicalizedForm": "[poStatusCode >= 500 OrElse poStatusCode = 0]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(poApiResponse IsNot Nothing, CStr(poApiResponse(\\&quot;order_number\\&quot;)), \\&quot;\\&quot;)&quot;}]",
      "canonicalizedForm": "[If(poApiResponse IsNot Nothing, CStr(poApiResponse(\"order_number\")), \"\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(poApiResponse IsNot Nothing, CStr(poApiResponse(\\&quot;total\\&quot;)), \\&quot;0\\&quot;)&quot;}]",
      "canonicalizedForm": "[If(poApiResponse IsNot Nothing, CStr(poApiResponse(\"total\")), \"0\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(poApiResponse IsNot Nothing AndAlso poApiResponse(\\&quot;remaining\\&quot;) IsNot Nothing, CStr(poApiResponse(\\&quot;remaining\\&q",
      "canonicalizedForm": "[If(poApiResponse IsNot Nothing AndAlso poApiResponse(\"remaining\") IsNot Nothing, CStr(poApiResponse(\"remaining\")), poTotalFromCoupa)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] START | InvoiceId=\\&quot; &amp; InCoupaInvoiceId &amp; \\&quot; | Decision=\\&quot; &amp; InDecision &am\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] START | InvoiceId=\" & InCoupaInvoiceId & \" | Decision=\" & InDecision & \" | RejectionCode=\" & InRejectionReasonCode]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] Decision branch resolved | IsRoute=\\&quot; &amp; isRouteDecision.ToString() &amp; \\&quot; | Correlatio\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] Decision branch resolved | IsRoute=\" & isRouteDecision.ToString() & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] Coupa API request | Endpoint=\\&quot; &amp; If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] Coupa API request | Endpoint=\" & If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint) & \" | Body=\" & requestBodyJson & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] Coupa API response | StatusCode=\\&quot; &amp; httpStatusCode.ToString() &amp; \\&quot; | Body=\\&quot; &\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] Coupa API response | StatusCode=\" & httpStatusCode.ToString() & \" | Body=\" & httpResponseBody & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] 401 Unauthorized received from Coupa — re-fetching Cred_Coupa_API and retrying once | InvoiceId=\\&quot\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] 401 Unauthorized received from Coupa — re-fetching Cred_Coupa_API and retrying once | InvoiceId=\" & InCoupaInvoiceId & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] Credential-retry response | StatusCode=\\&quot; &amp; httpStatusCode.ToString() &amp; \\&quot; | Correla\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] Credential-retry response | StatusCode=\" & httpStatusCode.ToString() & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] Non-retryable Coupa 4xx error | StatusCode=\\&quot; &amp; httpStatusCode.ToString() &amp; \\&quot; | Res\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] Non-retryable Coupa 4xx error | StatusCode=\" & httpStatusCode.ToString() & \" | ResponseBody=\" & httpResponseBody & \" | InvoiceId=\" & InCoupaInvoiceId & \" | Decision=\" & InDecision & \" | RejectionCode=\" & InRejectionReasonCode & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] Coupa 5xx server error after retries exhausted | StatusCode=\\&quot; &amp; httpStatusCode.ToString() &a\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] Coupa 5xx server error after retries exhausted | StatusCode=\" & httpStatusCode.ToString() & \" | ResponseBody=\" & httpResponseBody & \" | InvoiceId=\" & InCoupaInvoiceId & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RouteOrRejectInCoupa] Coupa action SUCCESS | Decision=\\&quot; &amp; InDecision &amp; \\&quot; | InvoiceId=\\&quot; &amp; InCou\"",
      "canonicalizedForm": "Message=\"[\"[RouteOrRejectInCoupa] Coupa action SUCCESS | Decision=\" & InDecision & \" | InvoiceId=\" & InCoupaInvoiceId & \" | StatusCode=\" & httpStatusCode.ToString() & \" | CorrelationId=\" & correlationId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isRouteDecision&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[isRouteDecision = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isRouteDecision&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]\"",
      "canonicalizedForm": "Condition=\"[isRouteDecision = True]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;httpStatusCode&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;401&quot;}]\"",
      "canonicalizedForm": "Condition=\"[httpStatusCode = 401]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;httpStatusCode &gt;= 400 AndAlso httpStatusCode &lt; 500 AndAlso httpStatusCode &lt;&gt; 401&quot;}]\"",
      "canonicalizedForm": "Condition=\"[httpStatusCode >= 400 AndAlso httpStatusCode < 500 AndAlso httpStatusCode <> 401]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;httpStatusCode &gt;= 500 AndAlso httpStatusCode &lt; 600&quot;}]\"",
      "canonicalizedForm": "Condition=\"[httpStatusCode >= 500 AndAlso httpStatusCode < 600]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaBaseUrl&quot;}\"",
      "canonicalizedForm": "Value=\"[coupaBaseUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Exception=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New BusinessRuleException(\\&quot;[RouteOrRejectInCoupa] Coupa returned non-retryable \\&quot; &amp; httpStatusCode.ToString() &amp; \\\"",
      "canonicalizedForm": "Exception=\"[New BusinessRuleException(\"[RouteOrRejectInCoupa] Coupa returned non-retryable \" & httpStatusCode.ToString() & \" for InvoiceId=\" & InCoupaInvoiceId & \" Decision=\" & InDecision & \" — CorrelationId=\" & correlationId)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Throw",
      "propertyName": "Exception",
      "rationale": "JSON expression leak in Exception normalized to VB expression"
    },
    {
      "originalForm": "Exception=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New ApplicationException(\\&quot;[RouteOrRejectInCoupa] Coupa returned 5xx \\&quot; &amp; httpStatusCode.ToString() &amp; \\&quot; for \"",
      "canonicalizedForm": "Exception=\"[New ApplicationException(\"[RouteOrRejectInCoupa] Coupa returned 5xx \" & httpStatusCode.ToString() & \" for InvoiceId=\" & InCoupaInvoiceId & \" — queue retry eligible — CorrelationId=\" & correlationId)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Throw",
      "propertyName": "Exception",
      "rationale": "JSON expression leak in Exception normalized to VB expression"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;InCoupaInvoiceId &amp; \\&quot;_\\&quot; &amp; DateTime.UtcNow.ToString(\\&quot;yyyyMMddHHmmssfff\\&quot;)&quot;}]",
      "canonicalizedForm": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmssfff\")]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Equals(InDecision, \\&quot;ROUTE\\&quot;, StringComparison.OrdinalIgnoreCase)&quot;}]",
      "canonicalizedForm": "[String.Equals(InDecision, \"ROUTE\", StringComparison.OrdinalIgnoreCase)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    },
    {
      "originalForm": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;STATUS=\\&quot; &amp; httpStatusCode.ToString() &amp; \\&quot;|BODY=\\&quot; &amp; If(httpResponseBody.Length &gt; 500, httpRes",
      "canonicalizedForm": "[\"STATUS=\" & httpStatusCode.ToString() & \"|BODY=\" & If(httpResponseBody.Length > 500, httpResponseBody.Substring(0, 500) & \"...[truncated]\", httpResponseBody)]",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "InvokeArgument",
      "propertyName": "ArgumentValue",
      "rationale": "JSON expression in invoke argument value normalized"
    }
  ],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dispatchRunId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][Init] Dispatcher started. RunId=&quot; &amp; dispatchRunId &amp; &quot; | UtcNow=&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyy-MM-ddTHH:mm:ssZ&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dispatchRunId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dispatchRunId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][Init] Run correlation ID assigned. RunId=&quot; &amp; dispatchRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dispatchRunId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "coupaBaseUrl",
      "offendingExpression": "[coupaBaseUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaBaseUrl\" referenced in Value but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "pollingEnabled",
      "offendingExpression": "[pollingEnabled]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"pollingEnabled\" referenced in Value but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "lookbackMinutesStr",
      "offendingExpression": "[lookbackMinutesStr]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lookbackMinutesStr\" referenced in Value but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "orchestratorFolder",
      "offendingExpression": "[orchestratorFolder]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"orchestratorFolder\" referenced in Value but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "pollingEnabled",
      "offendingExpression": "[pollingEnabled.Trim().ToLowerInvariant() &lt;&gt; &quot;true&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"pollingEnabled\" referenced in Condition but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "lastRunUtcStr",
      "offendingExpression": "[lastRunUtcStr]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lastRunUtcStr\" referenced in Value but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dispatchRunId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][WatermarkRead] RunId=&quot; &amp; dispatchRunId &amp; &quot; | EffectiveFrom=&quot; &amp; queryFilterUtcStr &amp; &quot; | NewWatermark=&quot; &amp; newWatermarkUtc.ToString",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dispatchRunId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "queryFilterUtcStr",
      "offendingExpression": "[&quot;[InvoiceDispatcher][WatermarkRead] RunId=&quot; &amp; dispatchRunId &amp; &quot; | EffectiveFrom=&quot; &amp; queryFilterUtcStr &amp; &quot; | NewWatermark=&quot; &amp; newWatermarkUtc.ToString",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"queryFilterUtcStr\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "newWatermarkUtc",
      "offendingExpression": "[&quot;[InvoiceDispatcher][WatermarkRead] RunId=&quot; &amp; dispatchRunId &amp; &quot; | EffectiveFrom=&quot; &amp; queryFilterUtcStr &amp; &quot; | NewWatermark=&quot; &amp; newWatermarkUtc.ToString",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"newWatermarkUtc\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "lookbackMinutes",
      "offendingExpression": "[&quot;[InvoiceDispatcher][WatermarkRead] RunId=&quot; &amp; dispatchRunId &amp; &quot; | EffectiveFrom=&quot; &amp; queryFilterUtcStr &amp; &quot; | NewWatermark=&quot; &amp; newWatermarkUtc.ToString",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lookbackMinutes\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[String.IsNullOrWhiteSpace(coupaInvoiceId) = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Condition but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dispatchRunId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][Skip] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Invoice skipped: missing CoupaInvoiceId in API response. InvoiceNumber=&quot; &amp; coupaInvoiceNumber]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dispatchRunId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceNumber",
      "offendingExpression": "[&quot;[InvoiceDispatcher][Skip] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Invoice skipped: missing CoupaInvoiceId in API response. InvoiceNumber=&quot; &amp; coupaInvoiceNumber]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceNumber\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dispatchRunId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][IdempotencyCheck] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Checking Data Service for existing open case. CoupaInvoiceId=&quot; &amp; coupaInvoiceId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dispatchRunId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][IdempotencyCheck] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Checking Data Service for existing open case. CoupaInvoiceId=&quot; &amp; coupaInvoiceId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "existingCaseList",
      "offendingExpression": "[existingCaseList]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"existingCaseList\" referenced in Result but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "isDuplicateItem",
      "offendingExpression": "[isDuplicateItem = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"isDuplicateItem\" referenced in Condition but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dispatchRunId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][IdempotencySkip] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Open InvoiceCase already exists for CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot;. Skipping enqueu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dispatchRunId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[&quot;[InvoiceDispatcher][IdempotencySkip] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Open InvoiceCase already exists for CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot;. Skipping enqueu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "existingCaseCount",
      "offendingExpression": "[&quot;[InvoiceDispatcher][IdempotencySkip] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Open InvoiceCase already exists for CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot;. Skipping enqueu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"existingCaseCount\" referenced in Message but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "lookbackMinutesStr",
      "offendingExpression": "[If(Integer.TryParse(lookbackMinutesStr, lookbackMinutes), lookbackMinutes, 60)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lookbackMinutesStr\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "lookbackMinutes",
      "offendingExpression": "[If(Integer.TryParse(lookbackMinutesStr, lookbackMinutes), lookbackMinutes, 60)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lookbackMinutes\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "lastRunUtcStr",
      "offendingExpression": "[If(String.IsNullOrWhiteSpace(lastRunUtcStr) OrElse Not DateTime.TryParse(lastRunUtcStr, lastRunUtc), DateTime.UtcNow.AddMinutes(-lookbackMinutes), DateTime.Parse(lastRunUtcStr).ToUniversalTime())]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lastRunUtcStr\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "lastRunUtc",
      "offendingExpression": "[If(String.IsNullOrWhiteSpace(lastRunUtcStr) OrElse Not DateTime.TryParse(lastRunUtcStr, lastRunUtc), DateTime.UtcNow.AddMinutes(-lookbackMinutes), DateTime.Parse(lastRunUtcStr).ToUniversalTime())]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lastRunUtc\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "lookbackMinutes",
      "offendingExpression": "[If(String.IsNullOrWhiteSpace(lastRunUtcStr) OrElse Not DateTime.TryParse(lastRunUtcStr, lastRunUtc), DateTime.UtcNow.AddMinutes(-lookbackMinutes), DateTime.Parse(lastRunUtcStr).ToUniversalTime())]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lookbackMinutes\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "lastRunUtc",
      "offendingExpression": "[lastRunUtc.ToString(\"yyyy-MM-ddTHH:mm:ssZ\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"lastRunUtc\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentInvoice",
      "offendingExpression": "[currentInvoice]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentInvoice\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentInvoice",
      "offendingExpression": "[If(currentInvoice(\"id\") IsNot Nothing, currentInvoice(\"id\").ToString().Trim(), String.Empty)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentInvoice\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentInvoice",
      "offendingExpression": "[If(currentInvoice(\"invoice_number\") IsNot Nothing, currentInvoice(\"invoice_number\").ToString().Trim(), String.Empty)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentInvoice\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentInvoice",
      "offendingExpression": "[If(currentInvoice(\"vendor_id\") IsNot Nothing, currentInvoice(\"vendor_id\").ToString().Trim(), String.Empty)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentInvoice\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentInvoice",
      "offendingExpression": "[If(currentInvoice(\"vendor_name\") IsNot Nothing, currentInvoice(\"vendor_name\").ToString().Trim(), String.Empty)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentInvoice\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentInvoice",
      "offendingExpression": "[If(currentInvoice(\"pdf_attachment_url\") IsNot Nothing, currentInvoice(\"pdf_attachment_url\").ToString().Trim(), String.Empty)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentInvoice\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentInvoice",
      "offendingExpression": "[If(currentInvoice(\"submitted_at\") IsNot Nothing, currentInvoice(\"submitted_at\").ToString().Trim(), DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\"))]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentInvoice\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "existingCaseList",
      "offendingExpression": "[If(existingCaseList IsNot Nothing, DirectCast(existingCaseList, System.Collections.IList).Count, 0)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"existingCaseList\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "existingCaseCount",
      "offendingExpression": "[existingCaseCount > 0]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"existingCaseCount\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceDispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "strRunId",
      "offendingExpression": "[&quot;[Init] PerformerMain starting. RunId=&quot; &amp; strRunId &amp; &quot; UTC=&quot; &amp; DateTime.UtcNow.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strRunId\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "strCoupaBaseUrl",
      "offendingExpression": "[strCoupaBaseUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strCoupaBaseUrl\" referenced in Value but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "strCoupaBaseUrl",
      "offendingExpression": "[&quot;[Init] Coupa.BaseUrl loaded: &quot; &amp; strCoupaBaseUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strCoupaBaseUrl\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "strToleranceBasis",
      "offendingExpression": "[strToleranceBasis]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strToleranceBasis\" referenced in Value but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "intTolerancePercent",
      "offendingExpression": "[intTolerancePercent]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intTolerancePercent\" referenced in Value but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "intDuConfidenceThreshold",
      "offendingExpression": "[intDuConfidenceThreshold]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intDuConfidenceThreshold\" referenced in Value but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "intActionCenterSlaHours",
      "offendingExpression": "[intActionCenterSlaHours]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intActionCenterSlaHours\" referenced in Value but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "strOrchestratorFolderName",
      "offendingExpression": "[strOrchestratorFolderName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strOrchestratorFolderName\" referenced in Value but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "intStorageRetentionDays",
      "offendingExpression": "[intStorageRetentionDays]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intStorageRetentionDays\" referenced in Value but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "While",
      "propertyName": "Condition",
      "referencedSymbol": "shouldContinueLoop",
      "offendingExpression": "[shouldContinueLoop = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"shouldContinueLoop\" referenced in Condition but not declared in workflow \"PerformerMain\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionCount",
      "offendingExpression": "[&quot;[GetTransaction] TransactionCount=&quot; &amp; transactionCount.ToString() &amp; &quot; ItemRetrieved=&quot; &amp; (transactionItem IsNot Nothing).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionCount\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionItem",
      "offendingExpression": "[&quot;[GetTransaction] TransactionCount=&quot; &amp; transactionCount.ToString() &amp; &quot; ItemRetrieved=&quot; &amp; (transactionItem IsNot Nothing).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionItem\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "transactionItem",
      "offendingExpression": "[transactionItem Is Nothing]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionItem\" referenced in Condition but not declared in workflow \"PerformerMain\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionCount",
      "offendingExpression": "[&quot;[GetTransaction] Queue Q_Coupa_InvoiceReconciliation is empty or no eligible items. Exiting transaction loop. TotalProcessed=&quot; &amp; transactionCount.ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionCount\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionCount",
      "offendingExpression": "[&quot;[Process] Starting transaction #&quot; &amp; transactionCount.ToString() &amp; &quot; CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; QueueItemRef=&quot; &amp; CStr(transactionIt",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionCount\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentCoupaInvoiceId",
      "offendingExpression": "[&quot;[Process] Starting transaction #&quot; &amp; transactionCount.ToString() &amp; &quot; CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; QueueItemRef=&quot; &amp; CStr(transactionIt",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentCoupaInvoiceId\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionItem",
      "offendingExpression": "[&quot;[Process] Starting transaction #&quot; &amp; transactionCount.ToString() &amp; &quot; CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; QueueItemRef=&quot; &amp; CStr(transactionIt",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionItem\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"PerformerMain\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Config",
      "offendingExpression": "in_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Config\" referenced in Key but not declared in workflow \"PerformerMain\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_CoupaInvoiceId",
      "offendingExpression": "in_CoupaInvoiceId",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_CoupaInvoiceId\" referenced in Key but not declared in workflow \"PerformerMain\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionStatus",
      "offendingExpression": "out_TransactionStatus",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionStatus\" referenced in Key but not declared in workflow \"PerformerMain\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_IsBusinessException",
      "offendingExpression": "out_IsBusinessException",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_IsBusinessException\" referenced in Key but not declared in workflow \"PerformerMain\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_RejectionReasonCode",
      "offendingExpression": "out_RejectionReasonCode",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_RejectionReasonCode\" referenced in Key but not declared in workflow \"PerformerMain\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_ErrorMessage",
      "offendingExpression": "out_ErrorMessage",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_ErrorMessage\" referenced in Key but not declared in workflow \"PerformerMain\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentCoupaInvoiceId",
      "offendingExpression": "[&quot;[Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; Status=&quot; &amp; strTransactionStatus &amp; &quot; IsBusinessEx=&quot; &amp; boolIsBusi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentCoupaInvoiceId\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "strTransactionStatus",
      "offendingExpression": "[&quot;[Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; Status=&quot; &amp; strTransactionStatus &amp; &quot; IsBusinessEx=&quot; &amp; boolIsBusi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strTransactionStatus\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "boolIsBusinessException",
      "offendingExpression": "[&quot;[Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; Status=&quot; &amp; strTransactionStatus &amp; &quot; IsBusinessEx=&quot; &amp; boolIsBusi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"boolIsBusinessException\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "strRejectionReasonCode",
      "offendingExpression": "[&quot;[Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; Status=&quot; &amp; strTransactionStatus &amp; &quot; IsBusinessEx=&quot; &amp; boolIsBusi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strRejectionReasonCode\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "strTransactionStatus",
      "offendingExpression": "[strTransactionStatus = Successful]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strTransactionStatus\" referenced in Condition but not declared in workflow \"PerformerMain\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Successful",
      "offendingExpression": "[strTransactionStatus = Successful]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Successful\" referenced in Condition but not declared in workflow \"PerformerMain\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentCoupaInvoiceId",
      "offendingExpression": "[&quot;[Process] Transaction successful. CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; SuccessCount=&quot; &amp; successCount.ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentCoupaInvoiceId\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "successCount",
      "offendingExpression": "[&quot;[Process] Transaction successful. CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; SuccessCount=&quot; &amp; successCount.ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"successCount\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "boolIsBusinessException",
      "offendingExpression": "[boolIsBusinessException = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"boolIsBusinessException\" referenced in Condition but not declared in workflow \"PerformerMain\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentCoupaInvoiceId",
      "offendingExpression": "[&quot;[Process] Business exception (no retry). CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; RejectionCode=&quot; &amp; strRejectionReasonCode &amp; &quot; Reason=&quot; &amp; strErr",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentCoupaInvoiceId\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "strRejectionReasonCode",
      "offendingExpression": "[&quot;[Process] Business exception (no retry). CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; RejectionCode=&quot; &amp; strRejectionReasonCode &amp; &quot; Reason=&quot; &amp; strErr",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strRejectionReasonCode\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "strErrorMessage",
      "offendingExpression": "[&quot;[Process] Business exception (no retry). CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; RejectionCode=&quot; &amp; strRejectionReasonCode &amp; &quot; Reason=&quot; &amp; strErr",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strErrorMessage\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "businessExceptionCount",
      "offendingExpression": "[&quot;[Process] Business exception (no retry). CoupaInvoiceId=&quot; &amp; currentCoupaInvoiceId &amp; &quot; RejectionCode=&quot; &amp; strRejectionReasonCode &amp; &quot; Reason=&quot; &amp; strErr",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"businessExceptionCount\" referenced in Message but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "strCoupaBaseUrl",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strCoupaBaseUrl\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "strToleranceBasis",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strToleranceBasis\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "intTolerancePercent",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intTolerancePercent\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "intDuConfidenceThreshold",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intDuConfidenceThreshold\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "intActionCenterSlaHours",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intActionCenterSlaHours\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "strOrchestratorFolderName",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strOrchestratorFolderName\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "intStorageRetentionDays",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"intStorageRetentionDays\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "strRunId",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"Coupa.BaseUrl\", strCoupaBaseUrl}, {\"Business.ToleranceBasis\", strToleranceBasis}, {\"Business.TolerancePercent\", intTolerancePercent}, {\"DU.ConfidenceThreshol",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"strRunId\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "transactionItem",
      "offendingExpression": "[CStr(transactionItem.SpecificContent(\"CoupaInvoiceId\"))]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionItem\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "transactionCount",
      "offendingExpression": "[transactionCount + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionCount\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "successCount",
      "offendingExpression": "[successCount + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"successCount\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "businessExceptionCount",
      "offendingExpression": "[businessExceptionCount + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"businessExceptionCount\" referenced in child element <Assign.Value> but not declared in workflow \"PerformerMain\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "invoiceCaseEntity",
      "offendingExpression": "[invoiceCaseEntity]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"invoiceCaseEntity\" referenced in Result but not declared in workflow \"ProcessTransaction\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "invoiceCaseEntity",
      "offendingExpression": "[&quot;[ProcessTransaction] InvoiceCase query complete CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; EntityFound=&quot; &amp; (invoiceCaseEntity IsNot Nothing).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"invoiceCaseEntity\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[ProcessTransaction] InvoiceCase marked InProgress CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; CorrelationId=&quot; &amp; correlationId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "localPdfPath",
      "offendingExpression": "[&quot;[ProcessTransaction] PDF downloaded CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; LocalPath=&quot; &amp; localPdfPath]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"localPdfPath\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "needsHumanValidation",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; NeedsHumanValidation=&quot; &amp; needsHumanValidation.ToString() &amp; &quot; PONumber=&quot;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"needsHumanValidation\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedPONumber",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; NeedsHumanValidation=&quot; &amp; needsHumanValidation.ToString() &amp; &quot; PONumber=&quot;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedPONumber\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedTotalAmount",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; NeedsHumanValidation=&quot; &amp; needsHumanValidation.ToString() &amp; &quot; PONumber=&quot;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedTotalAmount\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "needsHumanValidation",
      "offendingExpression": "[needsHumanValidation = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"needsHumanValidation\" referenced in Condition but not declared in workflow \"ProcessTransaction\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "validationTaskCompleted",
      "offendingExpression": "[validationTaskCompleted = False]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationTaskCompleted\" referenced in Condition but not declared in workflow \"ProcessTransaction\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "resolvedPONumber",
      "offendingExpression": "[&quot;[ProcessTransaction] Human validation complete — resolved fields CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; ResolvedPO=&quot; &amp; resolvedPONumber &amp; &quot; ResolvedTotal=&q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedPONumber\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "resolvedInvoiceTotal",
      "offendingExpression": "[&quot;[ProcessTransaction] Human validation complete — resolved fields CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; ResolvedPO=&quot; &amp; resolvedPONumber &amp; &quot; ResolvedTotal=&q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedInvoiceTotal\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "poFound",
      "offendingExpression": "[&quot;[ProcessTransaction] PO validation result CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; POFound=&quot; &amp; poFound.ToString() &amp; &quot; POMatches=&quot; &amp; poMatches.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poFound\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "poMatches",
      "offendingExpression": "[&quot;[ProcessTransaction] PO validation result CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; POFound=&quot; &amp; poFound.ToString() &amp; &quot; POMatches=&quot; &amp; poMatches.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poMatches\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "withinTolerance",
      "offendingExpression": "[&quot;[ProcessTransaction] PO validation result CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; POFound=&quot; &amp; poFound.ToString() &amp; &quot; POMatches=&quot; &amp; poMatches.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"withinTolerance\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "poValidationRejectionCode",
      "offendingExpression": "[&quot;[ProcessTransaction] PO validation result CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; POFound=&quot; &amp; poFound.ToString() &amp; &quot; POMatches=&quot; &amp; poMatches.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poValidationRejectionCode\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "poFound",
      "offendingExpression": "[poFound AndAlso poMatches AndAlso withinTolerance]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poFound\" referenced in Condition but not declared in workflow \"ProcessTransaction\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "poMatches",
      "offendingExpression": "[poFound AndAlso poMatches AndAlso withinTolerance]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poMatches\" referenced in Condition but not declared in workflow \"ProcessTransaction\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "withinTolerance",
      "offendingExpression": "[poFound AndAlso poMatches AndAlso withinTolerance]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"withinTolerance\" referenced in Condition but not declared in workflow \"ProcessTransaction\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "tempFolderPath",
      "offendingExpression": "[System.IO.Path.Combine(tempFolderPath, InCoupaInvoiceId & \".pdf\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"tempFolderPath\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractedPONumber",
      "offendingExpression": "[extractedPONumber]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedPONumber\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractedInvoiceNumber",
      "offendingExpression": "[extractedInvoiceNumber]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedInvoiceNumber\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractedTotalAmount",
      "offendingExpression": "[extractedTotalAmount]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedTotalAmount\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractedCurrency",
      "offendingExpression": "[extractedCurrency]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedCurrency\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "PendingValidation",
      "offendingExpression": "[PendingValidation]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PendingValidation\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "logContext",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] ENTER InvoiceExtractionAndValidation | PdfPath=&apos;&quot; &amp; InLocalPdfPath &amp; &quot;&apos; | ConfidenceThreshold=&quot; &amp; InConfidenceThresho",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"logContext\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "pdfPathValidated",
      "offendingExpression": "[pdfPathValidated = False]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"pdfPathValidated\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "logContext",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Starting DigitizeDocument with RetryScope | PdfPath=&apos;&quot; &amp; InLocalPdfPath &amp; &quot;&apos; | ConfidenceThresholdDecimal=&quot; &amp; confide",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"logContext\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "confidenceThresholdDecimal",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Starting DigitizeDocument with RetryScope | PdfPath=&apos;&quot; &amp; InLocalPdfPath &amp; &quot;&apos; | ConfidenceThresholdDecimal=&quot; &amp; confide",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceThresholdDecimal\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "logContext",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] ExtractDocumentData succeeded | ResultsIsNothing=&quot; &amp; (extractionResults Is Nothing).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"logContext\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] ExtractDocumentData succeeded | ResultsIsNothing=&quot; &amp; (extractionResults Is Nothing).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "logContext",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"logContext\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedPoNumber",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedPoNumber\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "confidencePoNumber",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidencePoNumber\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedInvoiceNumber",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedInvoiceNumber\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "confidenceInvoiceNumber",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceInvoiceNumber\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedVendorName",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedVendorName\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "confidenceVendorName",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceVendorName\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedTotalAmount",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedTotalAmount\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "confidenceTotalAmount",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceTotalAmount\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "minConfidenceScore",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"minConfidenceScore\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "confidenceThresholdDecimal",
      "offendingExpression": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction results | PONumber=&apos;&quot; &amp; extractedPoNumber &amp; &quot;&apos; conf=&quot; &amp; confidencePoNumber &amp; &quot; | InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceThresholdDecimal\" referenced in Message but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "confidencePoNumber",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidencePoNumber\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "confidenceThresholdDecimal",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceThresholdDecimal\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "confidenceInvoiceNumber",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceInvoiceNumber\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "confidenceVendorName",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceVendorName\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "confidenceTotalAmount",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceTotalAmount\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "extractedPoNumber",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedPoNumber\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "extractedInvoiceNumber",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedInvoiceNumber\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "extractedTotalAmount",
      "offendingExpression": "[CDbl(confidencePoNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceInvoiceNumber) &lt; CDbl(confidenceThresholdDecimal) OrElse CDbl(confidenceVendorName) &lt; 0.80 OrElse CDbl(confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedTotalAmount\" referenced in Condition but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"PONumber\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONumber\").Values(0)",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"InvoiceNumber\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"InvoiceNumber\")",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"VendorName\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"VendorName\").Value",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"InvoiceDate\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"InvoiceDate\").Val",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"Currency\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"Currency\").Values(0)",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"TotalAmount\"), extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"TotalAmount\").Val",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"PONumber\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONumber\").Va",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"InvoiceNumber\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"InvoiceN",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"VendorName\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"VendorName\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"TotalAmount\") AndAlso extractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"TotalAmoun",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "confidencePoNumber",
      "offendingExpression": "[Math.Min(Math.Min(CDbl(confidencePoNumber), CDbl(confidenceInvoiceNumber)), Math.Min(CDbl(confidenceVendorName), CDbl(confidenceTotalAmount))).ToString(\"F4\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidencePoNumber\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "confidenceInvoiceNumber",
      "offendingExpression": "[Math.Min(Math.Min(CDbl(confidencePoNumber), CDbl(confidenceInvoiceNumber)), Math.Min(CDbl(confidenceVendorName), CDbl(confidenceTotalAmount))).ToString(\"F4\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceInvoiceNumber\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "confidenceVendorName",
      "offendingExpression": "[Math.Min(Math.Min(CDbl(confidencePoNumber), CDbl(confidenceInvoiceNumber)), Math.Min(CDbl(confidenceVendorName), CDbl(confidenceTotalAmount))).ToString(\"F4\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceVendorName\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "confidenceTotalAmount",
      "offendingExpression": "[Math.Min(Math.Min(CDbl(confidencePoNumber), CDbl(confidenceInvoiceNumber)), Math.Min(CDbl(confidenceVendorName), CDbl(confidenceTotalAmount))).ToString(\"F4\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceTotalAmount\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "genExtractionResults",
      "offendingExpression": "[If(genExtractionResults IsNot Nothing AndAlso genExtractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \"PONumber\") AndAlso genExtractionResults.DataPoints.Find(Function(dp) dp.FieldId = \"PONu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"genExtractionResults\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "value",
      "offendingExpression": "[value]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"value\" referenced in child element <Assign.Value> but not declared in workflow \"InvoiceExtractionAndValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "slaHoursAsset",
      "offendingExpression": "[slaHoursAsset]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"slaHoursAsset\" referenced in Value but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "invoiceCaseQueryResult",
      "offendingExpression": "[invoiceCaseQueryResult]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"invoiceCaseQueryResult\" referenced in Result but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "upers:WaitForFormTask",
      "propertyName": "Result",
      "referencedSymbol": "completedTaskData",
      "offendingExpression": "[completedTaskData]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"completedTaskData\" referenced in Result but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "validationOutcomeRaw",
      "offendingExpression": "[&quot;[CreateHumanValidationTask][INFO] RESUME complete: CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | ValidationOutcome=&quot; &amp; validationOutcomeRaw &amp; &quot; | ValidatedPO=&qu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationOutcomeRaw\" referenced in Message but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "resolvedPoNumber",
      "offendingExpression": "[&quot;[CreateHumanValidationTask][INFO] RESUME complete: CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | ValidationOutcome=&quot; &amp; validationOutcomeRaw &amp; &quot; | ValidatedPO=&qu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedPoNumber\" referenced in Message but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "slaHoursValue",
      "offendingExpression": "[&quot;[CreateHumanValidationTask][INFO] CREATE path: building AC task for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | SLAHours=&quot; &amp; slaHoursValue.ToString() &amp; &quot; | Due",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"slaHoursValue\" referenced in Message but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "validationDueUtc",
      "offendingExpression": "[&quot;[CreateHumanValidationTask][INFO] CREATE path: building AC task for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | SLAHours=&quot; &amp; slaHoursValue.ToString() &amp; &quot; | Due",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationDueUtc\" referenced in Message but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "formTaskObject",
      "offendingExpression": "[&quot;[CreateHumanValidationTask][INFO] AC task created for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | TaskObject=&quot; &amp; If(formTaskObject IsNot Nothing, formTaskObject.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"formTaskObject\" referenced in Message but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "validationDueUtc",
      "offendingExpression": "[&quot;[CreateHumanValidationTask][INFO] AC task created for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | TaskObject=&quot; &amp; If(formTaskObject IsNot Nothing, formTaskObject.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationDueUtc\" referenced in Message but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "slaHoursAsset",
      "offendingExpression": "[If(Integer.TryParse(slaHoursAsset, Nothing) AndAlso CInt(slaHoursAsset) > 0, CInt(slaHoursAsset), InSlaHours)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"slaHoursAsset\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "slaHoursValue",
      "offendingExpression": "[DateTime.UtcNow.AddHours(slaHoursValue)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"slaHoursValue\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "completedTaskData",
      "offendingExpression": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"ValidationOutcome\"), CStr(completedTaskData(\"ValidationOutcome\")), \"CannotDetermine\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"completedTaskData\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "completedTaskData",
      "offendingExpression": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"PONumber\"), CStr(completedTaskData(\"PONumber\")), InExtractedPoNumber)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"completedTaskData\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "completedTaskData",
      "offendingExpression": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"InvoiceNumber\"), CStr(completedTaskData(\"InvoiceNumber\")), InExtractedInvoiceNumber)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"completedTaskData\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "completedTaskData",
      "offendingExpression": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"VendorName\"), CStr(completedTaskData(\"VendorName\")), InExtractedVendorName)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"completedTaskData\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "completedTaskData",
      "offendingExpression": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"InvoiceTotal\"), CStr(completedTaskData(\"InvoiceTotal\")), InExtractedTotalAmount)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"completedTaskData\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "completedTaskData",
      "offendingExpression": "[If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"Currency\"), CStr(completedTaskData(\"Currency\")), InExtractedCurrency)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"completedTaskData\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "validationDueUtc",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", InCoupaInvoiceId}, {\"InvoiceCaseId\", InInvoiceCaseId}, {\"PONumber\", If(String.IsNullOrWhiteSpace(InExtractedPoNumber), String.Empty, InExtra",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationDueUtc\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "taskCatalogName",
      "offendingExpression": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", InCoupaInvoiceId}, {\"InvoiceCaseId\", InInvoiceCaseId}, {\"PONumber\", If(String.IsNullOrWhiteSpace(InExtractedPoNumber), String.Empty, InExtra",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskCatalogName\" referenced in child element <Assign.Value> but not declared in workflow \"CreateHumanValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaApiEndpoint",
      "offendingExpression": "[&quot;[PurchaseOrderValidation] Calling Coupa PO lookup — Endpoint=&apos;&quot; &amp; coupaApiEndpoint &amp; &quot;&apos; | RetryAttempt=&quot; &amp; retryAttemptCount]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaApiEndpoint\" referenced in Message but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "retryAttemptCount",
      "offendingExpression": "[&quot;[PurchaseOrderValidation] Calling Coupa PO lookup — Endpoint=&apos;&quot; &amp; coupaApiEndpoint &amp; &quot;&apos; | RetryAttempt=&quot; &amp; retryAttemptCount]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"retryAttemptCount\" referenced in Message but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "retryAttemptCount",
      "offendingExpression": "[&quot;[PurchaseOrderValidation] WARN — Coupa PO API transient failure on attempt &quot; &amp; retryAttemptCount &amp; &quot; | StatusCode=&quot; &amp; poStatusCode &amp; &quot; | PoNumber=&apos;&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"retryAttemptCount\" referenced in Message but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "poStatusCode",
      "offendingExpression": "[&quot;[PurchaseOrderValidation] WARN — Coupa PO API transient failure on attempt &quot; &amp; retryAttemptCount &amp; &quot; | StatusCode=&quot; &amp; poStatusCode &amp; &quot; | PoNumber=&apos;&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poStatusCode\" referenced in Message but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "shouldRetryFlag",
      "offendingExpression": "[&quot;[PurchaseOrderValidation] WARN — Coupa PO API transient failure on attempt &quot; &amp; retryAttemptCount &amp; &quot; | StatusCode=&quot; &amp; poStatusCode &amp; &quot; | PoNumber=&apos;&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"shouldRetryFlag\" referenced in Message but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "poStatusCode",
      "offendingExpression": "[poStatusCode = 200]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poStatusCode\" referenced in Condition but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "poApiResponse",
      "offendingExpression": "[poApiResponse Is Nothing]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poApiResponse\" referenced in Condition but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "poNumberFromCoupa",
      "offendingExpression": "[String.Equals(InPoNumber.Trim(), poNumberFromCoupa.Trim(), StringComparison.OrdinalIgnoreCase) = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poNumberFromCoupa\" referenced in Condition but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "rejectionReasonCodeLocal",
      "offendingExpression": "[rejectionReasonCodeLocal]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"rejectionReasonCodeLocal\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "coupaBaseUrl",
      "offendingExpression": "[coupaBaseUrl.TrimEnd(\"/\"c) & \"/api/purchase_orders?order_number=\" & InPoNumber.Trim() & \"&status=issued&fields=order_number,total,status,line_items\"]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaBaseUrl\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "retryAttemptCount",
      "offendingExpression": "[retryAttemptCount + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"retryAttemptCount\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "poStatusCode",
      "offendingExpression": "[poStatusCode >= 500 OrElse poStatusCode = 0]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poStatusCode\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "poApiResponse",
      "offendingExpression": "[If(poApiResponse IsNot Nothing, CStr(poApiResponse(\"order_number\")), \"\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poApiResponse\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "poApiResponse",
      "offendingExpression": "[If(poApiResponse IsNot Nothing, CStr(poApiResponse(\"total\")), \"0\")]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poApiResponse\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "poApiResponse",
      "offendingExpression": "[If(poApiResponse IsNot Nothing AndAlso poApiResponse(\"remaining\") IsNot Nothing, CStr(poApiResponse(\"remaining\")), poTotalFromCoupa)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poApiResponse\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "poTotalFromCoupa",
      "offendingExpression": "[If(poApiResponse IsNot Nothing AndAlso poApiResponse(\"remaining\") IsNot Nothing, CStr(poApiResponse(\"remaining\")), poTotalFromCoupa)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poTotalFromCoupa\" referenced in child element <Assign.Value> but not declared in workflow \"PurchaseOrderValidation\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "coupaBaseUrl",
      "offendingExpression": "[coupaBaseUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaBaseUrl\" referenced in Value but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "isRouteDecision",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Decision branch resolved | IsRoute=&quot; &amp; isRouteDecision.ToString() &amp; &quot; | CorrelationId=&quot; &amp; correlationId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"isRouteDecision\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Decision branch resolved | IsRoute=&quot; &amp; isRouteDecision.ToString() &amp; &quot; | CorrelationId=&quot; &amp; correlationId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "isRouteDecision",
      "offendingExpression": "[isRouteDecision = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"isRouteDecision\" referenced in Condition but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "isRouteDecision",
      "offendingExpression": "[isRouteDecision = True]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"isRouteDecision\" referenced in Condition but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "isRouteDecision",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API request | Endpoint=&quot; &amp; If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint) &amp; &quot; | Body=&quot; &amp; requestBodyJson &amp; &quot; | Cor",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"isRouteDecision\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaRouteEndpoint",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API request | Endpoint=&quot; &amp; If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint) &amp; &quot; | Body=&quot; &amp; requestBodyJson &amp; &quot; | Cor",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaRouteEndpoint\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaRejectEndpoint",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API request | Endpoint=&quot; &amp; If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint) &amp; &quot; | Body=&quot; &amp; requestBodyJson &amp; &quot; | Cor",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaRejectEndpoint\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "requestBodyJson",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API request | Endpoint=&quot; &amp; If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint) &amp; &quot; | Body=&quot; &amp; requestBodyJson &amp; &quot; | Cor",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"requestBodyJson\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API request | Endpoint=&quot; &amp; If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint) &amp; &quot; | Body=&quot; &amp; requestBodyJson &amp; &quot; | Cor",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API response | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | Body=&quot; &amp; httpResponseBody &amp; &quot; | CorrelationId=&quot; &amp; correla",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpResponseBody",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API response | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | Body=&quot; &amp; httpResponseBody &amp; &quot; | CorrelationId=&quot; &amp; correla",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpResponseBody\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa API response | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | Body=&quot; &amp; httpResponseBody &amp; &quot; | CorrelationId=&quot; &amp; correla",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[httpStatusCode = 401]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Condition but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] 401 Unauthorized received from Coupa — re-fetching Cred_Coupa_API and retrying once | InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | CorrelationId=&quot; &amp; co",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Credential-retry response | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | CorrelationId=&quot; &amp; correlationId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Credential-retry response | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | CorrelationId=&quot; &amp; correlationId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[httpStatusCode &gt;= 400 AndAlso httpStatusCode &lt; 500 AndAlso httpStatusCode &lt;&gt; 401]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Condition but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Non-retryable Coupa 4xx error | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | ResponseBody=&quot; &amp; httpResponseBody &amp; &quot; | InvoiceId=&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpResponseBody",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Non-retryable Coupa 4xx error | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | ResponseBody=&quot; &amp; httpResponseBody &amp; &quot; | InvoiceId=&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpResponseBody\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Non-retryable Coupa 4xx error | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | ResponseBody=&quot; &amp; httpResponseBody &amp; &quot; | InvoiceId=&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[New BusinessRuleException(&quot;[RouteOrRejectInCoupa] Coupa returned non-retryable &quot; &amp; httpStatusCode.ToString() &amp; &quot; for InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; Decisi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Exception but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[New BusinessRuleException(&quot;[RouteOrRejectInCoupa] Coupa returned non-retryable &quot; &amp; httpStatusCode.ToString() &amp; &quot; for InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; Decisi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Exception but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[httpStatusCode &gt;= 500 AndAlso httpStatusCode &lt; 600]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Condition but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa 5xx server error after retries exhausted | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | ResponseBody=&quot; &amp; httpResponseBody &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpResponseBody",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa 5xx server error after retries exhausted | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | ResponseBody=&quot; &amp; httpResponseBody &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpResponseBody\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa 5xx server error after retries exhausted | StatusCode=&quot; &amp; httpStatusCode.ToString() &amp; &quot; | ResponseBody=&quot; &amp; httpResponseBody &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[New ApplicationException(&quot;[RouteOrRejectInCoupa] Coupa returned 5xx &quot; &amp; httpStatusCode.ToString() &amp; &quot; for InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; — queue retry eli",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Exception but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[New ApplicationException(&quot;[RouteOrRejectInCoupa] Coupa returned 5xx &quot; &amp; httpStatusCode.ToString() &amp; &quot; for InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; — queue retry eli",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Exception but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[httpStatusCode = 200 OrElse httpStatusCode = 201]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Condition but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa action SUCCESS | Decision=&quot; &amp; InDecision &amp; &quot; | InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | StatusCode=&quot; &amp; httpStatusCode.ToStr",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "correlationId",
      "offendingExpression": "[&quot;[RouteOrRejectInCoupa] Coupa action SUCCESS | Decision=&quot; &amp; InDecision &amp; &quot; | InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | StatusCode=&quot; &amp; httpStatusCode.ToStr",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"correlationId\" referenced in Message but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "httpStatusCode",
      "offendingExpression": "[\"STATUS=\" & httpStatusCode.ToString() & \"|BODY=\" & If(httpResponseBody.Length > 500, httpResponseBody.Substring(0, 500) & \"...[truncated]\", httpResponseBody)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpStatusCode\" referenced in child element <Assign.Value> but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "httpResponseBody",
      "offendingExpression": "[\"STATUS=\" & httpStatusCode.ToString() & \"|BODY=\" & If(httpResponseBody.Length > 500, httpResponseBody.Substring(0, 500) & \"...[truncated]\", httpResponseBody)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"httpResponseBody\" referenced in child element <Assign.Value> but not declared in workflow \"RouteOrRejectInCoupa\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "No",
      "offendingExpression": "[No]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"No\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "No",
      "offendingExpression": "[No]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"No\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_Config",
      "offendingExpression": "io_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_Config\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_QueueName",
      "offendingExpression": "in_QueueName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_QueueName\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionItem",
      "offendingExpression": "out_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_TransactionNumber",
      "offendingExpression": "io_TransactionNumber",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_TransactionNumber\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Init.xaml",
      "workflow": "Init",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_Config",
      "offendingExpression": "out_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_Config\" referenced in Key but not declared in workflow \"Init\" — expression replaced with \"Nothing\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 233 symbol scope defect(s), 0 sentinel replacement(s), 80 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [],
  "sentinelReplacements": [],
  "unresolvableJsonDefects": [
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dispatchRunId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;lookbackMinutes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;lastRunUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;newWatermarkUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;queryFilterUtcStr&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentInvoice&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaInvoiceId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;vendorId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;vendorName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoicePdfUrl&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;submittedUtcStr&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;existingCaseCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isDuplicateItem&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dateStartTime&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;strRunId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dictConfig&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;shouldContinueLoop&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentCoupaInvoiceId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;transactionCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;boolIsBusinessException&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;strRejectionReasonCode&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;successCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;businessExceptionCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;correlationId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceThreshold&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;tolerancePercent&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;toleranceBasis&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;localPdfPath&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;pdfBucketPath&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedPONumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedInvoiceTotal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedCurrency&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;caseStatus&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;shouldRoute&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceThresholdDecimal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedPoNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedVendorName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedInvoiceDate&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedCurrency&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;extractedTotalAmount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidencePoNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceVendorName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceTotalAmount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;minConfidenceScore&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genConfidencePoNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genConfidenceInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;slaHoursValue&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationDueUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationOutcomeRaw&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedPoNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedVendorName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedTotalAmount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedCurrency&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskDataDictionary&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;queueItemSpecificReference&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;OutTaskCreated&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poFoundLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectionReasonCodeLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;OutRejectionReasonCode&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaApiEndpoint&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;retryAttemptCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;shouldRetryFlag&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poFoundLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectionReasonCodeLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poNumberFromCoupa&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poTotalFromCoupa&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poRemainingFromCoupa&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poFoundLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poMatchesLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;correlationId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isRouteDecision&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;actionSuccess&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaActionResult&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;actionSuccess&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    }
  ],
  "requiredPropertyBindings": [
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: InvoiceDispatcher ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: InvoiceDispatcher ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: InvoiceDispatcher ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[Guid.NewGuid().ToString(\"N\").Substring(0, 16)]",
      "resolvedValue": "[Guid.NewGuid().ToString(\"N\").Substring(0, 16)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Guid.NewGuid().ToString(\"N\").Substring(0, 16)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.BaseUrl asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.BaseUrl asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.BaseUrl asset from Orchestrator failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.Polling.Enabled asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.Polling.Enabled asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.Polling.Enabled asset from Orchestrator failed (&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.Polling.LookbackMinutes asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.Polling.LookbackMinutes asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.Polling.LookbackMinutes asset from Orchestrator failed",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Orchestrator.FolderName asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Orchestrator.FolderName asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Orchestrator.FolderName asset from Orchestrator failed (&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if polling is disabled and log exit if so&quot;]",
      "resolvedValue": "[&quot;Then path: Check if polling is disabled and log exit if so&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if polling is disabled and log exit if so&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if polling is disabled and log exit if so&quot;]",
      "resolvedValue": "[&quot;Else path: Check if polling is disabled and log exit if so&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if polling is disabled and log exit if so&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[InvoiceDispatcher][Init] Polling is disabled via Coupa.Polling.Enabled asset. RunId=&quot; &amp; dispatchRunId &amp; &quot;. Dispatcher exiting without processing.&quot;]",
      "resolvedValue": "[&quot;[InvoiceDispatcher][Init] Polling is disabled via Coupa.Polling.Enabled asset. RunId=&quot; &amp; dispatchRunId &amp; &quot;. Dispatcher exiting without processing.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[InvoiceDispatcher][Init] Polling is disabled via Coupa.Polling.Enabled a",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read CoupaInvoiceRecon_LastRunUtc watermark asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read CoupaInvoiceRecon_LastRunUtc watermark asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read CoupaInvoiceRecon_LastRunUtc watermark asset from Orchestrat",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow]",
      "resolvedValue": "[DateTime.UtcNow]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl &amp; \\&quot;/api/invoices?status=submitted&amp;updated_at[gt_or_eq]=\\&quot; &amp; queryFilterUtcStr &amp; \\&quot;&amp;fields=id,invoice_number,vendor_id,vendor_name,pdf_attachment_url,submitted_at&amp;limit=500\\&quot;&quot;}",
      "resolvedValue": "[coupaBaseUrl & \"/api/invoices?status=submitted&updated_at[gt_or_eq]=\" & queryFilterUtcStr & \"&fields=id,invoice_number,vendor_id,vendor_name,pdf_attachment_url,submitted_at&limit=500\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "GET",
      "resolvedValue": "GET",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GET",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Query Coupa via Integration Service for invoices submitted since watermark, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Query Coupa via Integration Service for invoices submitted since watermark, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Query Coupa via Integration Service for invoices subm",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Query Coupa via Integration Service for invoices submitted since watermark failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Query Coupa via Integration Service for invoices submitted since watermark failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Query Coupa via Integration Service for invoices submit",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaApiResponseJson&quot;}",
      "resolvedValue": "[coupaApiResponseJson]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaApiResponseJs",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Deserialize Coupa API JSON response to object failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Deserialize Coupa API JSON response to object failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Deserialize Coupa API JSON response to object failed (&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[InvoiceDispatcher][CoupaQuery] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Coupa API returned response. RawLength=&quot; &amp; coupaApiResponseJson.Length.ToString() &amp; &quot; chars.&quot;]",
      "resolvedValue": "[&quot;[InvoiceDispatcher][CoupaQuery] RunId=&quot; &amp; dispatchRunId &amp; &quot; | Coupa API returned response. RawLength=&quot; &amp; coupaApiResponseJson.Length.ToString() &amp; &quot; chars.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[InvoiceDispatcher][CoupaQuery] RunId=&quot; &amp; dispatchRunId &amp; &q",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaInvoiceList&quot;}]",
      "resolvedValue": "[coupaInvoiceList]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaInvoiceList&",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing item in: Iterate over each invoice returned from Coupa API&quot;]",
      "resolvedValue": "[&quot;Processing item in: Iterate over each invoice returned from Coupa API&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing item in: Iterate over each invoice returned from Coupa API&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate that coupaInvoiceId is not empty before processing&quot;]",
      "resolvedValue": "[&quot;Then path: Validate that coupaInvoiceId is not empty before processing&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate that coupaInvoiceId is not empty before processing&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate that coupaInvoiceId is not empty before processing&quot;]",
      "resolvedValue": "[&quot;Else path: Validate that coupaInvoiceId is not empty before processing&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate that coupaInvoiceId is not empty before processing&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Query Data Service for existing open InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Query Data Service for existing open InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Query Data Service for existing open InvoiceCase by CoupaInvoiceI",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch: skip if duplicate, process if new invoice&quot;]",
      "resolvedValue": "[&quot;Then path: Branch: skip if duplicate, process if new invoice&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch: skip if duplicate, process if new invoice&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch: skip if duplicate, process if new invoice&quot;]",
      "resolvedValue": "[&quot;Else path: Branch: skip if duplicate, process if new invoice&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch: skip if duplicate, process if new invoice&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InvoiceDispatcher ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InvoiceDispatcher ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InvoiceDispatcher ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: PerformerMain ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: PerformerMain ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: PerformerMain ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow]",
      "resolvedValue": "[DateTime.UtcNow]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[Guid.NewGuid().ToString(\"N\").Substring(0, 12)]",
      "resolvedValue": "[Guid.NewGuid().ToString(\"N\").Substring(0, 12)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Guid.NewGuid().ToString(\"N\").Substring(0, 12)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Coupa.BaseUrl failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Coupa.BaseUrl failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Coupa.BaseUrl failed (&quot; &amp; exception.GetType()",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Business.ToleranceBasis failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Business.ToleranceBasis failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Business.ToleranceBasis failed (&quot; &amp; exception",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Business.TolerancePercent failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Business.TolerancePercent failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Business.TolerancePercent failed (&quot; &amp; excepti",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: DU.ConfidenceThreshold failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: DU.ConfidenceThreshold failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: DU.ConfidenceThreshold failed (&quot; &amp; exception.",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: ActionCenter.SLAHours failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: ActionCenter.SLAHours failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: ActionCenter.SLAHours failed (&quot; &amp; exception.G",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Orchestrator.FolderName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Orchestrator.FolderName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Orchestrator.FolderName failed (&quot; &amp; exception",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Storage.RetentionDays failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Storage.RetentionDays failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Storage.RetentionDays failed (&quot; &amp; exception.G",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Init] Configuration loaded successfully. ToleranceBasis=&quot; &amp; strToleranceBasis &amp; &quot; TolerancePct=&quot; &amp; intTolerancePercent.ToString() &amp; &quot; DU_Threshold=&quot; &amp; intDuConfidenceThreshold.ToString() &amp; &quot; SLAHours=&quot; &amp; intActionCenterSlaHours.ToString() &amp; &quot;. Entering transaction loop.&quot;]",
      "resolvedValue": "[&quot;[Init] Configuration loaded successfully. ToleranceBasis=&quot; &amp; strToleranceBasis &amp; &quot; TolerancePct=&quot; &amp; intTolerancePercent.ToString() &amp; &quot; DU_Threshold=&quot; &amp; intDuConfidenceThreshold.ToString() &amp; &quot; SLAHours=&quot; &amp; intActionCenterSlaHours.ToString() &amp; &quot;. Entering transaction loop.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Init] Configuration loaded successfully. ToleranceBasis=&quot; &amp; str",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] GetTransactionItem from Q_Coupa_InvoiceReconciliation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] GetTransactionItem from Q_Coupa_InvoiceReconciliation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] GetTransactionItem from Q_Coupa_InvoiceReconciliation failed (&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if transaction item is Nothing — exit loop if queue empty&quot;]",
      "resolvedValue": "[&quot;Then path: Check if transaction item is Nothing — exit loop if queue empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if transaction item is Nothing — exit loop if queue empt",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if transaction item is Nothing — exit loop if queue empty&quot;]",
      "resolvedValue": "[&quot;Else path: Check if transaction item is Nothing — exit loop if queue empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if transaction item is Nothing — exit loop if queue empt",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract CoupaInvoiceId from transaction item specific data failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract CoupaInvoiceId from transaction item specific data failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract CoupaInvoiceId from transaction item specific data failed",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[]",
      "resolvedValue": "[]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ProcessTransaction.xaml",
      "resolvedValue": "ProcessTransaction.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ProcessTransaction.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke ProcessTransaction for current queue item failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke ProcessTransaction for current queue item failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke ProcessTransaction for current queue item failed (&quot; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on transaction outcome: Successful vs BusinessException vs SystemException&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on transaction outcome: Successful vs BusinessException vs SystemException&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on transaction outcome: Successful vs BusinessException",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on transaction outcome: Successful vs BusinessException vs SystemException&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on transaction outcome: Successful vs BusinessException vs SystemException&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on transaction outcome: Successful vs BusinessException",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] SetTransactionStatus Successful — compliant invoice processed failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] SetTransactionStatus Successful — compliant invoice processed failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 44,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] SetTransactionStatus Successful — compliant invoice processed fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on exception type: BusinessException vs SystemException&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on exception type: BusinessException vs SystemException&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 46,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on exception type: BusinessException vs SystemException",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on exception type: BusinessException vs SystemException&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on exception type: BusinessException vs SystemException&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 47,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on exception type: BusinessException vs SystemException",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 48,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 49,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] SetTransactionStatus Successful (BusinessException — rejection is a valid business outcome) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] SetTransactionStatus Successful (BusinessException — rejection is a valid business outcome) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 50,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] SetTransactionStatus Successful (BusinessException — rejection is",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 52,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 53,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] SetTransactionStatus Failed (SystemException — eligible for queue retry) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] SetTransactionStatus Failed (SystemException — eligible for queue retry) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 54,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] SetTransactionStatus Failed (SystemException — eligible for queue",
        "precedenceTier": 4
      }
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: PerformerMain ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: PerformerMain ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 55,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: PerformerMain ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: ProcessTransaction ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: ProcessTransaction ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: ProcessTransaction ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessTransaction] START CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; VendorName=&quot; &amp; InVendorName &amp; &quot; PdfUrl=&quot; &amp; InInvoicePdfUrl]",
      "resolvedValue": "[&quot;[ProcessTransaction] START CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; VendorName=&quot; &amp; InVendorName &amp; &quot; PdfUrl=&quot; &amp; InInvoicePdfUrl]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessTransaction] START CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmss\")]",
      "resolvedValue": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmss\")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmss\")]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InConfig(\"DU.ConfidenceThreshold\")]",
      "resolvedValue": "[InConfig(\"DU.ConfidenceThreshold\")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InConfig(\"DU.ConfidenceThreshold\")]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InConfig(\"Business.TolerancePercent\")]",
      "resolvedValue": "[InConfig(\"Business.TolerancePercent\")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InConfig(\"Business.TolerancePercent\")]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[CStr(InConfig(\"Business.ToleranceBasis\"))]",
      "resolvedValue": "[CStr(InConfig(\"Business.ToleranceBasis\"))]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[CStr(InConfig(\"Business.ToleranceBasis\"))]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"invoices/raw/\" & InCoupaInvoiceId & \".pdf\"]",
      "resolvedValue": "[\"invoices/raw/\" & InCoupaInvoiceId & \".pdf\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"invoices/raw/\" & InCoupaInvoiceId & \".pdf\"]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = InCoupaInvoiceId, .CaseStatus = \\&quot;InProgress\\&quot;, .PickedUpUtc = DateTime.UtcNow, .CorrelationId = correlationId}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = InCoupaInvoiceId, .CaseStatus = \"InProgress\", .PickedUpUtc = DateTime.UtcNow, .CorrelationId = correlationId}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.C",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase status to InProgress in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase status to InProgress in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase status to InProgress in Data Service failed (&",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;InInvoicePdfUrl&quot;}",
      "resolvedValue": "[InInvoicePdfUrl]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;InInvoicePdfUrl&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "GET",
      "resolvedValue": "GET",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GET",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Download invoice PDF from Coupa URL to local temp path, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Download invoice PDF from Coupa URL to local temp path, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Download invoice PDF from Coupa URL to local temp pat",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Download invoice PDF from Coupa URL to local temp path failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Download invoice PDF from Coupa URL to local temp path failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Download invoice PDF from Coupa URL to local temp path ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceExtractionAndValidation.xaml",
      "resolvedValue": "InvoiceExtractionAndValidation.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceExtractionAndValidation.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke InvoiceExtractionAndValidation to extract PDF fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke InvoiceExtractionAndValidation to extract PDF fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke InvoiceExtractionAndValidation to extract PDF fields faile",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch: if human validation required, invoke CreateHumanValidationTask&quot;]",
      "resolvedValue": "[&quot;Then path: Branch: if human validation required, invoke CreateHumanValidationTask&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch: if human validation required, invoke CreateHumanValida",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch: if human validation required, invoke CreateHumanValidationTask&quot;]",
      "resolvedValue": "[&quot;Else path: Branch: if human validation required, invoke CreateHumanValidationTask&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch: if human validation required, invoke CreateHumanValida",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessTransaction] Low-confidence extraction — creating Action Center validation task CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId]",
      "resolvedValue": "[&quot;[ProcessTransaction] Low-confidence extraction — creating Action Center validation task CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessTransaction] Low-confidence extraction — creating Action Center v",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CreateHumanValidationTask.xaml",
      "resolvedValue": "CreateHumanValidationTask.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CreateHumanValidationTask.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke CreateHumanValidationTask to create Action Center task and suspend failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke CreateHumanValidationTask to create Action Center task and suspend failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke CreateHumanValidationTask to create Action Center task and",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if validation task was completed in this run (vs deferred)&quot;]",
      "resolvedValue": "[&quot;Then path: Check if validation task was completed in this run (vs deferred)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if validation task was completed in this run (vs deferre",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if validation task was completed in this run (vs deferred)&quot;]",
      "resolvedValue": "[&quot;Else path: Check if validation task was completed in this run (vs deferred)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if validation task was completed in this run (vs deferre",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessTransaction] Action Center task created and deferred — releasing robot slot CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; CaseStatus=PendingValidation&quot;]",
      "resolvedValue": "[&quot;[ProcessTransaction] Action Center task created and deferred — releasing robot slot CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; CaseStatus=PendingValidation&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessTransaction] Action Center task created and deferred — releasing ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "PurchaseOrderValidation.xaml",
      "resolvedValue": "PurchaseOrderValidation.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "PurchaseOrderValidation.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke PurchaseOrderValidation with resolved PO number and invoice total failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke PurchaseOrderValidation with resolved PO number and invoice total failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke PurchaseOrderValidation with resolved PO number and invoic",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Decision: determine if invoice should be routed or rejected&quot;]",
      "resolvedValue": "[&quot;Then path: Decision: determine if invoice should be routed or rejected&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Decision: determine if invoice should be routed or rejected&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Decision: determine if invoice should be routed or rejected&quot;]",
      "resolvedValue": "[&quot;Else path: Decision: determine if invoice should be routed or rejected&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Decision: determine if invoice should be routed or rejected&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ProcessTransaction ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ProcessTransaction ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ProcessTransaction ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: InvoiceExtractionAndValidation ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: InvoiceExtractionAndValidation ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: InvoiceExtractionAndValidation ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[InLocalPdfPath = &quot;&quot;]",
      "resolvedValue": "[InLocalPdfPath = &quot;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InLocalPdfPath = &quot;&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate that InLocalPdfPath is non-empty before attempting digitization&quot;]",
      "resolvedValue": "[&quot;Then path: Validate that InLocalPdfPath is non-empty before attempting digitization&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate that InLocalPdfPath is non-empty before attempting di",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate that InLocalPdfPath is non-empty before attempting digitization&quot;]",
      "resolvedValue": "[&quot;Else path: Validate that InLocalPdfPath is non-empty before attempting digitization&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate that InLocalPdfPath is non-empty before attempting di",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Throw ApplicationException when PDF file is not found on disk&quot;]",
      "resolvedValue": "[&quot;Then path: Throw ApplicationException when PDF file is not found on disk&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Throw ApplicationException when PDF file is not found on disk&",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Throw ApplicationException when PDF file is not found on disk&quot;]",
      "resolvedValue": "[&quot;Else path: Throw ApplicationException when PDF file is not found on disk&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Throw ApplicationException when PDF file is not found on disk&",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[(CDbl(InConfidenceThreshold) / 100.0D).ToString()]",
      "resolvedValue": "[(CDbl(InConfidenceThreshold) / 100.0D).ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[(CDbl(InConfidenceThreshold) / 100.0D).ToString()]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] RetryScope: Digitize and Extract with up to 2 retries on transient DU failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] RetryScope: Digitize and Extract with up to 2 retries on transient DU failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] RetryScope: Digitize and Extract with up to 2 retries on transien",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Delay",
      "propertyName": "Duration",
      "sourceBinding": "attribute-value",
      "originalValue": "00:00:10",
      "resolvedValue": "00:00:10",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "00:00:10",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[&quot; &amp; logContext &amp; &quot;] DigitizeDocument attempt inside RetryScope | PdfPath=&apos;&quot; &amp; InLocalPdfPath &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[&quot; &amp; logContext &amp; &quot;] DigitizeDocument attempt inside RetryScope | PdfPath=&apos;&quot; &amp; InLocalPdfPath &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[&quot; &amp; logContext &amp; &quot;] DigitizeDocument attempt inside Re",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Digitize invoice PDF using OCR to produce a Document Object, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Digitize invoice PDF using OCR to produce a Document Object, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Digitize invoice PDF using OCR to produce a Document ",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Digitize invoice PDF using OCR to produce a Document Object failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Digitize invoice PDF using OCR to produce a Document Object failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Digitize invoice PDF using OCR to produce a Document Ob",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[&quot; &amp; logContext &amp; &quot;] DigitizeDocument succeeded | PdfPath=&apos;&quot; &amp; InLocalPdfPath &amp; &quot;&apos; | Proceeding to ExtractDocumentData&quot;]",
      "resolvedValue": "[&quot;[&quot; &amp; logContext &amp; &quot;] DigitizeDocument succeeded | PdfPath=&apos;&quot; &amp; InLocalPdfPath &amp; &quot;&apos; | Proceeding to ExtractDocumentData&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[&quot; &amp; logContext &amp; &quot;] DigitizeDocument succeeded | PdfPa",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Extract invoice fields from digitized document using Invoice taxonomy, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Extract invoice fields from digitized document using Invoice taxonomy, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Extract invoice fields from digitized document using ",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Extract invoice fields from digitized document using Invoice taxonomy failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Extract invoice fields from digitized document using Invoice taxonomy failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Extract invoice fields from digitized document using In",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign extracted PONumber field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign extracted PONumber field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign extracted PONumber field value from extraction results fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign extracted InvoiceNumber field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign extracted InvoiceNumber field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign extracted InvoiceNumber field value from extraction result",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign extracted VendorName field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign extracted VendorName field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign extracted VendorName field value from extraction results f",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign extracted InvoiceDate field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign extracted InvoiceDate field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign extracted InvoiceDate field value from extraction results ",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign extracted Currency field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign extracted Currency field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign extracted Currency field value from extraction results fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign extracted TotalAmount field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign extracted TotalAmount field value from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign extracted TotalAmount field value from extraction results ",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign per-field confidence score for PONumber failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign per-field confidence score for PONumber failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign per-field confidence score for PONumber failed (&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign per-field confidence score for InvoiceNumber failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign per-field confidence score for InvoiceNumber failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign per-field confidence score for InvoiceNumber failed (&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 44,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign per-field confidence score for VendorName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign per-field confidence score for VendorName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 45,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign per-field confidence score for VendorName failed (&quot; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 46,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 47,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign per-field confidence score for TotalAmount failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign per-field confidence score for TotalAmount failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 48,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign per-field confidence score for TotalAmount failed (&quot; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Evaluate whether classic extraction meets confidence threshold for required fields&quot;]",
      "resolvedValue": "[&quot;Then path: Evaluate whether classic extraction meets confidence threshold for required fields&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 50,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Evaluate whether classic extraction meets confidence threshold",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Evaluate whether classic extraction meets confidence threshold for required fields&quot;]",
      "resolvedValue": "[&quot;Else path: Evaluate whether classic extraction meets confidence threshold for required fields&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 51,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Evaluate whether classic extraction meets confidence threshold",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction confidence below threshold | MinConf=&quot; &amp; minConfidenceScore &amp; &quot; | Threshold=&quot; &amp; confidenceThresholdDecimal &amp; &quot; | Initiating Generative Extraction fallback&quot;]",
      "resolvedValue": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction confidence below threshold | MinConf=&quot; &amp; minConfidenceScore &amp; &quot; | Threshold=&quot; &amp; confidenceThresholdDecimal &amp; &quot; | Initiating Generative Extraction fallback&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 52,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[&quot; &amp; logContext &amp; &quot;] Classic extraction confidence belo",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 53,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 54,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Attempt Generative Extraction via ValidateDocumentData for low-confidence fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Attempt Generative Extraction via ValidateDocumentData for low-confidence fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 55,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Attempt Generative Extraction via ValidateDocumentData for low-co",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 56,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 57,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Assign Generative Extraction confidence for PONumber if GenAI results available failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Assign Generative Extraction confidence for PONumber if GenAI results available failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 58,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Assign Generative Extraction confidence for PONumber if GenAI res",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InvoiceExtractionAndValidation ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InvoiceExtractionAndValidation ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 59,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InvoiceExtractionAndValidation ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: CreateHumanValidationTask ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: CreateHumanValidationTask ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: CreateHumanValidationTask ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[CreateHumanValidationTask][INFO] Invoked for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | InvoiceCaseId=&quot; &amp; InInvoiceCaseId &amp; &quot; | ResumeFromValidation=&quot; &amp; InResumeFromValidation.ToString()]",
      "resolvedValue": "[&quot;[CreateHumanValidationTask][INFO] Invoked for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | InvoiceCaseId=&quot; &amp; InInvoiceCaseId &amp; &quot; | ResumeFromValidation=&quot; &amp; InResumeFromValidation.ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[CreateHumanValidationTask][INFO] Invoked for CoupaInvoiceId=&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read ActionCenter.SLAHours asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read ActionCenter.SLAHours asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read ActionCenter.SLAHours asset from Orchestrator failed (&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[InResumeFromValidation = True]",
      "resolvedValue": "[InResumeFromValidation = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InResumeFromValidation = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch: ResumeFromValidation determines which path to execute&quot;]",
      "resolvedValue": "[&quot;Then path: Branch: ResumeFromValidation determines which path to execute&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch: ResumeFromValidation determines which path to execute&",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch: ResumeFromValidation determines which path to execute&quot;]",
      "resolvedValue": "[&quot;Else path: Branch: ResumeFromValidation determines which path to execute&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch: ResumeFromValidation determines which path to execute&",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[CreateHumanValidationTask][INFO] RESUME path: reading completed task for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId]",
      "resolvedValue": "[&quot;[CreateHumanValidationTask][INFO] RESUME path: reading completed task for CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[CreateHumanValidationTask][INFO] RESUME path: reading completed task for",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Query InvoiceCase from Data Service to retrieve linked Action Center task reference failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Query InvoiceCase from Data Service to retrieve linked Action Center task reference failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Query InvoiceCase from Data Service to retrieve linked Action Cen",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "WaitForFormTask",
      "propertyName": "TaskObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resumeTaskObject&quot;}",
      "resolvedValue": "[resumeTaskObject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resumeTaskObject&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Wait for completed Action Center form task and retrieve results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Wait for completed Action Center form task and retrieve results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Wait for completed Action Center form task and retrieve results f",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;Id\\&quot;, InInvoiceCaseId}, {\\&quot;CaseStatus\\&quot;, \\&quot;Validated\\&quot;}, {\\&quot;ValidatedPONumber\\&quot;, resolvedPoNumber}, {\\&quot;ValidatedInvoiceNumber\\&quot;, resolvedInvoiceNumber}, {\\&quot;ValidatedVendorName\\&quot;, resolvedVendorName}, {\\&quot;ValidatedInvoiceTotal\\&quot;, resolvedTotalAmount}, {\\&quot;ValidatedCurrency\\&quot;, resolvedCurrency}, {\\&quot;ValidatedBy\\&quot;, If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;ValidatorUser\\&quot;), CStr(completedTaskData(\\&quot;ValidatorUser\\&quot;)), \\&quot;Unknown\\&quot;)}, {\\&quot;ValidatedUtc\\&quot;, DateTime.UtcNow}, {\\&quot;ValidationOutcome\\&quot;, validationOutcomeRaw}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"Id\", InInvoiceCaseId}, {\"CaseStatus\", \"Validated\"}, {\"ValidatedPONumber\", resolvedPoNumber}, {\"ValidatedInvoiceNumber\", resolvedInvoiceNumber}, {\"ValidatedVendorName\", resolvedVendorName}, {\"ValidatedInvoiceTotal\", resolvedTotalAmount}, {\"ValidatedCurrency\", resolvedCurrency}, {\"ValidatedBy\", If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"ValidatorUser\"), CStr(completedTaskData(\"ValidatorUser\")), \"Unknown\")}, {\"ValidatedUtc\", DateTime.UtcNow}, {\"ValidationOutcome\", validationOutcomeRaw}}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictiona",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase status to Validated in Data Service (resume path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase status to Validated in Data Service (resume path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase status to Validated in Data Service (resume pa",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"Invoice Validation Required: \" & InCoupaInvoiceId & \" | Vendor: \" & If(String.IsNullOrWhiteSpace(InExtractedVendorName), \"Unknown\", InExtractedVendorName)]",
      "resolvedValue": "[\"Invoice Validation Required: \" & InCoupaInvoiceId & \" | Vendor: \" & If(String.IsNullOrWhiteSpace(InExtractedVendorName), \"Unknown\", InExtractedVendorName)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"Invoice Validation Required: \" & InCoupaInvoiceId & \" | Vendor: \" & If(String.",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskFormSchemaPath&quot;}",
      "resolvedValue": "[taskFormSchemaPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskFormSchemaPath",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create Action Center form task in AC_CoupaInvoiceRecon_DUValidation catalog failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create Action Center form task in AC_CoupaInvoiceRecon_DUValidation catalog failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create Action Center form task in AC_CoupaInvoiceRecon_DUValidati",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;Id\\&quot;, InInvoiceCaseId}, {\\&quot;CaseStatus\\&quot;, \\&quot;PendingValidation\\&quot;}, {\\&quot;NeedsHumanValidation\\&quot;, True}, {\\&quot;ValidationDueUtc\\&quot;, validationDueUtc}, {\\&quot;ValidationOverdue\\&quot;, False}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"Id\", InInvoiceCaseId}, {\"CaseStatus\", \"PendingValidation\"}, {\"NeedsHumanValidation\", True}, {\"ValidationDueUtc\", validationDueUtc}, {\"ValidationOverdue\", False}}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictiona",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase status to PendingValidation with ValidationDueUtc in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase status to PendingValidation with ValidationDueUtc in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase status to PendingValidation with ValidationDue",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"RESUME_VALIDATION_\" & InCoupaInvoiceId & \"_\" & DateTime.UtcNow.Ticks.ToString()]",
      "resolvedValue": "[\"RESUME_VALIDATION_\" & InCoupaInvoiceId & \"_\" & DateTime.UtcNow.Ticks.ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"RESUME_VALIDATION_\" & InCoupaInvoiceId & \"_\" & DateTime.UtcNow.Ticks.ToString(",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Enqueue deferred item to Q_Coupa_InvoiceReconciliation for resume processing after AC task completion failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Enqueue deferred item to Q_Coupa_InvoiceReconciliation for resume processing after AC task completion failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Enqueue deferred item to Q_Coupa_InvoiceReconciliation for resume",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[CreateHumanValidationTask][INFO] CREATE complete: CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | DeferredRef=&quot; &amp; queueItemSpecificReference &amp; &quot; | DueUtc=&quot; &amp; validationDueUtc.ToString(&quot;o&quot;) &amp; &quot; | OutTaskCreated=True&quot;]",
      "resolvedValue": "[&quot;[CreateHumanValidationTask][INFO] CREATE complete: CoupaInvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | DeferredRef=&quot; &amp; queueItemSpecificReference &amp; &quot; | DueUtc=&quot; &amp; validationDueUtc.ToString(&quot;o&quot;) &amp; &quot; | OutTaskCreated=True&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[CreateHumanValidationTask][INFO] CREATE complete: CoupaInvoiceId=&quot; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CreateHumanValidationTask ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CreateHumanValidationTask ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CreateHumanValidationTask ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: PurchaseOrderValidation ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: PurchaseOrderValidation ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: PurchaseOrderValidation ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[PurchaseOrderValidation] START — PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | InvoiceTotal=&apos;&quot; &amp; InInvoiceTotal &amp; &quot;&apos; | TolerancePct=&quot; &amp; InTolerancePercent &amp; &quot;% | ToleranceBasis=&apos;&quot; &amp; InToleranceBasis &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[PurchaseOrderValidation] START — PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | InvoiceTotal=&apos;&quot; &amp; InInvoiceTotal &amp; &quot;&apos; | TolerancePct=&quot; &amp; InTolerancePercent &amp; &quot;% | ToleranceBasis=&apos;&quot; &amp; InToleranceBasis &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[PurchaseOrderValidation] START — PoNumber=&apos;&quot; &amp; InPoNumber ",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[String.IsNullOrWhiteSpace(InPoNumber) = True]",
      "resolvedValue": "[String.IsNullOrWhiteSpace(InPoNumber) = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[String.IsNullOrWhiteSpace(InPoNumber) = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate InPoNumber argument is not empty before proceeding&quot;]",
      "resolvedValue": "[&quot;Then path: Validate InPoNumber argument is not empty before proceeding&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate InPoNumber argument is not empty before proceeding&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate InPoNumber argument is not empty before proceeding&quot;]",
      "resolvedValue": "[&quot;Else path: Validate InPoNumber argument is not empty before proceeding&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate InPoNumber argument is not empty before proceeding&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[PO_MISMATCH_OR_NOT_FOUND]",
      "resolvedValue": "[PO_MISMATCH_OR_NOT_FOUND]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[PO_MISMATCH_OR_NOT_FOUND]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.BaseUrl asset for API endpoint construction failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.BaseUrl asset for API endpoint construction failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.BaseUrl asset for API endpoint construction failed (&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] RetryScope: Coupa PO lookup API call (2 retries, exponential backoff) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] RetryScope: Coupa PO lookup API call (2 retries, exponential backoff) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] RetryScope: Coupa PO lookup API call (2 retries, exponential back",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[PurchaseOrderValidation] Coupa PO API attempt &quot; &amp; retryAttemptCount &amp; &quot; of 3 — PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[PurchaseOrderValidation] Coupa PO API attempt &quot; &amp; retryAttemptCount &amp; &quot; of 3 — PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[PurchaseOrderValidation] Coupa PO API attempt &quot; &amp; retryAttemptC",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaApiEndpoint&quot;}",
      "resolvedValue": "[coupaApiEndpoint]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaApiEndpoint&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "GET",
      "resolvedValue": "GET",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GET",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] HTTP GET request to Coupa PO lookup API via Integration Service connector failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] HTTP GET request to Coupa PO lookup API via Integration Service connector failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] HTTP GET request to Coupa PO lookup API via Integration Service c",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Delay",
      "propertyName": "Duration",
      "sourceBinding": "attribute-value",
      "originalValue": "TimeSpan.FromSeconds(If(retryAttemptCount = 1, 15, 30))",
      "resolvedValue": "TimeSpan.FromSeconds(If(retryAttemptCount = 1, 15, 30))",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TimeSpan.FromSeconds(If(retryAttemptCount = 1, 15, 30))",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[PurchaseOrderValidation] ERROR — Coupa PO API failed after all retry attempts | PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | FinalStatusCode=&quot; &amp; poStatusCode &amp; &quot; | Endpoint=&apos;&quot; &amp; coupaApiEndpoint &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[PurchaseOrderValidation] ERROR — Coupa PO API failed after all retry attempts | PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | FinalStatusCode=&quot; &amp; poStatusCode &amp; &quot; | Endpoint=&apos;&quot; &amp; coupaApiEndpoint &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[PurchaseOrderValidation] ERROR — Coupa PO API failed after all retry att",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check HTTP status code — if 4xx log as business error, if 5xx after retries rethrow system exception&quot;]",
      "resolvedValue": "[&quot;Then path: Check HTTP status code — if 4xx log as business error, if 5xx after retries rethrow system exception&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check HTTP status code — if 4xx log as business error, if 5xx ",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check HTTP status code — if 4xx log as business error, if 5xx after retries rethrow system exception&quot;]",
      "resolvedValue": "[&quot;Else path: Check HTTP status code — if 4xx log as business error, if 5xx after retries rethrow system exception&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check HTTP status code — if 4xx log as business error, if 5xx ",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[PurchaseOrderValidation] ERROR — Non-200 response from Coupa PO API | StatusCode=&quot; &amp; poStatusCode &amp; &quot; | PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | ResponseBody=&apos;&quot; &amp; If(poApiResponseBody.Length &gt; 500, poApiResponseBody.Substring(0, 500) &amp; &quot;...[truncated]&quot;, poApiResponseBody) &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[PurchaseOrderValidation] ERROR — Non-200 response from Coupa PO API | StatusCode=&quot; &amp; poStatusCode &amp; &quot; | PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | ResponseBody=&apos;&quot; &amp; If(poApiResponseBody.Length &gt; 500, poApiResponseBody.Substring(0, 500) &amp; &quot;...[truncated]&quot;, poApiResponseBody) &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[PurchaseOrderValidation] ERROR — Non-200 response from Coupa PO API | St",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poApiResponseBody&quot;}",
      "resolvedValue": "[poApiResponseBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poApiResponseBody&",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Deserialize Coupa PO API JSON response body into structured object failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Deserialize Coupa PO API JSON response body into structured object failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Deserialize Coupa PO API JSON response body into structured objec",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if Coupa returned an empty PO array (PO not found in system)&quot;]",
      "resolvedValue": "[&quot;Then path: Check if Coupa returned an empty PO array (PO not found in system)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if Coupa returned an empty PO array (PO not found in sys",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if Coupa returned an empty PO array (PO not found in system)&quot;]",
      "resolvedValue": "[&quot;Else path: Check if Coupa returned an empty PO array (PO not found in system)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if Coupa returned an empty PO array (PO not found in sys",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[PurchaseOrderValidation] WARN — PO not found in Coupa | PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | Setting POFound=False, Reason=PO_MISMATCH_OR_NOT_FOUND&quot;]",
      "resolvedValue": "[&quot;[PurchaseOrderValidation] WARN — PO not found in Coupa | PoNumber=&apos;&quot; &amp; InPoNumber &amp; &quot;&apos; | Setting POFound=False, Reason=PO_MISMATCH_OR_NOT_FOUND&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[PurchaseOrderValidation] WARN — PO not found in Coupa | PoNumber=&apos;&",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[PO_MISMATCH_OR_NOT_FOUND]",
      "resolvedValue": "[PO_MISMATCH_OR_NOT_FOUND]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[PO_MISMATCH_OR_NOT_FOUND]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract PO number field from Coupa API response (first result in array) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract PO number field from Coupa API response (first result in array) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract PO number field from Coupa API response (first result in ",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract PO total amount from Coupa API response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract PO total amount from Coupa API response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract PO total amount from Coupa API response failed (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Compare extracted PO number against Coupa PO number to check for match&quot;]",
      "resolvedValue": "[&quot;Then path: Compare extracted PO number against Coupa PO number to check for match&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Compare extracted PO number against Coupa PO number to check f",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Compare extracted PO number against Coupa PO number to check for match&quot;]",
      "resolvedValue": "[&quot;Else path: Compare extracted PO number against Coupa PO number to check for match&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Compare extracted PO number against Coupa PO number to check f",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: PurchaseOrderValidation ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: PurchaseOrderValidation ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: PurchaseOrderValidation ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: RouteOrRejectInCoupa ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: RouteOrRejectInCoupa ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: RouteOrRejectInCoupa ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[RouteOrRejectInCoupa] START | InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | Decision=&quot; &amp; InDecision &amp; &quot; | RejectionCode=&quot; &amp; InRejectionReasonCode]",
      "resolvedValue": "[&quot;[RouteOrRejectInCoupa] START | InvoiceId=&quot; &amp; InCoupaInvoiceId &amp; &quot; | Decision=&quot; &amp; InDecision &amp; &quot; | RejectionCode=&quot; &amp; InRejectionReasonCode]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[RouteOrRejectInCoupa] START | InvoiceId=&quot; &amp; InCoupaInvoiceId &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmssfff\")]",
      "resolvedValue": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmssfff\")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InCoupaInvoiceId & \"_\" & DateTime.UtcNow.ToString(\"yyyyMMddHHmmssfff\")]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Coupa Base URL from Orchestrator Asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Coupa Base URL from Orchestrator Asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Coupa Base URL from Orchestrator Asset failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "Cred_Coupa_API",
      "resolvedValue": "Cred_Coupa_API",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Cred_Coupa_API",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Coupa API credential from Orchestrator Asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Coupa API credential from Orchestrator Asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Coupa API credential from Orchestrator Asset failed (&quot; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[String.Equals(InDecision, \"ROUTE\", StringComparison.OrdinalIgnoreCase)]",
      "resolvedValue": "[String.Equals(InDecision, \"ROUTE\", StringComparison.OrdinalIgnoreCase)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[String.Equals(InDecision, \"ROUTE\", StringComparison.OrdinalIgnoreCase)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Build Coupa route endpoint URL when decision is ROUTE&quot;]",
      "resolvedValue": "[&quot;Then path: Build Coupa route endpoint URL when decision is ROUTE&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Build Coupa route endpoint URL when decision is ROUTE&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Build Coupa route endpoint URL when decision is ROUTE&quot;]",
      "resolvedValue": "[&quot;Else path: Build Coupa route endpoint URL when decision is ROUTE&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Build Coupa route endpoint URL when decision is ROUTE&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Build JSON request body for route action&quot;]",
      "resolvedValue": "[&quot;Then path: Build JSON request body for route action&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Build JSON request body for route action&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Build JSON request body for route action&quot;]",
      "resolvedValue": "[&quot;Else path: Build JSON request body for route action&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Build JSON request body for route action&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Execute Coupa route API call via HttpClient with auth and retry for transient failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Execute Coupa route API call via HttpClient with auth and retry for transient failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Execute Coupa route API call via HttpClient with auth and retry f",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaRouteEndpoint&quot;}",
      "resolvedValue": "[coupaRouteEndpoint]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaRouteEndpoint",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "POST",
      "resolvedValue": "POST",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "POST",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] POST to Coupa submit_for_approval endpoint (route path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] POST to Coupa submit_for_approval endpoint (route path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] POST to Coupa submit_for_approval endpoint (route path) failed (&",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaRejectEndpoint&quot;}",
      "resolvedValue": "[coupaRejectEndpoint]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaRejectEndpoin",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "POST",
      "resolvedValue": "POST",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "POST",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] POST to Coupa reject endpoint (reject path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] POST to Coupa reject endpoint (reject path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] POST to Coupa reject endpoint (reject path) failed (&quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Handle 401 auth expiry: re-fetch credential and set authRetryDone flag&quot;]",
      "resolvedValue": "[&quot;Then path: Handle 401 auth expiry: re-fetch credential and set authRetryDone flag&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Handle 401 auth expiry: re-fetch credential and set authRetryD",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Handle 401 auth expiry: re-fetch credential and set authRetryDone flag&quot;]",
      "resolvedValue": "[&quot;Else path: Handle 401 auth expiry: re-fetch credential and set authRetryDone flag&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Handle 401 auth expiry: re-fetch credential and set authRetryD",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "Cred_Coupa_API",
      "resolvedValue": "Cred_Coupa_API",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Cred_Coupa_API",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Re-fetch Coupa API credential after 401 expiry failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Re-fetch Coupa API credential after 401 expiry failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Re-fetch Coupa API credential after 401 expiry failed (&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint)",
      "resolvedValue": "If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "If(isRouteDecision, coupaRouteEndpoint, coupaRejectEndpoint)",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "POST",
      "resolvedValue": "POST",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "POST",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Retry Coupa API call after credential re-fetch (route path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Retry Coupa API call after credential re-fetch (route path) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Retry Coupa API call after credential re-fetch (route path) faile",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Evaluate HTTP status code: detect non-retryable 4xx client errors&quot;]",
      "resolvedValue": "[&quot;Then path: Evaluate HTTP status code: detect non-retryable 4xx client errors&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Evaluate HTTP status code: detect non-retryable 4xx client err",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Evaluate HTTP status code: detect non-retryable 4xx client errors&quot;]",
      "resolvedValue": "[&quot;Else path: Evaluate HTTP status code: detect non-retryable 4xx client errors&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Evaluate HTTP status code: detect non-retryable 4xx client err",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Evaluate HTTP status code: detect 5xx server errors for ApplicationException escalation&quot;]",
      "resolvedValue": "[&quot;Then path: Evaluate HTTP status code: detect 5xx server errors for ApplicationException escalation&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Evaluate HTTP status code: detect 5xx server errors for Applic",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Evaluate HTTP status code: detect 5xx server errors for ApplicationException escalation&quot;]",
      "resolvedValue": "[&quot;Else path: Evaluate HTTP status code: detect 5xx server errors for ApplicationException escalation&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Evaluate HTTP status code: detect 5xx server errors for Applic",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Evaluate success: set actionSuccess True when HTTP 200 or 201&quot;]",
      "resolvedValue": "[&quot;Then path: Evaluate success: set actionSuccess True when HTTP 200 or 201&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Evaluate success: set actionSuccess True when HTTP 200 or 201&",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Evaluate success: set actionSuccess True when HTTP 200 or 201&quot;]",
      "resolvedValue": "[&quot;Else path: Evaluate success: set actionSuccess True when HTTP 200 or 201&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Evaluate success: set actionSuccess True when HTTP 200 or 201&",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: RouteOrRejectInCoupa ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: RouteOrRejectInCoupa ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: RouteOrRejectInCoupa ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization: Invoice Submitted in Coupa Triggers Automation&quot;]",
      "resolvedValue": "[&quot;Initialization: Invoice Submitted in Coupa Triggers Automation&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization: Invoice Submitted in Coupa Triggers Automation&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Retrieve Invoice PDF + Metadata from Coupa",
      "resolvedValue": "Executing: Retrieve Invoice PDF + Metadata from Coupa",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Retrieve Invoice PDF + Metadata from Coupa",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Extract Invoice Fields from PDF (PO#, Invoice#, Amount, Vendor)",
      "resolvedValue": "Executing: Extract Invoice Fields from PDF (PO#, Invoice#, Amount, Vendor)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Extract Invoice Fields from PDF (PO#, Invoice#, Amount, Vendor)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Get PO Details from Coupa for Extracted PO#",
      "resolvedValue": "Executing: Get PO Details from Coupa for Extracted PO#",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Get PO Details from Coupa for Extracted PO#",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Send to Human Validation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Send to Human Validation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Send to Human Validation failed (&quot; &amp; exception.GetType()",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "TODO: Set form schema path",
      "resolvedValue": "TODO: Set form schema path",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TODO: Set form schema path",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Apply Validated Fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Apply Validated Fields failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Apply Validated Fields failed (&quot; &amp; exception.GetType().N",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Get PO Details from Coupa for Extracted PO#",
      "resolvedValue": "Executing: Get PO Details from Coupa for Extracted PO#",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Get PO Details from Coupa for Extracted PO#",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Get PO Details from Coupa for Validated PO#",
      "resolvedValue": "Executing: Get PO Details from Coupa for Validated PO#",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Get PO Details from Coupa for Validated PO#",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Amount Within 5% Tolerance?",
      "resolvedValue": "Executing: Amount Within 5% Tolerance?",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Amount Within 5% Tolerance?",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Reject Invoice in Coupa (PO Mismatch/Not Found)",
      "resolvedValue": "Executing: Reject Invoice in Coupa (PO Mismatch/Not Found)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Reject Invoice in Coupa (PO Mismatch/Not Found)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Reject Invoice in Coupa (PO Mismatch/Not Found)",
      "resolvedValue": "Executing: Reject Invoice in Coupa (PO Mismatch/Not Found)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Reject Invoice in Coupa (PO Mismatch/Not Found)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Route Invoice for DOA Approval in Coupa",
      "resolvedValue": "Executing: Route Invoice for DOA Approval in Coupa",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Route Invoice for DOA Approval in Coupa",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Reject Invoice in Coupa (Out of Tolerance)",
      "resolvedValue": "Executing: Reject Invoice in Coupa (Out of Tolerance)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Reject Invoice in Coupa (Out of Tolerance)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Route Invoice for DOA Approval in Coupa",
      "resolvedValue": "Executing: Route Invoice for DOA Approval in Coupa",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Route Invoice for DOA Approval in Coupa",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "Executing: Reject Invoice in Coupa (Out of Tolerance)",
      "resolvedValue": "Executing: Reject Invoice in Coupa (Out of Tolerance)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Executing: Reject Invoice in Coupa (Out of Tolerance)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
      "resolvedValue": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Invoice Rejected End&quot;]",
      "resolvedValue": "[&quot;Completed: Invoice Rejected End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Invoice Rejected End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "WorkbookPath",
      "sourceBinding": "variable",
      "originalValue": "[str_ConfigPath]",
      "resolvedValue": "[str_ConfigPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ConfigPath",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Settings]",
      "resolvedValue": "[dt_Settings]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Settings",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Constants]",
      "resolvedValue": "[dt_Constants]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Constants",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Cred_Coupa_API&quot;]",
      "resolvedValue": "[&quot;Cred_Coupa_API&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Cred_Coupa_API&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Cred_Coupa_API&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Cred_Coupa_API&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Cred_Coupa_API&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_TempUser]",
      "resolvedValue": "[str_TempUser]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempUser",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa.BaseUrl&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa.BaseUrl&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa.BaseUrl&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa.Polling.Enabled&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa.Polling.Enabled&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa.Polling.Enabled&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa.Polling.LookbackMinutes&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa.Polling.LookbackMinutes&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa.Polling.LookbackMinutes&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Business.TolerancePercent&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Business.TolerancePercent&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Business.TolerancePercent&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Business.ToleranceBasis&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Business.ToleranceBasis&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Business.ToleranceBasis&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;DU.ConfidenceThreshold&quot;)]",
      "resolvedValue": "[dict_Config(&quot;DU.ConfidenceThreshold&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;DU.ConfidenceThreshold&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;ActionCenter.SLAHours&quot;)]",
      "resolvedValue": "[dict_Config(&quot;ActionCenter.SLAHours&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;ActionCenter.SLAHours&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Storage.RetentionDays&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Storage.RetentionDays&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Storage.RetentionDays&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Orchestrator.FolderName&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Orchestrator.FolderName&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Orchestrator.FolderName&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initializing CoupaInvoiceReconciliation ===&quot;]",
      "resolvedValue": "[&quot;=== Initializing CoupaInvoiceReconciliation ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initializing CoupaInvoiceReconciliation ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Init.xaml",
      "resolvedValue": "Init.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Init.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_SystemReady]",
      "resolvedValue": "[bool_SystemReady]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_SystemReady",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization complete&quot;]",
      "resolvedValue": "[&quot;Initialization complete&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization complete&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetTransactionData.xaml",
      "resolvedValue": "GetTransactionData.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetTransactionData.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Process.xaml",
      "resolvedValue": "Process.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Process.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryNumber]",
      "resolvedValue": "[int_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryNumber",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "0",
      "resolvedValue": "0",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "0",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "resolvedValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; Da",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "resolvedValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== CoupaInvoiceReconciliation Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "resolvedValue": "[&quot;=== CoupaInvoiceReconciliation Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== CoupaInvoiceReconciliation Complete. Transactions processed: &quot; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[out_TransactionItem IsNot Nothing]",
      "resolvedValue": "[out_TransactionItem IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[out_TransactionItem IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_TransactionNumber",
        "sourceWorkflow": "GetTransactionData",
        "precedenceTier": 1
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber + 1]",
      "resolvedValue": "[io_TransactionNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "resolvedValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;No more transactions in queue&quot;]",
      "resolvedValue": "[&quot;No more transactions in queue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;No more transactions in queue&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetTransactionData ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_Status = &quot;Successful&quot;]",
      "resolvedValue": "[in_Status = &quot;Successful&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_Status = &quot;Successful&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "resolvedValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "resolvedValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Closing all applications...&quot;]",
      "resolvedValue": "[&quot;Closing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Closing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications closed&quot;]",
      "resolvedValue": "[&quot;All applications closed&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications closed&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "resolvedValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "KillAllProcesses.xaml",
      "resolvedValue": "KillAllProcesses.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "KillAllProcesses.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "resolvedValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Force killing all application processes...&quot;]",
      "resolvedValue": "[&quot;Force killing all application processes...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Force killing all application processes...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;chrome&quot;]",
      "resolvedValue": "[&quot;chrome&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;chrome&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;iexplore&quot;]",
      "resolvedValue": "[&quot;iexplore&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;iexplore&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;EXCEL&quot;]",
      "resolvedValue": "[&quot;EXCEL&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;EXCEL&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All processes terminated&quot;]",
      "resolvedValue": "[&quot;All processes terminated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All processes terminated&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Started ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Started ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Started ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_Config]",
      "resolvedValue": "[io_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 1
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Complete ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Complete ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Complete ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "While",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on While contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PerformerMain.xaml",
      "workflow": "PerformerMain",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "workflow": "InvoiceExtractionAndValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl &amp; \\&quot;/api/invoices?status=submitted&amp;updated_at[gt_or_eq]=\\&quot; &amp; queryFilterUtcStr &amp; \\&quot;&amp;fields=id,invoice_number,vendor_id,vendor_name,pdf_attachment_url,submitted_at&amp;limit=500\\&quot;&quot;}",
      "resolvedValue": "[coupaBaseUrl & \"/api/invoices?status=submitted&updated_at[gt_or_eq]=\" & queryFilterUtcStr & \"&fields=id,invoice_number,vendor_id,vendor_name,pdf_attachment_url,submitted_at&limit=500\"]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaApiResponseJson&quot;}",
      "resolvedValue": "[coupaApiResponseJson]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "InvoiceDispatcher.xaml",
      "workflow": "InvoiceDispatcher",
      "activityType": "ForEach",
      "propertyName": "Values",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaInvoiceList&quot;}]",
      "resolvedValue": "[coupaInvoiceList]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = InCoupaInvoiceId, .CaseStatus = \\&quot;InProgress\\&quot;, .PickedUpUtc = DateTime.UtcNow, .CorrelationId = correlationId}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = InCoupaInvoiceId, .CaseStatus = \"InProgress\", .PickedUpUtc = DateTime.UtcNow, .CorrelationId = correlationId}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;InInvoicePdfUrl&quot;}",
      "resolvedValue": "[InInvoicePdfUrl]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "WaitForFormTask",
      "propertyName": "TaskObject",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resumeTaskObject&quot;}",
      "resolvedValue": "[resumeTaskObject]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;Id\\&quot;, InInvoiceCaseId}, {\\&quot;CaseStatus\\&quot;, \\&quot;Validated\\&quot;}, {\\&quot;ValidatedPONumber\\&quot;, resolvedPoNumber}, {\\&quot;ValidatedInvoiceNumber\\&quot;, resolvedInvoiceNumber}, {\\&quot;ValidatedVendorName\\&quot;, resolvedVendorName}, {\\&quot;ValidatedInvoiceTotal\\&quot;, resolvedTotalAmount}, {\\&quot;ValidatedCurrency\\&quot;, resolvedCurrency}, {\\&quot;ValidatedBy\\&quot;, If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\\&quot;ValidatorUser\\&quot;), CStr(completedTaskData(\\&quot;ValidatorUser\\&quot;)), \\&quot;Unknown\\&quot;)}, {\\&quot;ValidatedUtc\\&quot;, DateTime.UtcNow}, {\\&quot;ValidationOutcome\\&quot;, validationOutcomeRaw}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"Id\", InInvoiceCaseId}, {\"CaseStatus\", \"Validated\"}, {\"ValidatedPONumber\", resolvedPoNumber}, {\"ValidatedInvoiceNumber\", resolvedInvoiceNumber}, {\"ValidatedVendorName\", resolvedVendorName}, {\"ValidatedInvoiceTotal\", resolvedTotalAmount}, {\"ValidatedCurrency\", resolvedCurrency}, {\"ValidatedBy\", If(completedTaskData IsNot Nothing AndAlso completedTaskData.ContainsKey(\"ValidatorUser\"), CStr(completedTaskData(\"ValidatorUser\")), \"Unknown\")}, {\"ValidatedUtc\", DateTime.UtcNow}, {\"ValidationOutcome\", validationOutcomeRaw}}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskFormSchemaPath&quot;}",
      "resolvedValue": "[taskFormSchemaPath]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "workflow": "CreateHumanValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;Id\\&quot;, InInvoiceCaseId}, {\\&quot;CaseStatus\\&quot;, \\&quot;PendingValidation\\&quot;}, {\\&quot;NeedsHumanValidation\\&quot;, True}, {\\&quot;ValidationDueUtc\\&quot;, validationDueUtc}, {\\&quot;ValidationOverdue\\&quot;, False}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"Id\", InInvoiceCaseId}, {\"CaseStatus\", \"PendingValidation\"}, {\"NeedsHumanValidation\", True}, {\"ValidationDueUtc\", validationDueUtc}, {\"ValidationOverdue\", False}}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 1
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaApiEndpoint&quot;}",
      "resolvedValue": "[coupaApiEndpoint]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "workflow": "PurchaseOrderValidation",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poApiResponseBody&quot;}",
      "resolvedValue": "[poApiResponseBody]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaRouteEndpoint&quot;}",
      "resolvedValue": "[coupaRouteEndpoint]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "workflow": "RouteOrRejectInCoupa",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaRejectEndpoint&quot;}",
      "resolvedValue": "[coupaRejectEndpoint]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 1
    }
  ],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "503 required property binding(s) resolved; 142 unresolved required property defect(s); 14 structured expression(s) lowered; 141 invalid generic substitution(s) blocked",
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "InvoiceDispatcher.xaml",
      "preCanonicalizationHash": "3874bf3c898a369aa0781ab40459d5c2ad71a4f901ee7751afcd0eb26dc4740e",
      "canonicalizedHash": "32d4f60fdb5275b0685db48538cfc8a42704fc66dc8a54e5a440f8588c4f11b7",
      "archivedHash": "32d4f60fdb5275b0685db48538cfc8a42704fc66dc8a54e5a440f8588c4f11b7",
      "identical": true,
      "mutated": true
    },
    {
      "file": "PerformerMain.xaml",
      "preCanonicalizationHash": "4530e1e62ac941ce35ce720bb8a33dd05a8656312bc0bc28950fc0ab5acbc6e1",
      "canonicalizedHash": "1a3a841e833e81ecb0474c57aac753c0f19dfecc63f4c944eaf94ae9ca3e8f96",
      "archivedHash": "1a3a841e833e81ecb0474c57aac753c0f19dfecc63f4c944eaf94ae9ca3e8f96",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ProcessTransaction.xaml",
      "preCanonicalizationHash": "0e203932060ea5fe28dde9b171f959dc26be502b324e3690d32ebe0bcd7c64bb",
      "canonicalizedHash": "cd0f32b084c9823df878d6aff90ce377bad81a937a48b0f55cb523a2f77b386d",
      "archivedHash": "cd0f32b084c9823df878d6aff90ce377bad81a937a48b0f55cb523a2f77b386d",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InvoiceExtractionAndValidation.xaml",
      "preCanonicalizationHash": "e53cb91b5669d72d28ae897afe3e4220e64cead186e67b634ab1a03b84aaab9d",
      "canonicalizedHash": "35e06229615c92b79f50c74777947cbbdc28422d0b514b6934ec4735cf3fcc64",
      "archivedHash": "35e06229615c92b79f50c74777947cbbdc28422d0b514b6934ec4735cf3fcc64",
      "identical": true,
      "mutated": true
    },
    {
      "file": "CreateHumanValidationTask.xaml",
      "preCanonicalizationHash": "26bb23c4e28623458c7ffbdba793c9a9b886b2e156620aa826a79a0b4875616d",
      "canonicalizedHash": "884a647a6060b355da0bfe88c9da13f1a9e5c93e2534c23bed6ade344cf8ed9f",
      "archivedHash": "884a647a6060b355da0bfe88c9da13f1a9e5c93e2534c23bed6ade344cf8ed9f",
      "identical": true,
      "mutated": true
    },
    {
      "file": "PurchaseOrderValidation.xaml",
      "preCanonicalizationHash": "00cee57f333f30831bacc39f9f8927ce8cfb441f8e81c40daee15a48e5afea95",
      "canonicalizedHash": "812f8410190037bde95093a54cd25a315fec9eaf1a303db6e13ab4e52a80f15e",
      "archivedHash": "812f8410190037bde95093a54cd25a315fec9eaf1a303db6e13ab4e52a80f15e",
      "identical": true,
      "mutated": true
    },
    {
      "file": "RouteOrRejectInCoupa.xaml",
      "preCanonicalizationHash": "bd03d7cd85ceb090ebe6f733cbc3541039cb5a142294eed52aba23c8a1935f52",
      "canonicalizedHash": "672d666a6ec9e7e61fddc2c3ca91762d29c20370b6b82c0becb34fd6905d0f69",
      "archivedHash": "672d666a6ec9e7e61fddc2c3ca91762d29c20370b6b82c0becb34fd6905d0f69",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Process.xaml",
      "preCanonicalizationHash": "b937791ec6c5f7b2a5e649b31de6e02dd0f22f3e67edc2981a9e523d5c81b167",
      "canonicalizedHash": "b1a0f975df5d84d622ba65595c6541171b63c510540fec1c326eb38e37bf6201",
      "archivedHash": "b1a0f975df5d84d622ba65595c6541171b63c510540fec1c326eb38e37bf6201",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "canonicalizedHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "archivedHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "6b2d04d173a944b5c355b1b537bb85d1b936b44fe91be2f40518cca19f3828bc",
      "canonicalizedHash": "3134bcf289e3f1713a123e1b238f9e7b95b08611c1cdec7d743fee6e3c108002",
      "archivedHash": "3134bcf289e3f1713a123e1b238f9e7b95b08611c1cdec7d743fee6e3c108002",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GetTransactionData.xaml",
      "preCanonicalizationHash": "657b6f45d0ccae4fba10b6e8745ae5083fb7d96c39c048185f2a2e5042f1f299",
      "canonicalizedHash": "657b6f45d0ccae4fba10b6e8745ae5083fb7d96c39c048185f2a2e5042f1f299",
      "archivedHash": "657b6f45d0ccae4fba10b6e8745ae5083fb7d96c39c048185f2a2e5042f1f299",
      "identical": true,
      "mutated": false
    },
    {
      "file": "SetTransactionStatus.xaml",
      "preCanonicalizationHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "canonicalizedHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "archivedHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
      "identical": true,
      "mutated": false
    },
    {
      "file": "CloseAllApplications.xaml",
      "preCanonicalizationHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "canonicalizedHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "archivedHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
      "identical": true,
      "mutated": false
    },
    {
      "file": "KillAllProcesses.xaml",
      "preCanonicalizationHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
      "canonicalizedHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
      "archivedHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Init.xaml",
      "preCanonicalizationHash": "a6f465aa95ed4d9516552abf6798777961a3cd9448fd6638f614cc78ac3ba0c2",
      "canonicalizedHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "archivedHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
      "identical": true,
      "mutated": true
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "CreateHumanValidationTask.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "InitAllSettings.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: AssetName=\"[&quot;Cred_Coupa_API&quot;]"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CreateHumanValidationTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "884a647a6060b355da0bfe88c9da13f1a9e5c93e2534c23bed6ade344cf8ed9f",
        "allowed": true,
        "reason": "Workflow \"CreateHumanValidationTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "657b6f45d0ccae4fba10b6e8745ae5083fb7d96c39c048185f2a2e5042f1f299",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InvoiceDispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "32d4f60fdb5275b0685db48538cfc8a42704fc66dc8a54e5a440f8588c4f11b7",
        "allowed": true,
        "reason": "Workflow \"InvoiceDispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InvoiceExtractionAndValidation.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "35e06229615c92b79f50c74777947cbbdc28422d0b514b6934ec4735cf3fcc64",
        "allowed": true,
        "reason": "Workflow \"InvoiceExtractionAndValidation.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3134bcf289e3f1713a123e1b238f9e7b95b08611c1cdec7d743fee6e3c108002",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "PerformerMain.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "1a3a841e833e81ecb0474c57aac753c0f19dfecc63f4c944eaf94ae9ca3e8f96",
        "allowed": true,
        "reason": "Workflow \"PerformerMain.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1a0f975df5d84d622ba65595c6541171b63c510540fec1c326eb38e37bf6201",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "cd0f32b084c9823df878d6aff90ce377bad81a937a48b0f55cb523a2f77b386d",
        "allowed": true,
        "reason": "Workflow \"ProcessTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "PurchaseOrderValidation.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "812f8410190037bde95093a54cd25a315fec9eaf1a303db6e13ab4e52a80f15e",
        "allowed": true,
        "reason": "Workflow \"PurchaseOrderValidation.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RouteOrRejectInCoupa.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "672d666a6ec9e7e61fddc2c3ca91762d29c20370b6b82c0becb34fd6905d0f69",
        "allowed": true,
        "reason": "Workflow \"RouteOrRejectInCoupa.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "CloseAllApplications.xaml": 1,
      "CreateHumanValidationTask.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InvoiceDispatcher.xaml": 1,
      "InvoiceExtractionAndValidation.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "PerformerMain.xaml": 1,
      "Process.xaml": 1,
      "ProcessTransaction.xaml": 1,
      "PurchaseOrderValidation.xaml": 1,
      "RouteOrRejectInCoupa.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 15,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 15,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "09875fb04edb15996ec75e9d3c8f138fa4ac4f07781a75ad9bb5568eda1956a5",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CreateHumanValidationTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "884a647a6060b355da0bfe88c9da13f1a9e5c93e2534c23bed6ade344cf8ed9f",
        "allowed": true,
        "reason": "Workflow \"CreateHumanValidationTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "657b6f45d0ccae4fba10b6e8745ae5083fb7d96c39c048185f2a2e5042f1f299",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3609e2513b7f215f6c95726cef17a538d604a1a0dcaeaa20b9277d823bd11741",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InvoiceDispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "32d4f60fdb5275b0685db48538cfc8a42704fc66dc8a54e5a440f8588c4f11b7",
        "allowed": true,
        "reason": "Workflow \"InvoiceDispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InvoiceExtractionAndValidation.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "35e06229615c92b79f50c74777947cbbdc28422d0b514b6934ec4735cf3fcc64",
        "allowed": true,
        "reason": "Workflow \"InvoiceExtractionAndValidation.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "6088f10db2d56edbb243ae7615383d9dbe7f6347f5beaa8a825b78b9f4131dca",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3134bcf289e3f1713a123e1b238f9e7b95b08611c1cdec7d743fee6e3c108002",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "PerformerMain.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "1a3a841e833e81ecb0474c57aac753c0f19dfecc63f4c944eaf94ae9ca3e8f96",
        "allowed": true,
        "reason": "Workflow \"PerformerMain.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1a0f975df5d84d622ba65595c6541171b63c510540fec1c326eb38e37bf6201",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "cd0f32b084c9823df878d6aff90ce377bad81a937a48b0f55cb523a2f77b386d",
        "allowed": true,
        "reason": "Workflow \"ProcessTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "PurchaseOrderValidation.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "812f8410190037bde95093a54cd25a315fec9eaf1a303db6e13ab4e52a80f15e",
        "allowed": true,
        "reason": "Workflow \"PurchaseOrderValidation.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RouteOrRejectInCoupa.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "672d666a6ec9e7e61fddc2c3ca91762d29c20370b6b82c0becb34fd6905d0f69",
        "allowed": true,
        "reason": "Workflow \"RouteOrRejectInCoupa.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b748c1650520d30931e19741b75829b2862e4effc65432ce3e9f05bfd4278260",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "CloseAllApplications.xaml": 1,
      "CreateHumanValidationTask.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InvoiceDispatcher.xaml": 1,
      "InvoiceExtractionAndValidation.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "PerformerMain.xaml": 1,
      "Process.xaml": 1,
      "ProcessTransaction.xaml": 1,
      "PurchaseOrderValidation.xaml": 1,
      "RouteOrRejectInCoupa.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 15,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 15,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "workflowAutoWiringDiagnostics": {
    "entries": [
      {
        "file": "InvoiceDispatcher.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:InvoiceDispatcher",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "PerformerMain.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:PerformerMain",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ProcessTransaction.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:ProcessTransaction",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "PerformerMain.xaml",
        "callerCandidates": [
          "PerformerMain.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "PerformerMain.xaml",
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InvoiceExtractionAndValidation.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessTransaction.xaml → spec-decomposition:InvoiceExtractionAndValidation",
        "expectedCaller": "ProcessTransaction.xaml",
        "callerCandidates": [
          "ProcessTransaction.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessTransaction.xaml",
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CreateHumanValidationTask.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessTransaction.xaml → spec-decomposition:CreateHumanValidationTask",
        "expectedCaller": "ProcessTransaction.xaml",
        "callerCandidates": [
          "ProcessTransaction.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessTransaction.xaml",
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "PurchaseOrderValidation.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessTransaction.xaml → spec-decomposition:PurchaseOrderValidation",
        "expectedCaller": "ProcessTransaction.xaml",
        "callerCandidates": [
          "ProcessTransaction.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessTransaction.xaml",
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "RouteOrRejectInCoupa.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:RouteOrRejectInCoupa",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Process.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Process",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllSettings.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:initallsettings",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Init.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Main.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Main",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": null,
        "callerCandidates": [],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "GetTransactionData.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:GetTransactionData",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "SetTransactionStatus.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:SetTransactionStatus",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CloseAllApplications.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:closeallapplications",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "KillAllProcesses.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:killallprocesses",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "CloseAllApplications.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Init.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Init",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      }
    ],
    "summary": {
      "totalGeneratedWorkflows": 7,
      "totalRequiredWorkflows": 11,
      "totalRequiredWorkflowsWired": 11,
      "totalGeneratedButUnwired": 0,
      "totalUnreachableFromMain": 0,
      "totalMissingInvokeEdges": 0,
      "totalCallerMismatchDefects": 2,
      "totalInvokeEmissionFailures": 0
    },
    "activePathProof": {
      "reachabilityComputedOnFinalizedSet": true,
      "reachabilityPruningSkipped": false,
      "wiringComputedOnFinalizedSet": true,
      "workflowSetHashAtWiringTime": "5edbb829dad08d32",
      "workflowSetHashAtReachabilityTime": "5edbb829dad08d32",
      "consistent": true
    }
  },
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 1895,
        "approved": 1895,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 15946,
        "approved": 8594,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 7352
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 15102,
        "approved": 9557,
        "deprecated": 0,
        "nonEmissionApproved": 2970,
        "targetIncompatible": 0,
        "unknown": 2575
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 1019,
        "approved": 872,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 147
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 11,
        "approved": 11,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
