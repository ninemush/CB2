# Diagnostic Summary

## Run Metadata
- **Run ID:** 85d8b2d5-cb32-47b9-92b4-f1c2a8e7ed91
- **Idea ID:** 4e008772-687a-4046-8e1b-472832d1e3ed
- **Status:** completed_with_warnings
- **Generation Mode:** baseline_openable
- **Triggered By:** chat
- **Created At:** Tue Apr 07 2026 03:23:55 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Tue Apr 07 2026 03:33:26 GMT+0000 (Coordinated Universal Time)
- **Duration:** 570.2s

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 18 |
| pipeline_sdd_validation | succeeded | 18 |
| spec_generation | succeeded | 557636 |
| spec_context_loading | succeeded | 4 |
| spec_prompt_assembly | succeeded | 2 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 52172 |
| spec_workflow_detail_InvoiceDispatcher_retry | failed | 0 |
| spec_workflow_detail_InvoiceDispatcher_retry | failed | 0 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 0 |
| spec_handoff | succeeded | 1 |
| build_pipeline | succeeded | 12358 |
| pipeline_build_pipeline | succeeded | 12358 |
| pipeline_decomposition | succeeded | 2 |
| pipeline_pre_complexity_estimation | succeeded | 1 |
| pipeline_workflow_budget_check | succeeded | 1 |
| pipeline_complexity_classification | succeeded | 0 |
| pipeline_xaml_emission | succeeded | 4164 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 48 |
| pipeline_validation | succeeded | 743 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 663 |
| pipeline_packaging_dhg_guide | succeeded | 71 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_complete | succeeded | 0 |

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 19 |
| activity_policy_filter | 9 |
| workflow_analyzer_autofix | 9 |
| expression_lint | 3 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 73
- **Total Warnings:** 38
- **Completeness:** structural

## Meta-Validation Summary

- **Engaged:** true
- **Mode:** Always
- **Corrections Applied:** 1
- **Corrections Skipped:** 1
- **Corrections Failed:** 1
- **Confidence Score:** 0.5294117647058824
- **Duration:** 116ms

## Remediations

- {"level":"validation-finding","file":"InvoiceExtractionAndValidation.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 146: Activity \"DigitizeDocument\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:DigitizeDocument\"","classifiedCheck":"unprefixed-activity","developerAction":"Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InvoiceExtractionAndValidation.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 190: Activity \"ExtractDocumentData\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:ExtractDocumentData\"","classifiedCheck":"unprefixed-activity","developerAction":"Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InvoiceExtractionAndValidation.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 668: Activity \"ValidateDocumentData\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:ValidateDocumentData\"","classifiedCheck":"unprefixed-activity","developerAction":"Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InvoiceExtractionAndValidation.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 748: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in InvoiceExtractionAndValidation.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"PurchaseOrderValidation.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 133: .Trim() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in PurchaseOrderValidation.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"activity","file":"InvoiceExtractionAndValidation.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"value\" in InvoiceExtractionAndValidation.xaml with the appropriate type. Expression context: value","estimatedEffortMinutes":5}
- {"level":"workflow","file":"CreateHumanValidationTask.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in CreateHumanValidationTask.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;Cred_Coupa_API&quot;]","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve malformed_attribute_quoting in InitAllSettings.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"Process.xaml","description":"Stripped 5 placeholder token(s) from Process.xaml","developerAction":"Review Process.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved uweb:HttpClientRequest.EndPoint from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved uweb:DeserializeJson.JsonString from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved uweb:DeserializeJson.JsonObject from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved ForEach.Values from attribute to child-element in InvoiceDispatcher.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InvoiceDispatcher.xaml","description":"Catalog (fallback): Moved uds:QueryEntity.Result from attribute to child-element in InvoiceDispatcher.xaml"}
