# Developer Handoff Guide

**Project:** POInvoiceReconciliation
**Description:** Unattended RPA automation for PO and Invoice Reconciliation. Retrieves vendor PDF invoices from Coupa, extracts structured data via Document Understanding, validates PO number and amount tolerance, then routes or rejects invoices via the Coupa API. Queue-based dispatcher/performer architecture with Orchestrator-managed state and full audit logging.
**Generated:** 2026-03-16
**Architecture:** Sequential (Linear workflow)

**Readiness Score: 81%** | Estimated developer effort: **~6.8 hours** (0 selectors, 0 credentials, 105 min mandatory validation)

---

## 1. Tier 1 — AI Completed (No Human Action Required)

The following items were fully automated by CannonBall. These are verified facts from deterministic analysis.

### Workflow Inventory

**5 XAML workflow(s)** generated containing **0 activities** total.

| # | Workflow File | Purpose | Role |
|---|--------------|---------|------|
| 1 | `Main.xaml` | Entry point workflow | Entry Point |
| 2 | `InvoiceDispatcher.xaml` | Sub-workflow | Sub-workflow |
| 3 | `InvoicePerformer.xaml` | Sub-workflow | Sub-workflow |
| 4 | `ExtractInvoiceData.xaml` | Sub-workflow | Sub-workflow |
| 5 | `ValidatePONumber.xaml` | Sub-workflow | Sub-workflow |

### Workflow Analyzer Compliance

Analyzed 6 workflow file(s) against UiPath Workflow Analyzer rules.

| Rule ID | Rule | Category | Status | Auto-Fixed | Remaining |
|---------|------|----------|--------|------------|----------|
| ST-NMG-001 | Variable naming convention | naming | Auto-Fixed | 2 | 0 |
| ST-NMG-004 | Argument naming convention | naming | Passed | 0 | 0 |
| ST-NMG-009 | Activity must have DisplayName | naming | Passed | 0 | 0 |
| ST-DBP-002 | Empty Catch block | best-practice | Passed | 0 | 0 |
| ST-DBP-006 | Delay activity usage | best-practice | Passed | 0 | 0 |
| ST-DBP-020 | Hardcoded timeout | best-practice | Passed | 0 | 0 |
| ST-DBP-025 | Workflow start/end logging | best-practice | Needs Review | 1 | 1 |
| ST-USG-005 | Unused variable | usage | Needs Review | 0 | 5 |
| ST-USG-017 | Deeply nested If activities | usage | Passed | 0 | 0 |
| ST-SEC-004 | Sensitive data in log message | security | Needs Review | 0 | 5 |
| ST-SEC-005 | Plaintext credential in property | security | Passed | 0 | 0 |
| ST-ARG-001 | Invalid bare Argument tag in Catch | usage | Auto-Fixed | 2 | 0 |
| ST-ARG-002 | Missing declaration for invoked argument | usage | Passed | 0 | 0 |
| ST-ARG-003 | Undeclared variable in expression | usage | Passed | 0 | 0 |

**Result:** 77 of 84 rules passed across 6 workflow files. 5 violation(s) auto-corrected, 11 remaining for review.

**Per-Workflow Breakdown:**

| Workflow | Rules Checked | Passed | Auto-Fixed | Remaining |
|----------|--------------|--------|------------|----------|
| `Main.xaml` | 14 | 14 | 0 | 0 |
| `InvoiceDispatcher.xaml` | 14 | 13 | 0 | 3 |
| `InvoicePerformer.xaml` | 14 | 14 | 0 | 0 |
| `ExtractInvoiceData.xaml` | 14 | 13 | 0 | 1 |
| `ValidatePONumber.xaml` | 14 | 13 | 0 | 1 |
| `InitAllSettings.xaml` | 14 | 10 | 5 | 6 |

### Standards Enforcement

| Standard | What Was Done |
|----------|---------------|
| Naming Conventions | Variables renamed to `{type}_{PascalCase}`, arguments to `{direction}_{PascalCase}` |
| Activity Annotations | Every activity annotated with source step number, business context, and error handling strategy |
| Error Handling | All business activities wrapped in TryCatch with Log + Rethrow; UI activities include RetryScope (3 retries, 5s) |
| Logging | Start/end LogMessage in every workflow; exceptions logged at Error level before rethrow |
| Argument Validation | Entry points validate required arguments at workflow start |

### Architecture Decision

**Sequential Pattern** selected — linear step-by-step flow with step dependencies.

---

## 2. Tier 2 — AI Resolved with Smart Defaults (Review Recommended)

The AI set these values based on SDD analysis. They are likely correct but **must be verified** against your target environment before production use.

---

## 3. Process Logic Validation

Use this section to verify that the generated automation correctly implements the business rules defined in the SDD. Each item below should be confirmed against the live system before UAT.

### Extracted Business Rules — Verification Checklist

The following rules were extracted from the SDD. Verify each is correctly implemented in the generated workflows:

| # | Category | Rule / Requirement | Verified |
|---|----------|-------------------|----------|
| 1 | Threshold / Tolerance | 5% tolerance arithmetic check | [ ] |
| 2 | Approval / Rejection Criteria | RejectInvoice | [ ] |
| 3 | Approval / Rejection Criteria | rejection with reason code | [ ] |
| 4 | Approval / Rejection Criteria | rejection workflows | [ ] |
| 5 | Approval / Rejection Criteria | RejectionCode` (string), `RejectionReason` (string) | [ ] |
| 6 | Approval / Rejection Criteria | reject` with reason payload | [ ] |
| 7 | Approval / Rejection Criteria | RejectionConfirmed` (bool) | [ ] |
| 8 | Approval / Rejection Criteria | RejectionCode`, `VariancePercent`, `ConfidenceScore`, `ProcessingTimestamp` | [ ] |
| 9 | Approval / Rejection Criteria | rejection \| | [ ] |
| 10 | Approval / Rejection Criteria | Reject invoice \| PUT \| `/api/invoices/{id}/reject` \| | [ ] |
| 11 | Approval / Rejection Criteria | approval \| PUT \| `/api/invoices/{id}/submit_for_approval` \| | [ ] |
| 12 | Approval / Rejection Criteria | reject invoice | [ ] |
| 13 | Retry / SLA Requirements | timeout retries ×3 with 5-second backoff | [ ] |
| 14 | Retry / SLA Requirements | retryable), BusinessRuleException (known, non-retryable), SystemException (unknown) | [ ] |
| 15 | Retry / SLA Requirements | retry (max 3 per asset `MaxRetryCount`) | [ ] |
| 16 | Retry / SLA Requirements | retry, logs ERR code | [ ] |
| 17 | Retry / SLA Requirements | retry up to 3 times | [ ] |

---

## 4. Tier 3 — Requires Human Access (Developer Work Required)

These items require a developer with access to target systems and UiPath Studio. **Every generated package requires this work.**

### Business Logic & Manual Steps (5 items)

| # | Category | Activity | Description | Est. Time |
|---|----------|----------|-------------|----------|
| 1 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 2 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 3 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 4 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 5 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |

### Mandatory: Studio Validation & Testing

Every generated package requires these steps regardless of AI enrichment quality:

| # | Task | Description | Est. Time |
|---|------|-------------|----------|
| 1 | Studio Import | Open .nupkg in UiPath Studio. Install missing packages, resolve dependency conflicts, verify project compiles without errors. | 15 min |
| 2 | End-to-End Testing | Execute all 5 workflows in Studio Debug mode against UAT/test environment. Verify queue processing, exception handling, and business rules. | 30 min |
| 3 | UAT Sign-off | Business stakeholder validation with real data and real systems. Confirm outputs match expected results for representative scenarios. | 60 min |

**Total Tier 3 Effort: ~6.8 hours** (0 selectors, 0 credentials, 5 logic items, mandatory validation)

---

## 5. Code Review Checklist

Use this checklist during peer review before promoting to UAT.

### Workflow Analyzer Remaining Violations

| Severity | Rule | File | Message |
|----------|------|------|---------|
| error | ST-SEC-004 | InvoiceDispatcher.xaml | LogMessage may contain sensitive data (matched: "credential") — use SecureString or mask the value |
| error | ST-SEC-004 | InvoiceDispatcher.xaml | LogMessage may contain sensitive data (matched: "token(?!ize)") — use SecureString or mask the value |
| error | ST-SEC-004 | InvoiceDispatcher.xaml | LogMessage may contain sensitive data (matched: "token(?!ize)") — use SecureString or mask the value |
| error | ST-SEC-004 | ExtractInvoiceData.xaml | LogMessage may contain sensitive data (matched: "token(?!ize)") — use SecureString or mask the value |
| error | ST-SEC-004 | ValidatePONumber.xaml | LogMessage may contain sensitive data (matched: "token(?!ize)") — use SecureString or mask the value |
| warning | ST-DBP-025 | InitAllSettings.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "str_ConfigPath" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "str_AssetValue" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "str_TempUser" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "str_SecTempPass" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "drow_RowCurrent" is declared but never used |

### Review Rubric

| Category | Check | Status |
|----------|-------|---------|
| Exception Handling | All activities in TryCatch? Catch blocks log + rethrow? | AI: Done |
| Transaction Integrity | Queue items set to Success/Failed/BusinessException? | N/A |
| Logging | Info log at start/end of each workflow? Critical decisions logged? | AI: Done |
| Selector Reliability | Selectors use stable attributes (automationid, name)? | N/A |
| Credential Security | All credentials in Orchestrator Assets, not hardcoded? | AI: Verified |
| Naming Conventions | Variables/arguments follow type/direction prefixes? | AI: Auto-corrected |
| Annotations | Every activity annotated with business context? | AI: Done |
| Argument Validation | Entry points validate required arguments? | AI: Done |
| Config Management | Environment-specific values in Config.xlsx? | AI: Done |

### Pre-Deployment Verification

1. Open the project in UiPath Studio
2. Run **Analyze File** > **Workflow Analyzer** on all files
3. Confirm zero errors and zero warnings
4. Run all unit tests in Test Manager
5. Execute a full end-to-end run in Dev environment

### Sign-Off

| Field | Value |
|-------|-------|
| Reviewer | _________________ |
| Date | _________________ |
| Approval | [ ] Approved for UAT  [ ] Requires Changes |
| Notes | _________________ |

---

## 6. Package Contents

| File | Purpose |
|------|--------|
| `project.json` | UiPath project manifest with dependencies |
| `Main.xaml` | Entry point workflow |
| `InvoiceDispatcher.xaml` | Workflow: InvoiceDispatcher |
| `InvoicePerformer.xaml` | Workflow: InvoicePerformer |
| `ExtractInvoiceData.xaml` | Workflow: ExtractInvoiceData |
| `ValidatePONumber.xaml` | Workflow: ValidatePONumber |
| `InitAllSettings.xaml` | Configuration initialization |
| `Data/Config.xlsx` | Configuration settings |
| `DeveloperHandoffGuide.md` | This guide |

**Required Packages:** `UiPath.System.Activities`, `UiPath.UIAutomation.Activities`, `UiPath.Web.Activities`, `UiPath.Mail.Activities`, `UiPath.Excel.Activities`

---

## 7. Infrastructure


---

## 8. Go-Live Checklist

#### Development
- [ ] Open project in UiPath Studio — install missing packages
- [ ] Run Workflow Analyzer — confirm zero violations
- [ ] Complete Tier 3 items (selectors, credentials, business logic)
- [ ] Config.xlsx updated with Dev values

#### UAT
- [ ] UAT Orchestrator folder with separate assets/queues
- [ ] Full end-to-end run with real data
- [ ] Business stakeholder sign-off

#### Production
- [ ] Production credentials and assets configured
- [ ] Triggers/schedules active
- [ ] Monitoring and alerting configured
- [ ] Runbook documentation completed
