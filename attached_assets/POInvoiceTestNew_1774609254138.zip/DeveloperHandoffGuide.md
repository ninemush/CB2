# Developer Handoff Guide

**Project:** POInvoiceTestNew
**Description:** Queue-driven unattended automation for Coupa AP invoice pre-approval validation: ingests invoice PDFs via webhook/polling, extracts fields with Document Understanding, performs 2-way PO match with 5% tolerance, routes or rejects in Coupa with supplier messaging, and persists outcomes to Data Service.
**Generated:** 2026-03-27
**Architecture:** Sequential (Linear workflow)

**Readiness Score: 84%** | Estimated developer effort: **~1.8 hours** (0 selectors, 0 credentials, 105 min mandatory validation)

---

## 1. Pipeline Outcome Report

### Fully Generated (1 file(s))

These workflows were generated without any stub replacements or escalation.

- `InitAllSettings.xaml`

### Stubbed — Per-Workflow (1)

Entire workflows were replaced with Studio-openable stubs because per-activity and per-sequence remediation could not resolve the issues.

| # | File | Code | Developer Action | Est. Minutes |
|---|------|------|-----------------|-------------|
| 1 | `Main.xaml` | `STUB_WORKFLOW_BLOCKING` | Fix XML structure in Main.xaml — ensure proper nesting and closing tags | 15 |

**Total estimated developer effort for stubbed items: ~15 minutes (0.3 hours)**

---

## 2. Tier 1 — AI Completed (No Human Action Required)

The following items were fully automated by CannonBall. These are verified facts from deterministic analysis.

### Workflow Inventory

**7 XAML workflow(s)** generated containing **28 activities** total.

| # | Workflow File | Purpose | Role |
|---|--------------|---------|------|
| 1 | `Main.xaml` | Entry point workflow | Entry Point |
| 2 | `Dispatcher.xaml` | Sub-workflow | Sub-workflow |
| 3 | `Performer.xaml` | Sub-workflow | Sub-workflow |
| 4 | `InvoiceExtraction.xaml` | Sub-workflow | Sub-workflow |
| 5 | `HitlValidation.xaml` | Sub-workflow | Sub-workflow |
| 6 | `InvoiceValidation.xaml` | Sub-workflow | Sub-workflow |
| 7 | `CoupaActionExecutor.xaml` | Sub-workflow | Sub-workflow |

### Workflow Analyzer Compliance

Analyzed 4 workflow file(s) against UiPath Workflow Analyzer rules.

| Rule ID | Rule | Category | Status | Auto-Fixed | Remaining |
|---------|------|----------|--------|------------|----------|
| ST-NMG-001 | Variable naming convention | naming | Passed | 0 | 0 |
| ST-NMG-004 | Argument naming convention | naming | Passed | 0 | 0 |
| ST-NMG-009 | Activity must have DisplayName | naming | Passed | 0 | 0 |
| ST-DBP-002 | Empty Catch block | best-practice | Passed | 0 | 0 |
| ST-DBP-006 | Delay activity usage | best-practice | Passed | 0 | 0 |
| ST-DBP-020 | Hardcoded timeout | best-practice | Passed | 0 | 0 |
| ST-DBP-025 | Workflow start/end logging | best-practice | Needs Review | 0 | 4 |
| ST-USG-005 | Unused variable | usage | Needs Review | 0 | 3 |
| ST-USG-017 | Deeply nested If activities | usage | Passed | 0 | 0 |
| ST-SEC-004 | Sensitive data in log message | security | Passed | 0 | 0 |
| ST-SEC-005 | Plaintext credential in property | security | Passed | 0 | 0 |
| ST-ARG-001 | Invalid bare Argument tag in Catch | usage | Passed | 0 | 0 |
| ST-ARG-002 | Missing declaration for invoked argument | usage | Passed | 0 | 0 |
| ST-ARG-003 | Undeclared variable in expression | usage | Passed | 0 | 0 |

**Result:** 51 of 56 rules passed across 4 workflow files. 0 violation(s) auto-corrected, 7 remaining for review.

**Per-Workflow Breakdown:**

| Workflow | Rules Checked | Passed | Auto-Fixed | Remaining |
|----------|--------------|--------|------------|----------|
| `Main.xaml` | 14 | 13 | 0 | 1 |
| `InitAllSettings.xaml` | 14 | 12 | 0 | 4 |
| `Dispatcher.xaml` | 14 | 13 | 0 | 1 |
| `Performer.xaml` | 14 | 13 | 0 | 1 |

### Standards Enforcement

| Standard | What Was Done |
|----------|---------------|
| Naming Conventions | Variables renamed to `{type}_{PascalCase}`, arguments to `{direction}_{PascalCase}` |
| Activity Annotations | Every activity annotated with source step number, business context, and error handling strategy |
| Error Handling | All business activities wrapped in TryCatch with Log + Rethrow; UI activities include RetryScope (3 retries, 5s) |
| Logging | Start/end LogMessage in every workflow; exceptions logged at Error level before rethrow |
| Argument Validation | Entry points validate required arguments at workflow start |

### Architecture Decision

**Sequential Pattern** selected — linear step-by-step flow with step dependencies.

---

## 3. Tier 2 — AI Resolved with Smart Defaults (Review Recommended)

The AI set these values based on SDD analysis. They are likely correct but **must be verified** against your target environment before production use.

---

## 4. Process Logic Validation

Use this section to verify that the generated automation correctly implements the business rules defined in the SDD. Each item below should be confirmed against the live system before UAT.

### Extracted Business Rules — Verification Checklist

The following rules were extracted from the SDD. Verify each is correctly implemented in the generated workflows:

| # | Category | Rule / Requirement | Verified |
|---|----------|-------------------|----------|
| 1 | Threshold / Tolerance | 5% tolerance → supplier message + reject | [ ] |
| 2 | Approval / Rejection Criteria | reject invoice, route/submit for approval—subject to connector operation availability) | [ ] |
| 3 | Approval / Rejection Criteria | Reject invoice | [ ] |
| 4 | Approval / Rejection Criteria | approval (per DOA) | [ ] |
| 5 | Approval / Rejection Criteria | approved Integration Service connector or updating the Coupa connector configuration/o | [ ] |
| 6 | Approval / Rejection Criteria | reject (reason-specific) | [ ] |
| 7 | Approval / Rejection Criteria | RejectionCategory` (MissingPO / PONotFound / Mismatch / Tolerance / CannotDetermine) | [ ] |
| 8 | Retry / SLA Requirements | Retry Scope (where appropriate), Orchestrator HTTP Request (if needed internally), et | [ ] |
| 9 | Retry / SLA Requirements | retries + dead-letter) | [ ] |
| 10 | Retry / SLA Requirements | Retry strategy** | [ ] |
| 11 | Retry / SLA Requirements | retry (MaxRetries e | [ ] |

---

## 5. Tier 3 — Requires Human Access (Developer Work Required)

These items require a developer with access to target systems and UiPath Studio. **Every generated package requires this work.**

### Mandatory: Studio Validation & Testing

Every generated package requires these steps regardless of AI enrichment quality:

| # | Task | Description | Est. Time |
|---|------|-------------|----------|
| 1 | Studio Import | Open .nupkg in UiPath Studio. Install missing packages, resolve dependency conflicts, verify project compiles without errors. | 15 min |
| 2 | End-to-End Testing | Execute all 7 workflows in Studio Debug mode against UAT/test environment. Verify queue processing, exception handling, and business rules. | 30 min |
| 3 | UAT Sign-off | Business stakeholder validation with real data and real systems. Confirm outputs match expected results for representative scenarios. | 60 min |

**Total Tier 3 Effort: ~1.8 hours** (0 selectors, 0 credentials, 0 logic items, mandatory validation)

---

## 6. Code Review Checklist

Use this checklist during peer review before promoting to UAT.

### Workflow Analyzer Remaining Violations

| Severity | Rule | File | Message |
|----------|------|------|---------|
| warning | ST-DBP-025 | Main.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-DBP-025 | InitAllSettings.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "str_ConfigPath" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "sec_TempPass" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "drow_RowCurrent" is declared but never used |
| warning | ST-DBP-025 | Dispatcher.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-DBP-025 | Performer.xaml | Workflow does not contain an initial LogMessage activity |

### Review Rubric

| Category | Check | Status |
|----------|-------|---------|
| Exception Handling | All activities in TryCatch? Catch blocks log + rethrow? | AI: Done |
| Transaction Integrity | Queue items set to Success/Failed/BusinessException? | N/A |
| Logging | Info log at start/end of each workflow? Critical decisions logged? | AI: Done |
| Selector Reliability | Selectors use stable attributes (automationid, name)? | N/A |
| Credential Security | All credentials in Orchestrator Assets, not hardcoded? | AI: Verified |
| Naming Conventions | Variables/arguments follow type/direction prefixes? | AI: Auto-corrected |
| Annotations | Every activity annotated with business context? | AI: Done |
| Argument Validation | Entry points validate required arguments? | AI: Done |
| Config Management | Environment-specific values in Config.xlsx? | AI: Done |

### Pre-Deployment Verification

1. Open the project in UiPath Studio
2. Run **Analyze File** > **Workflow Analyzer** on all files
3. Confirm zero errors and zero warnings
4. Run all unit tests in Test Manager
5. Execute a full end-to-end run in Dev environment

### Sign-Off

| Field | Value |
|-------|-------|
| Reviewer | _________________ |
| Date | _________________ |
| Approval | [ ] Approved for UAT  [ ] Requires Changes |
| Notes | _________________ |

---

## 7. Package Contents

| File | Purpose |
|------|--------|
| `project.json` | UiPath project manifest with dependencies |
| `Main.xaml` | Entry point workflow |
| `Dispatcher.xaml` | Workflow: Dispatcher |
| `Performer.xaml` | Workflow: Performer |
| `InvoiceExtraction.xaml` | Workflow: InvoiceExtraction |
| `HitlValidation.xaml` | Workflow: HitlValidation |
| `InvoiceValidation.xaml` | Workflow: InvoiceValidation |
| `CoupaActionExecutor.xaml` | Workflow: CoupaActionExecutor |
| `InitAllSettings.xaml` | Configuration initialization |
| `Data/Config.xlsx` | Configuration settings |
| `DeveloperHandoffGuide.md` | This guide |

**Required Packages:** `UiPath.System.Activities`, `UiPath.Excel.Activities`, `UiPath.UIAutomation.Activities`

---

## 8. Infrastructure


---

## 9. Go-Live Checklist

#### Development
- [ ] Open project in UiPath Studio — install missing packages
- [ ] Run Workflow Analyzer — confirm zero violations
- [ ] Complete Tier 3 items (selectors, credentials, business logic)
- [ ] Config.xlsx updated with Dev values

#### UAT
- [ ] UAT Orchestrator folder with separate assets/queues
- [ ] Full end-to-end run with real data
- [ ] Business stakeholder sign-off

#### Production
- [ ] Production credentials and assets configured
- [ ] Triggers/schedules active
- [ ] Monitoring and alerting configured
- [ ] Runbook documentation completed


---

# Developer Handoff Guide

**Project:** POInvoiceTestNew
**Generated:** 2026-03-27
**Generation Mode:** Full Implementation
**Deployment Readiness:** Needs Work (60%)

**Total Estimated Effort: ~15 minutes (0.3 hours)**
**Remediations:** 1 total (0 property, 0 activity, 0 sequence, 0 structural-leaf, 1 workflow)
**Auto-Repairs:** 0
**Quality Warnings:** 17

---

## 1. Completed Work

The following 1 workflow(s) were fully generated without any stub replacements or remediation:

- `InitAllSettings.xaml`

### Workflow Inventory

| # | Workflow | Status |
|---|----------|--------|
| 1 | `Main.xaml` | Generated with Placeholders |
| 2 | `Dispatcher.xaml` | Generated with Placeholders |
| 3 | `Performer.xaml` | Generated with Placeholders |
| 4 | `InvoiceExtraction.xaml` | Generated |
| 5 | `HitlValidation.xaml` | Generated |
| 6 | `InvoiceValidation.xaml` | Generated |
| 7 | `CoupaActionExecutor.xaml` | Generated |

## 2. AI-Resolved with Smart Defaults

No auto-repairs were applied.

## 3. Manual Action Required

### Workflow-Level Stubs (1)

Entire workflows were replaced with Studio-openable stubs (XAML was not parseable for structural preservation).

| # | File | Code | Developer Action | Est. Minutes |
|---|------|------|-----------------|-------------|
| 1 | `Main.xaml` | `STUB_WORKFLOW_BLOCKING` | Fix XML structure in Main.xaml — ensure proper nesting and closing tags | 15 |

### Quality Warnings (17)

| # | File | Check | Detail | Developer Action | Est. Minutes |
|---|------|-------|--------|-----------------|-------------|
| 1 | `Main.xaml` | placeholder-value | Contains 2 placeholder value(s) matching "\bTODO\b" | — | undefined |
| 2 | `Dispatcher.xaml` | placeholder-value | Contains 1 placeholder value(s) matching "\bTODO\b" | — | undefined |
| 3 | `Performer.xaml` | placeholder-value | Contains 1 placeholder value(s) matching "\bTODO\b" | — | undefined |
| 4 | `orchestrator` | undeclared-asset | Asset "ProcessingMode" is referenced in XAML but not declared in orchestrator artifacts | — | undefined |
| 5 | `Main.xaml` | potentially-null-dereference | Line 170: "obj_StringComparison.OrdinalIgnoreCase" accessed without visible null guard in scope —... | — | undefined |
| 6 | `Main.xaml` | potentially-null-dereference | Line 170: "obj_StringComparison.OrdinalIgnoreCase" accessed without visible null guard in scope —... | — | undefined |
| 7 | `Main.xaml` | hardcoded-asset-name | Line 113: asset name "ProcessingMode" is hardcoded — consider using a Config.xlsx entry or workfl... | — | undefined |
| 8 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 115: asset name "Coupa.WebhookSharedSecret" is hardcoded — consider using a Config.xlsx entr... | — | undefined |
| 9 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 127: asset name "Coupa.ApiBaseUrl" is hardcoded — consider using a Config.xlsx entry or work... | — | undefined |
| 10 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 134: asset name "Invoice.DU.ConfidenceThreshold" is hardcoded — consider using a Config.xlsx... | — | undefined |
| 11 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 141: asset name "Invoice.TolerancePercent" is hardcoded — consider using a Config.xlsx entry... | — | undefined |
| 12 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 148: asset name "Orchestrator.StorageBucketName" is hardcoded — consider using a Config.xlsx... | — | undefined |
| 13 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 155: asset name "Processing.MaxApiRetries" is hardcoded — consider using a Config.xlsx entry... | — | undefined |
| 14 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 162: asset name "Processing.RetryBackoffSeconds" is hardcoded — consider using a Config.xlsx... | — | undefined |
| 15 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 169: asset name "ActionCenter.ValidationSLAHours" is hardcoded — consider using a Config.xls... | — | undefined |
| 16 | `InitAllSettings.xaml` | CATALOG_VIOLATION | Missing required property "WorkbookPath" on uexcel:ExcelApplicationScope | — | undefined |
| 17 | `InitAllSettings.xaml` | CATALOG_VIOLATION | Missing required property "DataTable" on uexcel:ExcelReadRange | — | undefined |

**Total manual remediation effort: ~15 minutes (0.3 hours)**

## 4. Process Context (from Pipeline)

### Idea Description

automate PO and Invoice matching

### PDD Summary

## 1. Executive Summary
The “PO Invoice test_new” project automates the Accounts Payable (AP) pre-approval validation of vendor invoices submitted in Coupa as PDFs. Today, AP processors manually open each invoice, confirm the PO exists in Coupa, perform a 2‑way match (Invoice vs PO) on vendor/lines/totals, validate that the invoice amount falls within a 5% tolerance, and then route the invoice through Coupa’s Delegation of Authority (DOA) approval chain. If any validation fails, AP rejects the invoice in Coupa and communicates correction requirements to the supplier using Coupa Supplier Messaging; suppliers then resubmit as a brand-new invoice. The process runs approximately 50 invoices per day and averages ~10 minutes per invoice.

The to-be solution uses UiPath Orchestrator (queues/triggers), Integration Service (Coupa connectivity and webhook), Document Understanding (PDF extraction), Action Center (human-in-the-loop for low confidence extraction), and rule-based validation to autonomously execute the same checks at scale. The process ends at either invoice rejection in Coupa (with supplier messaging) or successful routing and approval/progression per DOA, aligning with the current operational boundary.

## 2. Process Scope
This PDD covers the end-to-end flow from the moment a supplier submits an invoice PDF in Coupa through to one of two outcomes: (1) the invoice is rejected in Coupa (with supplier notified via Coupa Supplier Messaging) and the supplier resubmits as a new submission, or (2) the invoice is routed for approval and approved/progressed to the next stage in Coupa. The automation scope includes ingestion of new invoice events, retrieval of invoice PDF and metadata, extraction of key invoice fields, PO retrieval from Coupa, 2‑way match validation (Invoice vs PO), 5% tolerance validation, Coupa Supplier Messaging for discrepancy communications, and automated rejection/routing actions in Coupa.

Out of scope are downstream AP activities after “Approved &...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Pattern:** **Queue-driven dispatcher–performer with Human-in-the-Loop (Hybrid)**

- **Why RPA/Workflow (unattended) vs Agent:** The validation logic is deterministic (PO exists, 2‑way match, 5% tolerance) and the primary integrations are API-based in Coupa. This is best served by **unattended workflows** with strong retry/observability.  
- **Where AI adds value (Hybrid):** The non-deterministic part is **data extraction from heterogeneous invoice PDFs**. We use **Document Understanding + Generative Extraction** for resilient field extraction and **Action Center** only when confidence/validation fails.  
- **Why not an Agent-first solution:** Agents are detected with limited reachability. Also, continuous high-volume background execution (≈50/day) and strict operational outcomes (reject vs route) require predictable orchestration, retries, and queue SLAs—best delivered by Orchestrator + queues. Agents can be added later for enriched supplier messaging or exception triage, but not as a critical-path dependency.

[AUTOMATION_TYPE: HYBRID (Unattended RPA + Document Understanding + Action Center HITL)]

### 1.2 Core platform services used (and why)
- **Orchestrator (Queues, Triggers, Processes, Assets):** Primary workload management; supports horizontal scaling across **12 unattended slots**, controlled retries, and SLA-based monitoring.
- **Integration Service (Coupa connector + HTTP Webhook connection):** Mandatory for system connectivity. Used for Coupa invoice/PO retrieval, supplier messaging, reject/routing actions, and webhook ingestion (event-driven start).
- **Document Understanding + Generative Extraction:** Extract PO number, vendor, invoice number, totals, line items from PDFs. Generative Extraction improves robustness on variable invoice templates where classic extractors may be brittle.
- **Action Center + Persistence:** Human validation only when extraction confidence is...

**Automation Type:** rpa
**Rationale:** The process is deterministic (2‑way match + 5% tolerance) on structured Coupa data with repeatable routing/actions at ~50/day; exceptions follow a fixed reject path, so traditional unattended RPA with API/connector integration is the best fit.
**Feasibility Complexity:** medium
**Effort Estimate:** 2-4 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | Invoice Submitted in Coupa | Vendor | Coupa | start | — |
| 2 | Ingest New Invoice Event & Create Work Item | System | Orchestrator Queue | task | — |
| 3 | Retrieve Invoice PDF + Header Data from Coupa | System | Integration Service (HTTP Webhook connection "Whatapp_Webhook" or Coupa API via connector) | task | — |
| 4 | Extract Key Fields from Invoice PDF (PO#, vendor, invoice#, amount, line totals) | System | Document Understanding (Classic DU) | task | — |
| 5 | Extraction Confidence Sufficient? | System | Document Understanding | decision | — |
| 6 | Send to AP for Review/Correction | AP Processor | Action Center | task | — |
| 7 | Apply AP Corrections to Work Item | System | Action Center | task | — |
| 8 | Retrieve PO Details from Coupa (vendor, lines, totals) | System | Integration Service (Coupa API via connector) | task | — |
| 9 | Retrieve PO Details from Coupa (vendor, lines, totals) | System | Integration Service (Coupa API via connector) | task | — |
| 10 | PO Number Present & Found in Coupa? | System | Coupa | decision | — |
| 11 | PO Number Present & Found in Coupa? | System | Coupa | decision | — |
| 12 | Validate Invoice vs PO (2-way match: vendor, lines, totals) | System | Automation (rules) | task | — |
| 13 | Post Supplier Message: PO Not Found / Missing PO | System | Coupa Supplier Messaging | task | — |
| 14 | Reject Invoice in Coupa (supplier to resubmit) | System | Coupa | task | — |
| 15 | Invoice Rejected End | System | Coupa | end | — |
| 16 | Match Passes (Vendor/Lines/Totals)? | System | Automation (rules) | decision | — |
| 17 | Amount Within 5% Tolerance vs PO? | System | Automation (rules) | decision | — |
| 18 | Post Supplier Message: PO Mismatch Details | System | Coupa Supplier Messaging | task | — |
| 19 | Reject Invoice in Coupa (supplier to resubmit) | System | Coupa | task | — |
| 20 | Post Supplier Message: Amount Outside 5% Tolerance | System | Coupa Supplier Messaging | task | — |
| 21 | Reject Invoice in Coupa (supplier to resubmit) | System | Coupa | task | — |
| 22 | Route Invoice for Approval per DOA in Coupa | System | Coupa | task | — |
| 23 | Approved in Coupa? | System | Coupa | decision | — |
| 24 | Mark Invoice as Approved/Progressed | System | Data Service | task | — |
| 25 | Approved & Progressed to Next Stage End | System | Coupa | end | — |
| 26 | Post Supplier Message: Invoice Not Approved (Rejected in Approval) | System | Coupa Supplier Messaging | task | — |
| 27 | Reject Invoice in Coupa (supplier to resubmit) | System | Coupa | task | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Coupa
- Orchestrator Queue
- Integration Service (HTTP Webhook connection "Whatapp_Webhook" or Coupa API via connector)
- Document Understanding (Classic DU)
- Document Understanding
- Action Center
- Integration Service (Coupa API via connector)
- Automation (rules)
- Coupa Supplier Messaging
- Data Service

### User Roles Involved

- Vendor
- System
- AP Processor

### Decision Points (Process Map Topology)

**Extraction Confidence Sufficient?**
  - [No] → Send to AP for Review/Correction
  - [Yes] → Retrieve PO Details from Coupa (vendor, lines, totals)

**PO Number Present & Found in Coupa?**
  - [Yes] → Validate Invoice vs PO (2-way match: vendor, lines, totals)
  - [No] → Post Supplier Message: PO Not Found / Missing PO

**PO Number Present & Found in Coupa?**
  - [→] → Invoice Rejected End

**Match Passes (Vendor/Lines/Totals)?**
  - [Yes] → Amount Within 5% Tolerance vs PO?
  - [No] → Post Supplier Message: PO Mismatch Details

**Amount Within 5% Tolerance vs PO?**
  - [No] → Post Supplier Message: Amount Outside 5% Tolerance
  - [Yes] → Route Invoice for Approval per DOA in Coupa

**Approved in Coupa?**
  - [Yes] → Mark Invoice as Approved/Progressed
  - [No] → Post Supplier Message: Invoice Not Approved (Rejected in Approval)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.0 |
| Orchestrator Connection | Required |
| Machine Template | Standard |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with at least one unattended robot assignment. Use folder-level credential stores for asset isolation.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.Excel.Activities` |
| 3 | `UiPath.UIAutomation.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Coupa
- Orchestrator Queue
- Integration Service (HTTP Webhook connection "Whatapp_Webhook" or Coupa API via connector)
- Document Understanding (Classic DU)
- Document Understanding
- Action Center
- Integration Service (Coupa API via connector)
- Automation (rules)
- Coupa Supplier Messaging
- Data Service

## 7. Credential & Asset Inventory

**Total:** 17 activities (8 hardcoded, 9 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `Coupa.WebhookSharedSecret` | Credential | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `Coupa.ApiBaseUrl` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 2 | `Invoice.DU.ConfidenceThreshold` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 3 | `Invoice.TolerancePercent` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 4 | `Orchestrator.StorageBucketName` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 5 | `Processing.MaxApiRetries` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 6 | `Processing.RetryBackoffSeconds` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 7 | `ActionCenter.ValidationSLAHours` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `InitAllSettings.xaml` | 115 | GetCredential | `Coupa.WebhookSharedSecret` | Credential | — | Yes |
| `InitAllSettings.xaml` | 116 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 119 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 127 | GetAsset | `Coupa.ApiBaseUrl` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 128 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 134 | GetAsset | `Invoice.DU.ConfidenceThreshold` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 135 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 141 | GetAsset | `Invoice.TolerancePercent` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 142 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 148 | GetAsset | `Orchestrator.StorageBucketName` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 149 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 155 | GetAsset | `Processing.MaxApiRetries` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 156 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 162 | GetAsset | `Processing.RetryBackoffSeconds` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 163 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 169 | GetAsset | `ActionCenter.ValidationSLAHours` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 170 | GetAsset | `UNKNOWN` | Unknown | — | No |

> **Warning:** 8 asset/credential name(s) are hardcoded. Consider externalizing to Orchestrator Config assets for environment portability.

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 8 aligned, 1 SDD-only, 0 XAML-only

> **Warning:** 1 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `Coupa.ApiBaseUrl` | asset | **Aligned** | type: Text, value: https://<your-coupa-tenant>, description: Coupa tenant base URL used by Integration Service/API calls. | `InitAllSettings.xaml` | 127 |
| 2 | `Coupa.WebhookSharedSecret` | credential | **Aligned** | type: Credential, description: Secret used to validate inbound Coupa webhook signatures (if enabled) before creating queue items. | `InitAllSettings.xaml` | 115 |
| 3 | `Invoice.DU.ConfidenceThreshold` | asset | **Aligned** | type: Integer, value: 85, description: Minimum confidence (0-100) per critical DU field before routing to Action Center validation. | `InitAllSettings.xaml` | 134 |
| 4 | `Invoice.TolerancePercent` | asset | **Aligned** | type: Integer, value: 5, description: Invoice vs PO tolerance percentage for total amount validation. | `InitAllSettings.xaml` | 141 |
| 5 | `Orchestrator.StorageBucketName` | asset | **Aligned** | type: Text, value: SB_Coupa_POInvoice_PDF, description: Storage Bucket name used to store invoice PDFs and extraction snapshots. | `InitAllSettings.xaml` | 148 |
| 6 | `Processing.MaxApiRetries` | asset | **Aligned** | type: Integer, value: 3, description: Maximum retry attempts for transient Coupa/API failures within a single transaction. | `InitAllSettings.xaml` | 155 |
| 7 | `Processing.RetryBackoffSeconds` | asset | **Aligned** | type: Integer, value: 30, description: Backoff (seconds) between transient API retry attempts. | `InitAllSettings.xaml` | 162 |
| 8 | `ActionCenter.ValidationSLAHours` | asset | **Aligned** | type: Integer, value: 24, description: Target SLA (hours) for AP to complete DU validation tasks in Action Center. | `InitAllSettings.xaml` | 169 |
| 9 | `Q_Coupa_POInvoice_PreApproval` | queue | **SDD Only** | maxRetries: 5, uniqueReference: true, description: Queue of Coupa supplier invoice submissions (PDF) to be validated against Coupa POs (2-way match + 5% tolerance) and then rejected or routed for DOA approval. | — | — |

## 9. Queue Management

No queue activities detected in the package.

## 10. Exception Handling Coverage

**Coverage:** 0/17 high-risk activities inside TryCatch (0%)

### Files Without TryCatch

- `Main.xaml`
- `InitAllSettings.xaml`
- `Dispatcher.xaml`
- `Performer.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:115` | Get Coupa.WebhookSharedSecret |
| 2 | `InitAllSettings.xaml:116` | ui:GetCredential |
| 3 | `InitAllSettings.xaml:119` | ui:GetCredential |
| 4 | `InitAllSettings.xaml:127` | Get Coupa.ApiBaseUrl |
| 5 | `InitAllSettings.xaml:128` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:134` | Get Invoice.DU.ConfidenceThreshold |
| 7 | `InitAllSettings.xaml:135` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:141` | Get Invoice.TolerancePercent |
| 9 | `InitAllSettings.xaml:142` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:148` | Get Orchestrator.StorageBucketName |
| 11 | `InitAllSettings.xaml:149` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:155` | Get Processing.MaxApiRetries |
| 13 | `InitAllSettings.xaml:156` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:162` | Get Processing.RetryBackoffSeconds |
| 15 | `InitAllSettings.xaml:163` | ui:GetAsset |
| 16 | `InitAllSettings.xaml:169` | Get ActionCenter.ValidationSLAHours |
| 17 | `InitAllSettings.xaml:170` | ui:GetAsset |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Queue** | Defined in SDD orchestrator_artifacts: TRG_CoupaWebhook_ToQueue_Q_Coupa_POInvoice_PreApproval | SDD-specified: TRG_CoupaWebhook_ToQueue_Q_Coupa_POInvoice_PreApproval | Queue: Q_Coupa_POInvoice_PreApproval | Queue trigger to start processing as soon as webhook-ingested items are added to the queue. |
| 2 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_SafetyNet_Polling_Ingestion_Daily | SDD-specified: TRG_SafetyNet_Polling_Ingestion_Daily | Cron: 0 0 2 ? * MON-SUN * | Time trigger to run ingestion polling once daily as a fallback when webhooks are unavailable; creates items in Q_Coupa_POInvoice_PreApproval. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| undefined | warning | 17 |  |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `Coupa.WebhookSharedSecret` | Yes |
| 5 | Assets | Provision asset: `Coupa.ApiBaseUrl` | Yes |
| 6 | Assets | Provision asset: `Invoice.DU.ConfidenceThreshold` | Yes |
| 7 | Assets | Provision asset: `Invoice.TolerancePercent` | Yes |
| 8 | Assets | Provision asset: `Orchestrator.StorageBucketName` | Yes |
| 9 | Assets | Provision asset: `Processing.MaxApiRetries` | Yes |
| 10 | Assets | Provision asset: `Processing.RetryBackoffSeconds` | Yes |
| 11 | Assets | Provision asset: `ActionCenter.ValidationSLAHours` | Yes |
| 12 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 13 | Testing | Run smoke test in target environment | Yes |
| 14 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 15 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 16 | Governance | Peer code review completed | Yes |
| 17 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 18 | Governance | Business process owner validation obtained | Yes |
| 19 | Governance | CoE approval obtained | Yes |
| 20 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Needs Work — 30/50 (60%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 5/10 | 8 hardcoded asset name(s) — use Orchestrator assets/config |
| Exception Handling | 2/10 | Only 0% of high-risk activities covered by TryCatch; 4 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | No queue activities — section not applicable |
| Build Quality | 3/10 | 17 quality warnings — significant remediation needed; 1 remediation(s) to complete |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Action Required:** Address the items above before deploying to production. Focus on sections with the lowest scores first.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 21 |
| Valid activities | 21 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 8 |
| Enum values auto-corrected | 5 |
| Missing required props filled | 2 |
| Total issues | 13 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 15 auto-fixed, 13 total issues |
| Post-emission (quality gate) | 18 warnings/remediations |

---

## 16. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "InitAllSettings.xaml"
  ],
  "autoRepairs": [],
  "remediations": [
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in Main.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "Main.xaml",
      "detail": "Contains 2 placeholder value(s) matching \"\\bTODO\\b\"",
      "severity": "warning"
    },
    {
      "check": "placeholder-value",
      "file": "Dispatcher.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\"",
      "severity": "warning"
    },
    {
      "check": "placeholder-value",
      "file": "Performer.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\"",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"ProcessingMode\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "potentially-null-dereference",
      "file": "Main.xaml",
      "detail": "Line 170: \"obj_StringComparison.OrdinalIgnoreCase\" accessed without visible null guard in scope — verify null check exists in enclosing If/TryCatch",
      "severity": "warning"
    },
    {
      "check": "potentially-null-dereference",
      "file": "Main.xaml",
      "detail": "Line 170: \"obj_StringComparison.OrdinalIgnoreCase\" accessed without visible null guard in scope — verify null check exists in enclosing If/TryCatch",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 113: asset name \"ProcessingMode\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 115: asset name \"Coupa.WebhookSharedSecret\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 127: asset name \"Coupa.ApiBaseUrl\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 134: asset name \"Invoice.DU.ConfidenceThreshold\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 141: asset name \"Invoice.TolerancePercent\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 148: asset name \"Orchestrator.StorageBucketName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 155: asset name \"Processing.MaxApiRetries\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 162: asset name \"Processing.RetryBackoffSeconds\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 169: asset name \"ActionCenter.ValidationSLAHours\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "CATALOG_VIOLATION",
      "file": "InitAllSettings.xaml",
      "detail": "Missing required property \"WorkbookPath\" on uexcel:ExcelApplicationScope",
      "severity": "warning"
    },
    {
      "check": "CATALOG_VIOLATION",
      "file": "InitAllSettings.xaml",
      "detail": "Missing required property \"DataTable\" on uexcel:ExcelReadRange",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 15,
  "preEmissionValidation": {
    "totalActivities": 21,
    "validActivities": 21,
    "unknownActivities": 0,
    "strippedProperties": 8,
    "enumCorrections": 5,
    "missingRequiredFilled": 2,
    "commentConversions": 0,
    "issueCount": 13
  }
}
```
