# Developer Handoff Guide

**Project:** WeatherAndTravelNotification
**Description:** Unattended RPA automation that executes every weekday at 6:45am to retrieve live weather data, TfL Underground line status, and National Rail C2C service status, then composes and delivers a formatted HTML commute intelligence email to Yusuf.yasin@uipath.com before 7am departure.
**Generated:** 2026-03-18
**Architecture:** REFramework (Queue-based transactional)
**Generation Mode:** Full Implementation
**Mode Reason:** Pattern "transactional-queue" supports full implementation with REFramework
**Stubbed Workflows:** 4 workflow(s) replaced with Studio-openable stubs due to blocking issues

**Readiness Score: 82%** | Estimated developer effort: **~7.0 hours** (0 selectors, 3 credentials, 105 min mandatory validation)

---

## 1. Quality Gate Results

### Blocking Issues (9)

These issues caused specific workflows to fall back to Studio-openable stubs. The stubs are valid XAML and can be opened in Studio, but require manual implementation.

| # | File | Check | Detail |
|---|------|-------|---------|
| 1 | `GetWeatherData.xaml` | missing-package-dep | Activity "ui:HttpClient" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 2 | `GetWeatherData.xaml` | missing-package-dep | Activity "ui:DeserializeJSON" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 3 | `GetTfLStatus.xaml` | missing-package-dep | Activity "ui:HttpClient" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 4 | `GetTfLStatus.xaml` | missing-package-dep | Activity "ui:DeserializeJSON" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 5 | `GetC2CStatus.xaml` | missing-package-dep | Activity "ui:HttpClient" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 6 | `GetC2CStatus.xaml` | missing-package-dep | Activity "ui:DeserializeJSON" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 7 | `InitAllSettings.xaml` | missing-package-dep | Activity "ui:ExcelApplicationScope" requires package "UiPath.Excel.Activities" which is not in project.json dependencies |
| 8 | `InitAllSettings.xaml` | missing-package-dep | Activity "ui:ExcelReadRange" requires package "UiPath.Excel.Activities" which is not in project.json dependencies |
| 9 | `InitAllSettings.xaml` | missing-package-dep | Activity "ui:ExcelReadRange" requires package "UiPath.Excel.Activities" which is not in project.json dependencies |

**Stubbed Workflows:** `GetWeatherData.xaml`, `GetTfLStatus.xaml`, `GetC2CStatus.xaml`, `InitAllSettings.xaml`

> These stubs contain a LogMessage indicating manual implementation is needed. They are correctly wired into the project with valid InvokeWorkflowFile references.

### Warnings (83)

These are minor issues that do not prevent the package from being opened or used. They represent areas where a developer can improve the generated output.

| # | File | Check | Detail |
|---|------|-------|---------|
| 1 | `Main.xaml` | hardcoded-credential | Potential hardcoded credential detected (pattern: password\s*[:=]\s*["'](?!\[)[^...) |
| 2 | `ComposeEmail.xaml` | placeholder-value | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" |
| 3 | `SendEmail.xaml` | placeholder-value | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" |
| 4 | `LogResult.xaml` | placeholder-value | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" |
| 5 | `orchestrator` | undeclared-asset | Asset "Gmail_Credentials" is referenced in XAML but not declared in orchestrator artifacts |
| 6 | `orchestrator` | undeclared-asset | Asset "Max_Retry_Attempts" is referenced in XAML but not declared in orchestrator artifacts |
| 7 | `orchestrator` | undeclared-asset | Asset "Retry_Delay_Seconds" is referenced in XAML but not declared in orchestrator artifacts |
| 8 | `Main.xaml` | invalid-activity-property | Line 57: property "Main" is not a known property of ui:LogMessage |
| 9 | `Main.xaml` | invalid-activity-property | Line 657: property "EmailSent" is not a known property of ui:LogMessage |
| 10 | `Main.xaml` | invalid-activity-property | Line 657: property "Recommendation" is not a known property of ui:LogMessage |
| 11 | `Main.xaml` | invalid-activity-property | Line 657: property "Warnings" is not a known property of ui:LogMessage |
| 12 | `Main.xaml` | invalid-activity-property | Line 658: property "Main" is not a known property of ui:LogMessage |
| 13 | `Main.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 14 | `GetWeatherData.xaml` | invalid-activity-property | Line 62: property "GetWeatherData" is not a known property of ui:LogMessage |
| 15 | `GetWeatherData.xaml` | invalid-activity-property | Line 63: property "lat" is not a known property of ui:Assign |
| 16 | `GetWeatherData.xaml` | invalid-activity-property | Line 63: property "lon" is not a known property of ui:Assign |
| 17 | `GetWeatherData.xaml` | invalid-activity-property | Line 63: property "appid" is not a known property of ui:Assign |
| 18 | `GetWeatherData.xaml` | invalid-activity-property | Line 63: property "units" is not a known property of ui:Assign |
| 19 | `GetWeatherData.xaml` | invalid-activity-property | Line 178: property "EndpointUrl" is not a known property of ui:HttpClient |
| 20 | `GetWeatherData.xaml` | invalid-activity-property | Line 178: property "ResponseStatusCode" is not a known property of ui:HttpClient |
| 21 | `GetWeatherData.xaml` | invalid-activity-property | Line 178: property "Timeout" is not a known property of ui:HttpClient |
| 22 | `GetWeatherData.xaml` | invalid-activity-property | Line 234: property "Input" is not a known property of ui:DeserializeJSON |
| 23 | `GetWeatherData.xaml` | invalid-activity-property | Line 292: property "GetWeatherData" is not a known property of ui:LogMessage |
| 24 | `GetWeatherData.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 25 | `GetTfLStatus.xaml` | invalid-activity-property | Line 63: property "GetTfLStatus" is not a known property of ui:LogMessage |
| 26 | `GetTfLStatus.xaml` | invalid-activity-property | Line 179: property "EndpointUrl" is not a known property of ui:HttpClient |
| 27 | `GetTfLStatus.xaml` | invalid-activity-property | Line 179: property "ResponseStatusCode" is not a known property of ui:HttpClient |
| 28 | `GetTfLStatus.xaml` | invalid-activity-property | Line 179: property "Timeout" is not a known property of ui:HttpClient |
| 29 | `GetTfLStatus.xaml` | invalid-activity-property | Line 235: property "Input" is not a known property of ui:DeserializeJSON |
| 30 | `GetTfLStatus.xaml` | invalid-activity-property | Line 305: property "GetTfLStatus" is not a known property of ui:LogMessage |
| 31 | `GetTfLStatus.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 32 | `GetC2CStatus.xaml` | invalid-activity-property | Line 63: property "GetC2CStatus" is not a known property of ui:LogMessage |
| 33 | `GetC2CStatus.xaml` | invalid-activity-property | Line 179: property "EndpointUrl" is not a known property of ui:HttpClient |
| 34 | `GetC2CStatus.xaml` | invalid-activity-property | Line 179: property "ResponseStatusCode" is not a known property of ui:HttpClient |
| 35 | `GetC2CStatus.xaml` | invalid-activity-property | Line 179: property "Timeout" is not a known property of ui:HttpClient |
| 36 | `GetC2CStatus.xaml` | invalid-activity-property | Line 235: property "Input" is not a known property of ui:DeserializeJSON |
| 37 | `GetC2CStatus.xaml` | invalid-activity-property | Line 306: property "GetC2CStatus" is not a known property of ui:LogMessage |
| 38 | `GetC2CStatus.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 39 | `BuildRouteRecommendation.xaml` | invalid-activity-property | Line 56: property "BuildRouteRecommendation" is not a known property of ui:LogMessage |
| 40 | `BuildRouteRecommendation.xaml` | invalid-activity-property | Line 57: property "BuildRouteRecommendation" is not a known property of ui:LogMessage |
| 41 | `BuildRouteRecommendation.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 42 | `InitAllSettings.xaml` | invalid-activity-property | Line 119: property "InitAllSettings" is not a known property of ui:LogMessage |
| 43 | `InitAllSettings.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 44 | `ComposeEmail.xaml` | invalid-activity-property | Line 56: property "ComposeEmail" is not a known property of ui:LogMessage |
| 45 | `ComposeEmail.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 46 | `SendEmail.xaml` | invalid-activity-property | Line 56: property "SendEmail" is not a known property of ui:LogMessage |
| 47 | `SendEmail.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 48 | `LogResult.xaml` | invalid-activity-property | Line 56: property "LogResult" is not a known property of ui:LogMessage |
| 49 | `LogResult.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 50 | `Main.xaml` | hardcoded-asset-name | Line 63: asset name "WeatherAPI_Key" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 51 | `Main.xaml` | hardcoded-asset-name | Line 102: asset name "NationalRail_ApiKey" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 52 | `Main.xaml` | hardcoded-asset-name | Line 141: asset name "Gmail_Credentials" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 53 | `Main.xaml` | hardcoded-asset-name | Line 180: asset name "Recipient_Email" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 54 | `Main.xaml` | hardcoded-asset-name | Line 219: asset name "Home_Lat" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 55 | `Main.xaml` | hardcoded-asset-name | Line 258: asset name "Home_Lon" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 56 | `Main.xaml` | hardcoded-asset-name | Line 297: asset name "Max_Retry_Attempts" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 57 | `Main.xaml` | hardcoded-asset-name | Line 336: asset name "Retry_Delay_Seconds" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 58 | `GetWeatherData.xaml` | hardcoded-retry-count | Line 123: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| 59 | `GetWeatherData.xaml` | hardcoded-retry-count | Line 175: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| 60 | `GetWeatherData.xaml` | hardcoded-retry-interval | Line 123: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| 61 | `GetWeatherData.xaml` | hardcoded-retry-interval | Line 126: retry interval hardcoded as "TimeSpan.FromSeconds(in_RetryDelay)" — consider externalizing to Config.xlsx |
| 62 | `GetWeatherData.xaml` | hardcoded-retry-interval | Line 175: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| 63 | `GetWeatherData.xaml` | hardcoded-time-interval | Line 178: time interval "Timeout=00:30" is hardcoded — consider externalizing to Config.xlsx |
| 64 | `GetTfLStatus.xaml` | hardcoded-retry-count | Line 124: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| 65 | `GetTfLStatus.xaml` | hardcoded-retry-count | Line 176: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| 66 | `GetTfLStatus.xaml` | hardcoded-retry-interval | Line 124: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| 67 | `GetTfLStatus.xaml` | hardcoded-retry-interval | Line 127: retry interval hardcoded as "TimeSpan.FromSeconds(in_RetryDelay)" — consider externalizing to Config.xlsx |
| 68 | `GetTfLStatus.xaml` | hardcoded-retry-interval | Line 176: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| 69 | `GetTfLStatus.xaml` | hardcoded-time-interval | Line 179: time interval "Timeout=00:30" is hardcoded — consider externalizing to Config.xlsx |
| 70 | `GetC2CStatus.xaml` | hardcoded-retry-count | Line 124: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| 71 | `GetC2CStatus.xaml` | hardcoded-retry-count | Line 176: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| 72 | `GetC2CStatus.xaml` | hardcoded-retry-interval | Line 124: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| 73 | `GetC2CStatus.xaml` | hardcoded-retry-interval | Line 127: retry interval hardcoded as "TimeSpan.FromSeconds(in_RetryDelay)" — consider externalizing to Config.xlsx |
| 74 | `GetC2CStatus.xaml` | hardcoded-retry-interval | Line 176: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| 75 | `GetC2CStatus.xaml` | hardcoded-time-interval | Line 179: time interval "Timeout=00:30" is hardcoded — consider externalizing to Config.xlsx |
| 76 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 88: asset name "WeatherAPI_Key" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 77 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 93: asset name "Gmail_AppPassword" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 78 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 98: asset name "NationalRail_ApiKey" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 79 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 103: asset name "Gmail_Username" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 80 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 104: asset name "Recipient_Email" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 81 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 105: asset name "Home_Lat" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 82 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 106: asset name "Home_Lon" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 83 | `DeveloperHandoffGuide.md` | archive-parity-missing-artifact | Expected artifact "DeveloperHandoffGuide.md" is not present in the archive manifest |

---

## 2. Tier 1 — AI Completed (No Human Action Required)

The following items were fully automated by CannonBall. These are verified facts from deterministic analysis.

### Workflow Inventory

**10 XAML workflow(s)** generated containing **0 activities** total.

| # | Workflow File | Purpose | Role |
|---|--------------|---------|------|
| 1 | `Main.xaml` | REFramework State Machine entry point | Entry Point |
| 2 | `GetTransactionData.xaml` | Sub-workflow | Sub-workflow |
| 3 | `Process.xaml` | Sub-workflow | Sub-workflow |
| 4 | `SetTransactionStatus.xaml` | Sub-workflow | Sub-workflow |
| 5 | `CloseAllApplications.xaml` | Sub-workflow | Sub-workflow |
| 6 | `KillAllProcesses.xaml` | Sub-workflow | Sub-workflow |
| 7 | `GetWeatherData.xaml` | Sub-workflow | Sub-workflow |
| 8 | `GetTfLStatus.xaml` | Sub-workflow | Sub-workflow |
| 9 | `GetC2CStatus.xaml` | Sub-workflow | Sub-workflow |
| 10 | `BuildRouteRecommendation.xaml` | Sub-workflow | Sub-workflow |

### Workflow Analyzer Compliance

Analyzed 9 workflow file(s) against UiPath Workflow Analyzer rules.

| Rule ID | Rule | Category | Status | Auto-Fixed | Remaining |
|---------|------|----------|--------|------------|----------|
| ST-NMG-001 | Variable naming convention | naming | Auto-Fixed | 23 | 0 |
| ST-NMG-004 | Argument naming convention | naming | Passed | 0 | 0 |
| ST-NMG-009 | Activity must have DisplayName | naming | Passed | 0 | 0 |
| ST-DBP-002 | Empty Catch block | best-practice | Passed | 0 | 0 |
| ST-DBP-006 | Delay activity usage | best-practice | Passed | 0 | 0 |
| ST-DBP-020 | Hardcoded timeout | best-practice | Passed | 0 | 0 |
| ST-DBP-025 | Workflow start/end logging | best-practice | Needs Review | 4 | 4 |
| ST-USG-005 | Unused variable | usage | Needs Review | 0 | 28 |
| ST-USG-017 | Deeply nested If activities | usage | Passed | 0 | 0 |
| ST-SEC-004 | Sensitive data in log message | security | Needs Review | 0 | 3 |
| ST-SEC-005 | Plaintext credential in property | security | Needs Review | 0 | 3 |
| ST-ARG-001 | Invalid bare Argument tag in Catch | usage | Auto-Fixed | 2 | 0 |
| ST-ARG-002 | Missing declaration for invoked argument | usage | Passed | 0 | 0 |
| ST-ARG-003 | Undeclared variable in expression | usage | Passed | 0 | 0 |

**Result:** 108 of 126 rules passed across 9 workflow files. 29 violation(s) auto-corrected, 38 remaining for review.

**Per-Workflow Breakdown:**

| Workflow | Rules Checked | Passed | Auto-Fixed | Remaining |
|----------|--------------|--------|------------|----------|
| `Main.xaml` | 14 | 10 | 1 | 8 |
| `GetWeatherData.xaml` | 14 | 12 | 6 | 7 |
| `GetTfLStatus.xaml` | 14 | 12 | 7 | 8 |
| `GetC2CStatus.xaml` | 14 | 12 | 7 | 8 |
| `BuildRouteRecommendation.xaml` | 14 | 13 | 0 | 1 |
| `InitAllSettings.xaml` | 14 | 10 | 5 | 3 |
| `ComposeEmail.xaml` | 14 | 13 | 1 | 1 |
| `SendEmail.xaml` | 14 | 13 | 1 | 1 |
| `LogResult.xaml` | 14 | 13 | 1 | 1 |

### Standards Enforcement

| Standard | What Was Done |
|----------|---------------|
| Naming Conventions | Variables renamed to `{type}_{PascalCase}`, arguments to `{direction}_{PascalCase}` |
| Activity Annotations | Every activity annotated with source step number, business context, and error handling strategy |
| Error Handling | All business activities wrapped in TryCatch with Log + Rethrow; UI activities include RetryScope (3 retries, 5s) |
| Logging | Start/end LogMessage in every workflow; exceptions logged at Error level before rethrow |
| Argument Validation | Entry points validate required arguments at workflow start |

### Architecture Decision

**REFramework** selected — queue-based transactional processing with built-in retry and recovery.

```
Init → Get Transaction → Process Transaction → Get Transaction (loop)
                                    ↓ (exception)
                              Close Apps → Get Transaction (retry)
                    ↓ (no more items)
                       End Process
```

---

## 3. Tier 2 — AI Resolved with Smart Defaults (Review Recommended)

The AI set these values based on SDD analysis. They are likely correct but **must be verified** against your target environment before production use.

### Asset Values

| Asset | Type | AI-Set Value | Action Required |
|-------|------|--------------|-----------------|
| `Gmail_Username` | Text | `(empty)` | Verify matches your environment. Gmail sender account username for SMTP email delivery. |
| `Recipient_Email` | Text | `Yusuf.yasin@uipath.com` | Verify matches your environment. Target email address for daily commute notification. |
| `Home_Lat` | Text | `51.5586` | Verify matches your environment. Home location latitude for OpenWeatherMap API geolocation (RM14 1BT). |
| `Home_Lon` | Text | `0.2490` | Verify matches your environment. Home location longitude for OpenWeatherMap API geolocation (RM14 1BT). |

### Trigger Configuration

| Trigger | Type | Schedule | Timezone | Status | Action Required |
|---------|------|----------|----------|--------|-----------------|
| `WTN-WeekdayMorningTrigger` | Time | Cron: `0 45 6 ? * MON-FRI` | UTC | unknown | Verify schedule matches business requirements |

---

## 4. Process Logic Validation

Use this section to verify that the generated automation correctly implements the business rules defined in the SDD. Each item below should be confirmed against the live system before UAT.

### Extracted Business Rules — Verification Checklist

The following rules were extracted from the SDD. Verify each is correctly implemented in the generated workflows:

| # | Category | Rule / Requirement | Verified |
|---|----------|-------------------|----------|
| 1 | Retry / SLA Requirements | retry once after 30 seconds, fail job if second attempt fails \| | [ ] |

---

## 5. Tier 3 — Requires Human Access (Developer Work Required)

These items require a developer with access to target systems and UiPath Studio. **Every generated package requires this work.**

### Credentials (3 items)

These require access to production/UAT credential stores. **Credentials are never auto-filled** — you must set real values.

| # | Asset | Orchestrator ID | Description | Where to Set |
|---|-------|-----------------|-------------|-------------|
| 1 | `WeatherAPI_Key` | — | OpenWeatherMap API key for weather data retrieval. Register free at openweathermap.org/api. | Orchestrator > Assets > `WeatherAPI_Key` > Edit |
| 2 | `Gmail_AppPassword` | — | Gmail App Password for SMTP authentication. Generate in Google Account security settings. | Orchestrator > Assets > `Gmail_AppPassword` > Edit |
| 3 | `NationalRail_ApiKey` | — | National Rail Open Data API key. Register free at opendata.nationalrail.co.uk. | Orchestrator > Assets > `NationalRail_ApiKey` > Edit |

### Business Logic & Manual Steps (5 items)

| # | Category | Activity | Description | Est. Time |
|---|----------|----------|-------------|----------|
| 1 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 2 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 3 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 4 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |
| 5 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |

### Machine & Robot Configuration

Machines provisioned: `WTN-UNATTENDED-01`. Verify they are assigned to the correct folder and have available unattended slots.

### Action Center Configuration

| # | Task Catalog | Status | ID | Action Required |
|---|-------------|--------|----|-----------------|
| 1 | `WTN-DeliveryFailureReview` | unknown | — | Assign role (Process Owner), configure form fields, set SLA (suggested: 2 hours) |

### Mandatory: Studio Validation & Testing

Every generated package requires these steps regardless of AI enrichment quality:

| # | Task | Description | Est. Time |
|---|------|-------------|----------|
| 1 | Studio Import | Open .nupkg in UiPath Studio. Install missing packages, resolve dependency conflicts, verify project compiles without errors. | 15 min |
| 2 | Credential Setup | Set real username/password for 3 credential asset(s) in Orchestrator > Assets. | 15 min |
| 3 | End-to-End Testing | Execute all 10 workflows in Studio Debug mode against UAT/test environment. Verify queue processing, exception handling, and business rules. | 30 min |
| 4 | UAT Sign-off | Business stakeholder validation with real data and real systems. Confirm outputs match expected results for representative scenarios. | 60 min |

**Total Tier 3 Effort: ~7.3 hours** (0 selectors, 3 credentials, 5 logic items, mandatory validation)

---

## 6. Code Review Checklist

Use this checklist during peer review before promoting to UAT.

### Workflow Analyzer Remaining Violations

| Severity | Rule | File | Message |
|----------|------|------|---------|
| warning | ST-USG-005 | Main.xaml | Variable "str_PrimaryRouteDisrupted" is declared but never used |
| warning | ST-USG-005 | Main.xaml | Variable "str_ScreenshotPath" is declared but never used |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "api_key") — use SecureString or mask the value |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "apikey") — use SecureString or mask the value |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "credential") — use SecureString or mask the value |
| error | ST-SEC-005 | Main.xaml | Possible plaintext credential detected — use Orchestrator Asset or Windows Credential Manager |
| error | ST-SEC-005 | Main.xaml | Possible plaintext credential detected — use Orchestrator Asset or Windows Credential Manager |
| error | ST-SEC-005 | Main.xaml | Possible plaintext credential detected — use Orchestrator Asset or Windows Credential Manager |
| warning | ST-USG-005 | GetWeatherData.xaml | Variable "str_Retry" is declared but never used |
| warning | ST-USG-005 | GetWeatherData.xaml | Variable "str_Exhausted" is declared but never used |
| warning | ST-USG-005 | GetWeatherData.xaml | Variable "str_HttpResponseStatus" is declared but never used |
| warning | ST-USG-005 | GetWeatherData.xaml | Variable "str_Lt" is declared but never used |
| warning | ST-USG-005 | GetWeatherData.xaml | Variable "str_Gt" is declared but never used |
| warning | ST-USG-005 | GetWeatherData.xaml | Variable "str_Pop" is declared but never used |
| warning | ST-USG-005 | GetWeatherData.xaml | Variable "str_ScreenshotPath" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_Retry" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_Exhausted" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_HttpResponseStatus" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_Lt" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_Gt" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_DistrictLineObject" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_Reason" is declared but never used |
| warning | ST-USG-005 | GetTfLStatus.xaml | Variable "str_ScreenshotPath" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_Retry" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_Exhausted" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_HttpResponseStatus" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_Lt" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_Gt" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_ServicesArray" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_IsCancelled" is declared but never used |
| warning | ST-USG-005 | GetC2CStatus.xaml | Variable "str_ScreenshotPath" is declared but never used |
| warning | ST-USG-005 | BuildRouteRecommendation.xaml | Variable "str_ScreenshotPath" is declared but never used |
| warning | ST-DBP-025 | InitAllSettings.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "str_ConfigPath" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "drow_RowCurrent" is declared but never used |
| warning | ST-DBP-025 | ComposeEmail.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-DBP-025 | SendEmail.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-DBP-025 | LogResult.xaml | Workflow does not contain an initial LogMessage activity |

### Review Rubric

| Category | Check | Status |
|----------|-------|---------|
| Exception Handling | All activities in TryCatch? Catch blocks log + rethrow? | AI: Done |
| Transaction Integrity | Queue items set to Success/Failed/BusinessException? | AI: Done (REFramework) |
| Logging | Info log at start/end of each workflow? Critical decisions logged? | AI: Done |
| Selector Reliability | Selectors use stable attributes (automationid, name)? | N/A |
| Credential Security | All credentials in Orchestrator Assets, not hardcoded? | AI: Verified |
| Naming Conventions | Variables/arguments follow type/direction prefixes? | AI: Auto-corrected |
| Annotations | Every activity annotated with business context? | AI: Done |
| Argument Validation | Entry points validate required arguments? | AI: Done |
| Config Management | Environment-specific values in Config.xlsx? | AI: Done |

### Pre-Deployment Verification

1. Open the project in UiPath Studio
2. Run **Analyze File** > **Workflow Analyzer** on all files
3. Confirm zero errors and zero warnings
4. Run all unit tests in Test Manager
5. Execute a full end-to-end run in Dev environment

### Sign-Off

| Field | Value |
|-------|-------|
| Reviewer | _________________ |
| Date | _________________ |
| Approval | [ ] Approved for UAT  [ ] Requires Changes |
| Notes | _________________ |

---

## 7. Package Contents

| File | Purpose |
|------|--------|
| `project.json` | UiPath project manifest with dependencies |
| `Main.xaml` | REFramework State Machine entry point |
| `GetTransactionData.xaml` | Fetches next queue item |
| `Process.xaml` | Business logic for single transaction |
| `SetTransactionStatus.xaml` | Marks transaction Success/Failed |
| `CloseAllApplications.xaml` | Graceful app cleanup |
| `KillAllProcesses.xaml` | Force-kill hanging processes |
| `GetWeatherData.xaml` | Workflow: GetWeatherData |
| `GetTfLStatus.xaml` | Workflow: GetTfLStatus |
| `GetC2CStatus.xaml` | Workflow: GetC2CStatus |
| `BuildRouteRecommendation.xaml` | Workflow: BuildRouteRecommendation |
| `InitAllSettings.xaml` | Configuration initialization |
| `Data/Config.xlsx` | Configuration settings |
| `DeveloperHandoffGuide.md` | This guide |

**Required Packages:** `UiPath.System.Activities`, `UiPath.UIAutomation.Activities`

---

## 8. Test Suite

| # | Test Case | Type | Priority | Status |
|---|-----------|------|----------|--------|
| 1 | `TC001 - Happy Path No Disruptions` | Functional | Medium | unknown |
| 2 | `TC002 - District Line Disrupted C2C Available` | Functional | Medium | unknown |
| 3 | `TC003 - Both Routes Disrupted` | Functional | Medium | unknown |
| 4 | `TC004 - Weather API Failure` | Functional | Medium | unknown |
| 5 | `TC005 - Gmail SMTP Failure` | Functional | Medium | unknown |
| 6 | `TC006 - All APIs Unavailable` | Functional | Medium | unknown |

| # | Test Set | Mode | Test Cases | Status |
|---|----------|------|------------|--------|
| 1 | `Happy Path Tests` | Sequential | 1 | unknown |
| 2 | `Disruption Scenario Tests` | Sequential | 2 | unknown |
| 3 | `Exception Handling Tests` | Sequential | 3 | unknown |

---

## 9. Requirements Traceability

| # | Requirement | Type | Priority | Status |
|---|------------|------|----------|--------|
| 1 | `REQ-001: Daily weekday email notification` | Functional | Medium | unknown |
| 2 | `REQ-002: Weather data for 7am departure` | Functional | Medium | unknown |
| 3 | `REQ-003: TfL Underground status check` | Functional | Medium | unknown |
| 4 | `REQ-004: National Rail C2C fallback check` | Functional | Medium | unknown |
| 5 | `REQ-005: Route recommendation in email` | Functional | Medium | unknown |
| 6 | `REQ-006: Graceful degradation on API failure` | Functional | Medium | unknown |

---

## 10. Infrastructure

**Machines:** `WTN-UNATTENDED-01` (Unattended, 1 slots)
**Storage:** `WTN-Logs` (Orchestrator)

### Action Center

**WTN-DeliveryFailureReview** (unknown) — SLA: 2 hours

---

## 11. Go-Live Checklist

#### Development
- [ ] Open project in UiPath Studio — install missing packages
- [ ] Run Workflow Analyzer — confirm zero violations
- [ ] Complete Tier 3 items (selectors, credentials, business logic)
- [ ] Config.xlsx updated with Dev values

#### UAT
- [ ] UAT Orchestrator folder with separate assets/queues
- [ ] Full end-to-end run with real data
- [ ] Business stakeholder sign-off

#### Production
- [ ] Production credentials and assets configured
- [ ] Triggers/schedules active
- [ ] Monitoring and alerting configured
- [ ] Runbook documentation completed
